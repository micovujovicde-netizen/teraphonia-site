#!/usr/bin/env python3
"""Insert TERAPHON Receivers hero before BrakeMonster in the existing website ZIP.

Non-destructive, idempotent: modifies homepage HTML only and adds three isolated
assets. All payment, app download, help, receiver pages, and manifests are preserved.
"""
import sys, re, tempfile, zipfile
from pathlib import Path
SITE=Path(sys.argv[1]) if len(sys.argv)>1 else Path('TERAPHONIA_Website.zip')
PATCH=Path(sys.argv[2]) if len(sys.argv)>2 else Path('TERAPHON_SITE_HELP_PATCH.zip')
START='<!-- TERAPHON-HOMEPAGE-RECEIVERS-START -->'
END='<!-- TERAPHON-HOMEPAGE-RECEIVERS-END -->'
STYLE='<link rel="stylesheet" href="/assets/teraphon-receivers-home.css" data-tph-receivers-home-css>'
SCRIPT='<script defer src="/assets/teraphon-receivers-home.js" data-tph-receivers-home-js></script>'
ASSET_PATHS=('assets/teraphon-receivers-hero.webp','assets/teraphon-receivers-home.css','assets/teraphon-receivers-home.js')
with zipfile.ZipFile(SITE) as archive,zipfile.ZipFile(PATCH) as patch:
    if archive.testzip() is not None or patch.testzip() is not None:raise SystemExit('Invalid ZIP integrity')
    names=archive.namelist()
    if len(set(names))!=len(names):raise SystemExit('Duplicate paths in existing website ZIP')
    original={n:archive.read(n) for n in names if not n.endswith('/')}
    if 'index.html' not in original:raise SystemExit('Main index.html missing from website ZIP')
    # Existing Receiver page must already exist: we link there, not to an unverified URL.
    if 'teraphon/receivers/index.html' not in original:
        raise SystemExit('Existing TERAPHON Receivers page not found; refusing to add a broken homepage link')
    new=dict(original)
    for path in ASSET_PATHS:
        new[path]=patch.read('payload/'+path)
    page=original['index.html'].decode('utf-8')
    snippet=patch.read('hero-section.html').decode('utf-8')
    if START in page:
        if page.count(START)!=1 or page.count(END)!=1:
            raise SystemExit('Corrupt or duplicate receiver homepage markers')
        left=page.index(START);right=page.index(END,left)+len(END)
        page=page[:left]+snippet+page[right:]
    else:
        main=re.search(r'<main\b[^>]*>',page,re.I)
        if not main:raise SystemExit('Unable to find <main> on homepage')
        # Prefer the actual BrakeMonster hero section, if its CSS class is present.
        stage=re.search(r'<section\b[^>]*\bclass\s*=\s*["\'][^"\']*\bstage\b[^"\']*["\'][^>]*>',page[main.end():],re.I)
        if stage:
            at=main.end()+stage.start()
        else:
            # Secondary detection: first section of the main content containing a
            # BrakeMonster title/brand, with no assumption about current CSS classes.
            area=page[main.end():]
            sections=list(re.finditer(r'<section\b[^>]*>',area,re.I))
            at=None
            for sec in sections:
                next_section=next((s.start() for s in sections if s.start()>sec.start()),len(area))
                chunk=area[sec.start():next_section]
                if re.search(r'brake\s*monster|brakemonster',chunk,re.I):
                    at=main.end()+sec.start();break
            if at is None:
                raise SystemExit('Cannot safely locate BrakeMonster section; homepage was not changed')
        page=page[:at]+snippet+'\n'+page[at:]
    if 'data-tph-receivers-home-css' not in page:
        head=re.search(r'</head\s*>',page,re.I)
        if not head:raise SystemExit('Homepage </head> missing')
        page=page[:head.start()]+STYLE+'\n'+page[head.start():]
    if 'data-tph-receivers-home-js' not in page:
        body=re.search(r'</body\s*>',page,re.I)
        if not body:raise SystemExit('Homepage </body> missing')
        page=page[:body.start()]+SCRIPT+'\n'+page[body.start():]
    if page.count(START)!=1 or page.count(END)!=1 or '/teraphon/receivers/' not in page:
        raise SystemExit('Homepage hero validation failed')
    # Verify it precedes the existing BrakeMonster section.
    hero_end=page.index(END)
    suffix=page[hero_end:]
    if not re.search(r'brake\s*monster|brakemonster',suffix,re.I):
        raise SystemExit('No BrakeMonster after receiver hero; refusing incorrect placement')
    new['index.html']=page.encode('utf-8')
    changed={n for n in original if original[n]!=new[n]}
    if changed-({'index.html'}|set(ASSET_PATHS)):
        raise SystemExit('Unauthorized modification outside homepage and assets')
    newfiles=set(new)-set(original)
    if newfiles-set(ASSET_PATHS):raise SystemExit('Unexpected new files')
    for guarded in ('releases/latest.json','commercial-config.json','teraphon-product.json','purchase.js','purchase-complete.html','teraphon/receivers/index.html','teraphon/receivers/i18n.json'):
        if guarded in original and original[guarded]!=new[guarded]:
            raise SystemExit('Guarded website file modified: '+guarded)
    with tempfile.NamedTemporaryFile(dir=SITE.parent,suffix='.zip',delete=False) as f:
        dest=Path(f.name)
    try:
        with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as o:
            for name,data in new.items():o.writestr(name,data)
            o.comment=archive.comment
        with zipfile.ZipFile(dest) as check:
            if check.testzip() is not None:raise SystemExit('New website ZIP integrity check failed')
            if check.namelist().count('index.html')!=1:raise SystemExit('Duplicate main index')
        dest.replace(SITE)
    finally:
        dest.unlink(missing_ok=True)
    print('TERAPHON Receivers homepage hero added before BrakeMonster. All other site files preserved.')

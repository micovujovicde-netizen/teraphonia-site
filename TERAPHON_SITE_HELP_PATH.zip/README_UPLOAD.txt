TERAPHON RECEIVERS — HOMEPAGE HERO UPDATE

File to upload to repository root:
  TERAPHON_SITE_HELP_PATCH.zip

Repo:
  https://github.com/micovujovicde-netizen/teraphonia-site

Your existing GitHub Action "TERAPHON — apply HELP and product images" already
watches this exact filename. Replace the current file of that name with this ZIP.

What it does:
- Adds your latest Windows laptop image to the homepage, before BrakeMonster.
- Adds Windows and Android Receiver icons with one DOWNLOAD RECEIVERS button.
- That button links to the already-published /teraphon/receivers/ page.
- Supports the existing site's English, Montenegrin, German, Italian,
  Spanish and French language selector.
- Small screen: responsive vertical layout, strong contrast and large buttons.
- Does not touch the existing receivers downloads, help, site licensing,
  pricing, APK releases, production signature or other website content.

Technical safety:
- Requires existing receiver page to be in current canonical site ZIP.
- Only changes index.html and adds/updates 3 dedicated assets.
- Safely updates the hero in place if applied repeatedly.
- Refuses to alter the website if BrakeMonster's location cannot be determined.

After GitHub Apply action becomes green, it will dispatch deploy.yml.
#!/usr/bin/env python3
"""TERAPHON-first homepage. Move BrakeMonster marketing into a real menu and
prevent ambiguous shared Creem storefront checkout. Standard library only.
Usage: python apply_site_patch.py TERAPHONIA_Website.zip TERAPHON_SITE_HELP_PATCH.zip

Conservative: never edits BrakeMonster billing/download assets or any payment API.
Idempotent: rerunning does not add duplicate elements or pages.
"""
from __future__ import annotations
import hashlib
import os
import re
import sys
import tempfile
import zipfile
from pathlib import Path
from urllib.parse import urlsplit

if len(sys.argv) != 3:
    raise SystemExit('Usage: apply_site_patch.py TERAPHONIA_Website.zip TERAPHON_SITE_HELP_PATCH.zip')
site, patch = map(Path, sys.argv[1:])
if not site.is_file() or not patch.is_file():
    raise SystemExit('Site ZIP and patch ZIP are required')

with zipfile.ZipFile(site) as z:
    if z.testzip() is not None:
        raise SystemExit('Existing site ZIP CRC error')
    raw = {f.filename:z.read(f.filename) for f in z.infolist() if not f.is_dir()}
    comment = z.comment

if 'index.html' not in raw:
    raise SystemExit('Missing homepage index.html; no changes made')

with zipfile.ZipFile(patch) as z:
    if z.testzip() is not None:
        raise SystemExit('Patch ZIP CRC error')
    css = z.read('assets/tera-home-menu.css')
    js = z.read('assets/tera-home-menu.js')

protected = ('buy.html','purchase.js','commercial-config.json','releases/latest.json',
             'help.html','help-content.js','download-release.js','release.js',
             'download-brakemonster-pro/index.html','brakemonster-pro/index.html',
             'brakemonster/index.html')
snapshot = {name: hashlib.sha256(raw[name]).hexdigest() for name in protected if name in raw}

homepage = raw['index.html'].decode('utf-8')
if not re.search(r'<main\b',homepage,re.I):
    raise SystemExit('No main tag on homepage')

def brake_monster_link(href):
    url = urlsplit(href)
    if url.hostname == 'affiliates.creem.io':
        return url.path.rstrip('/') == '/join/brakemonsterpropartners'
    return url.hostname in (None, 'teraphonia.com', 'www.teraphonia.com') and url.path.strip('/') in {
        'brakemonster', 'brakemonster/index.html',
        'brakemonster-pro', 'brakemonster-pro/index.html',
        'download-brakemonster-pro', 'download-brakemonster-pro/index.html', 'buy.html',
    }


anchor = re.compile(r'<a\b[^>]*\shref=["\']([^"\']+)["\'][^>]*>[\s\S]*?</a>', re.I)
bm_section = re.compile(
    r'<section\b[^>]*\bclass=["\'](?:[^"\']*\s)?bm-section(?:\s[^"\']*)?["\'][^>]*>'
    r'[\s\S]*?</section>', re.I)


def has_brake_monster_link(html):
    return any(brake_monster_link(href) for href in anchor.findall(html))


# The newer homepage contains one standalone BrakeMonster promo; TERAPHON pricing
# is a separate block and uses the generic #pricing ID.
homepage = bm_section.sub(lambda m: '' if has_brake_monster_link(m[0]) else m[0], homepage)
bm_landing = 'brakemonster-pro' if 'brakemonster-pro/index.html' in raw else 'brakemonster'

# 1) Remove old BrakeMonster stage, cards, features and download CTA from the root,
# leaving the entire TERAPHON + Receiver + Teraphonia universe intact.
# The region starts at the legacy BrakeMonster stage and ends immediately before
# the original independent TERAPHONIA universe section.
legacy = re.search(
    r'<section\s+class=["\']stage["\'][\s\S]*?(?=<section\s+class=["\']section\s+shell["\']\s+id=["\']universe["\'])',
    homepage, re.I)
if legacy:
    old_content = legacy.group(0).strip()
    section_openings = re.findall(r'<section\b', old_content, re.I)
    if len(section_openings) != 4:
        raise SystemExit('Homepage layout changed; refusing to remove any unrecognized sections')
    if 'BrakeMonster' not in old_content and 'BRAKEMONSTER' not in old_content and 'MONSTER' not in old_content:
        raise SystemExit('Unexpected homepage stage; refuse to remove unrelated content')
    if f'{bm_landing}/index.html' not in raw:
        # Preserve original marketing and pricing at a dedicated BrakeMonster page;
        # no checkout URLs, billing code or release metadata are changed.
        fragment = re.sub(
            r'\b(href|src|srcset)=("|\')(?!/|https?:|mailto:|#|data:)([^"\']+)\2',
            lambda m: f'{m.group(1)}={m.group(2)}/{m.group(3)}{m.group(2)}',
            old_content, flags=re.I)
        separate = '''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#0c0d0e"><meta name="description" content="BrakeMonster PRO by TERAPHONIA, a separate Android app with separate pricing and licensing."><title>BrakeMonster PRO | TERAPHONIA</title><link rel="icon" href="/assets/bm-pro-icon.png" type="image/png"><link rel="stylesheet" href="/store.css"></head><body><header class="site-header"><div class="shell header-inner"><a class="brand" href="/" aria-label="TERAPHONIA home"><img src="/assets/teraphonia.png" alt="TERAPHONIA" width="218"></a><nav aria-label="BrakeMonster navigation"><a href="/">TERAPHON HOME</a><a class="nav-download" href="/download-brakemonster-pro/">DOWNLOAD BRAKEMONSTER</a><a href="/buy.html">BRAKEMONSTER PLANS</a><a href="/help.html">HELP</a></nav></div></header><main><section class="shell section"><p style="border:1px solid #ad945c;border-radius:12px;padding:14px;color:#fff;line-height:1.5;font-size:18px">BRAKEMONSTER PRO is a separate app from TERAPHON. Each has its own license and prices. Check the product name before purchasing.</p></section>''' + fragment + '''</main><footer class="site-footer"><div class="shell footer-inner"><div><strong>TERAPHONIA · BrakeMonster PRO</strong><p>Separate Android product, separate license.</p></div><div><a href="/">TERAPHON HOME</a><a href="/download-brakemonster-pro/">BrakeMonster APK</a><a href="/buy.html">BrakeMonster plans</a></div></div></footer></body></html>'''
        raw['brakemonster/index.html']=separate.encode('utf-8')
    homepage = homepage[:legacy.start()] + homepage[legacy.end():]
elif f'{bm_landing}/index.html' not in raw:
    # Recovery for sites where an earlier update has ALREADY removed the
    # BrakeMonster stage without creating the dedicated landing page.
    # A missing stage is not a reason to fail a site that otherwise retains
    # its intact, separately licensed BrakeMonster checkout/download pages.
    required=('buy.html','download-brakemonster-pro/index.html')
    missing=[n for n in required if n not in raw]
    if missing:
        raise SystemExit('BrakeMonster legacy page missing; refusing to create broken links: '+', '.join(missing))
    separate='''<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#0c0d0e">
<meta name="description" content="BrakeMonster PRO — a separate Android music application from TERAPHON. Separate checkout and license.">
<title>BrakeMonster PRO | TERAPHONIA</title>
<link rel="icon" href="/assets/bm-pro-icon.png" type="image/png">
<link rel="stylesheet" href="/store.css">
<style>
.bm-wrap{box-sizing:border-box;max-width:900px;margin:auto;padding:28px 22px 62px;color:#f5f2e9}
.bm-wrap h1{font-size:clamp(30px,6vw,56px);line-height:1.14;margin:0 0 16px}
.bm-wrap p{font-size:clamp(18px,3vw,22px);line-height:1.55;margin:0 0 25px}
.bm-notice{border:1px solid #b69c5f;border-radius:14px;padding:16px 20px;background:#151715}
.bm-actions{display:flex;flex-wrap:wrap;gap:14px;margin-top:28px}
.bm-actions a{display:inline-flex;box-sizing:border-box;align-items:center;justify-content:center;min-height:52px;padding:12px 18px;border:1px solid #b69c5f;border-radius:10px;color:#fff;text-decoration:none;background:#181d1b;font-weight:700;font-size:18px}
.bm-actions a:first-child{background:#8c6f29;color:#fff}
.bm-wrap a:focus-visible{outline:3px solid #e1bc63;outline-offset:3px}
@media(max-width:560px){.bm-actions{flex-direction:column}.bm-actions a{width:100%}}
</style></head><body>
<header class="site-header"><div class="shell header-inner"><a class="brand" href="/" aria-label="TERAPHONIA home"><img src="/assets/teraphonia.png" alt="TERAPHONIA" width="218"></a></div></header>
<main class="bm-wrap"><h1>BrakeMonster PRO</h1>
<p class="bm-notice">BrakeMonster PRO is a <strong>separate app</strong> from TERAPHON, with its own pricing and license. Please check the product name before purchasing.</p>
<p>Find the official BrakeMonster PRO download and subscription options here.</p>
<nav class="bm-actions" aria-label="BrakeMonster PRO actions">
<a href="/download-brakemonster-pro/">DOWNLOAD BRAKEMONSTER</a>
<a href="/buy.html">BRAKEMONSTER PRO PLANS</a>
<a href="/help.html">HELP</a>
<a href="/">TERAPHON HOME</a>
</nav></main></body></html>'''
    raw['brakemonster/index.html']=separate.encode('utf-8')
    print('Recovered missing BrakeMonster menu landing page (existing stage already absent)')

# 2) Replace just the HOMEPAGE navigation. Do not edit navigation on legacy
# BrakeMonster buy/help/download pages or TERAPHON subpages.
nav_html = f'''<nav id="site-navigation" class="tera-primary-nav" aria-label="Primary navigation" data-tera-home-nav>
<a href="/" aria-current="page" data-tera-home-label="home">POČETNA</a>
<a href="/#features"><span data-i18n="nav_features">FEATURES</span></a>
<a href="/teraphon/download/" class="tera-primary-download" data-tera-home-label="download">PREUZMI TERAPHON</a>
<a href="/teraphon/plans/" data-tera-home-label="plans">TERAPHON PLANOVI</a>
<a href="/teraphon/help/" data-tera-home-label="help">POMOĆ</a>
<details class="tera-more"><summary data-tera-home-label="menu">MENI</summary>
<div class="tera-more-panel" role="group" aria-label="More TERAPHONIA products">
<a href="/{bm_landing}/"><strong data-tera-home-label="bm">BrakeMonster PRO</strong><small data-tera-home-label="bmSub">Odvojena aplikacija</small></a>
<a href="/buy.html"><strong data-tera-home-label="bmPlans">BrakeMonster PRO planovi</strong><small data-tera-home-label="bmPlansSub">Zasebna kupovina i licenca</small></a>
</div></details></nav>'''
header = re.search(r'<header\b[\s\S]*?</header>', homepage, re.I)
if not header:
    raise SystemExit('No homepage header found')
nav = re.search(r'<nav\b[\s\S]*?</nav>', header.group(0), re.I)
if not nav:
    raise SystemExit('No homepage nav found')
h = header.group(0)
h = h[:nav.start()] + nav_html + h[nav.end():]
homepage = homepage[:header.start()] + h + homepage[header.end():]

# 3) Replace homepage footer's high-prominence BrakeMonster links with clear
# TERAPHON links. BrakeMonster is now only in the menu.
foot = re.search(r'<footer\b[\s\S]*?</footer>', homepage, re.I)
if not foot:raise SystemExit('No homepage footer')
f = foot.group(0)
f = anchor.sub(lambda m: '' if brake_monster_link(m[1]) else m[0], f)
if '/teraphon/download/' not in f:
    f = f.replace('</footer>', '<div><a href="/teraphon/download/" data-tera-home-label="download">PREUZMI TERAPHON</a><a href="/teraphon/plans/" data-tera-home-label="plans">TERAPHON PLANOVI</a><a href="/teraphon/help/" data-tera-home-label="help">POMOĆ</a></div></footer>')
homepage=homepage[:foot.start()]+f+homepage[foot.end():]

# Remove any remaining promotional BrakeMonster line from the TERAPHON hero
# without deleting its real download/pricing/Receivers content.
hero_note=re.compile(r'<p\s+class="tera-note"\s+data-tera="footerNote"[^>]*>.*?</p>',re.I|re.S)
if '<!-- TERAPHON-STORE-START -->' in homepage:
    a=homepage.index('<!-- TERAPHON-STORE-START -->'); b=homepage.index('<!-- TERAPHON-STORE-END -->',a)
    hero=homepage[a:b]
    hero=hero_note.sub('',hero)
    # Make the free TERAPHON download the first action on the homepage.
    hero=re.sub(r'<div\s+class="tera-actions">.*?</div>',
        '<div class="tera-actions"><a class="tera-btn" href="/teraphon/download/" data-tera="downloadTitle">DOWNLOAD TERAPHON</a><a class="tera-btn secondary" href="/teraphon/plans/" data-tera="heroCta">VIEW TERAPHON PLANS</a></div>',hero,count=1,flags=re.S|re.I)
    homepage=homepage[:a]+hero+homepage[b:]

# 4) Root metadata must not advertise BrakeMonster as the lead product.
homepage=re.sub(r'<title>[^<]*</title>','<title>TERAPHONIA · TERAPHON Android Music Player</title>',homepage,count=1,flags=re.I)
homepage=re.sub(r'<meta\s+name="description"\s+content="[^"]*"',
    '<meta name="description" content="TERAPHON for Android: free 7-day trial, professional music mixing, playlists, Receivers, three-device licenses and direct APK download."',homepage,count=1,flags=re.I)

# Only the homepage loads these assets. This avoids changing global menu or
# BrakeMonster look-and-feel. Changing query version busts mobile cache.
marker='20261123-tera-main-menu4'
if 'data-tera-home-menu-css' not in homepage:
    homepage=homepage.replace('</head>',f'<link rel="stylesheet" href="/assets/tera-home-menu.css?v={marker}" data-tera-home-menu-css>\n</head>',1)
if 'data-tera-home-menu-js' not in homepage:
    homepage=homepage.replace('</body>',f'<script src="/assets/tera-home-menu.js?v={marker}" defer data-tera-home-menu-js></script>\n</body>',1)
# Styles/scripts are versioned with a distinct menu marker if the patch is reapplied.
homepage=re.sub(r'(/assets/tera-home-menu\.(?:js|css))\?v=[^"\s]+',rf'\1?v={marker}',homepage)
# Check for actual BrakeMonster destinations outside the product menu.
outside_menu = re.sub(r'<details\s+class=["\']tera-more["\'][\s\S]*?</details>', '', homepage, flags=re.I)
if has_brake_monster_link(outside_menu):
    raise SystemExit('A BrakeMonster product link remains outside the menu')
raw['index.html']=homepage.encode('utf-8')
raw['assets/tera-home-menu.css']=css
raw['assets/tera-home-menu.js']=js

# 5) Critical root cause: TERAPHON plan buttons without app installation token
# used to open a SHARED Creem storefront containing BrakeMonster products.
# Do not create a fake Android installation token (would consume a license slot).
# Send browser visitors to TERAPHON download; inside the app the existing signed
# checkout flow remains unchanged. Users must not land on mixed-product store.
js_path='assets/tera-site.js'
if js_path not in raw:raise SystemExit('TERAPHON JS not found; no changes made')
src=raw[js_path].decode('utf-8')
old="else location.assign(STORE)"
new="else location.assign('/teraphon/download/#buy-in-app')"
if old in src:
    src=src.replace(old,new,1)
elif new not in src:
    raise SystemExit('TERAPHON checkout fallback changed; refusing to overwrite unknown logic')
if 'const result=await getHealth();if(status)' in src:
    src = src.replace(
        'const result=await getHealth();if(status)',
        "const result=activePurchaseToken?await getHealth():'statusReady';if(status)",
        1)
    src = src.replace(
        'status.dataset.teraHealth=result;status.textContent=tt(result)',
        "status.dataset.teraHealth=activePurchaseToken?result:'buyNote';status.textContent=tt(status.dataset.teraHealth)",
        1)
src = src.replace("const STORE='https://www.creem.io/stores/teraphonia';\n", '')
src = src.replace("checkoutReady:'SELECT ON CREEM'", "checkoutReady:'BUY IN TERAPHON APP'")
raw[js_path]=src.encode('utf-8')

download = 'teraphon/download/index.html'
if download in raw:
    page = raw[download].decode('utf-8')
    if 'id="buy-in-app"' not in page:
        page = page.replace('<p data-tera="notInstalled">', '<p id="buy-in-app" data-tera="notInstalled">', 1)
    raw[download] = page.encode('utf-8')

# Update the six localized plan-button labels and purchase instructions where
# the existing key schema is available (never alter BrakeMonster translations).
import json
path='assets/tera-i18n.json'
if path in raw:
    data=json.loads(raw[path].decode('utf-8'))
    labels={
      'en':('BUY IN TERAPHON APP','Install/open TERAPHON and select your plan inside the app. That checkout creates a TERAPHON activation code for up to three Android devices.','To buy, open TERAPHON on your phone or tablet and select a plan. Do not use the shared Creem storefront.'),
      'cnr':('KUPI U TERAPHON APLIKACIJI','Instaliraj ili otvori TERAPHON i izaberi plan unutar aplikacije. Tako dobijaš TERAPHON aktivacioni kod za do tri Android uređaja.','Za kupovinu otvori TERAPHON na telefonu ili tabletu i izaberi plan. Ne koristi zajedničku Creem prodavnicu.'),
      'de':('IN TERAPHON KAUFEN','Installiere oder öffne TERAPHON und wähle deinen Tarif in der App. So erhältst du einen Aktivierungscode für bis zu drei Android-Geräte.','Kaufe direkt in der TERAPHON-App, nicht im gemeinsamen Creem-Shop.'),
      'it':("ACQUISTA NELL'APP TERAPHON",'Installa o apri TERAPHON e scegli il piano nell’app. Riceverai un codice di attivazione per un massimo di tre dispositivi Android.','Acquista direttamente nell’app TERAPHON, non nello store Creem condiviso.'),
      'es':('COMPRA EN LA APP TERAPHON','Instala o abre TERAPHON y elige tu plan en la aplicación. Recibirás un código de activación para hasta tres dispositivos Android.','Compra desde la app TERAPHON, no desde la tienda Creem compartida.'),
      'fr':("ACHETER DANS L'APP TERAPHON",'Installez ou ouvrez TERAPHON puis choisissez votre formule dans l’application. Vous recevrez un code pour trois appareils Android au maximum.','Achetez depuis l’application TERAPHON, pas depuis la boutique Creem partagée.'),
    }
    for lang,(btn,note,again) in labels.items():
        if lang in data:
            data[lang]['checkoutReady']=btn
            data[lang]['buyNote']=note
            data[lang]['chooseAgain']=again
    raw[path]=(json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode('utf-8')

# Refresh script/JSON on all TERAPHON pages so mobiles do not keep the old
# redirect from cache. Does not change BrakeMonster pages.
version='20261123-tera-only5'
for n in ['index.html','teraphon/index.html','teraphon/plans/index.html','teraphon/help/index.html','teraphon/download/index.html']:
    if n in raw:
        txt=raw[n].decode('utf-8')
        if n.startswith('teraphon/'):
            # Remove shared storefront hyperlinks from every TERAPHON page.
            # Creem is still the processor inside the official TERAPHON checkout.
            txt=re.sub(r'\s*·\s*<a\s+href="https://www\.creem\.io/stores/teraphonia"[^>]*>Creem</a>', '', txt, flags=re.I)
        if n == 'teraphon/plans/index.html':
            txt = txt.replace(
                'Choose the plan on Creem. A verified purchase sends a code by email.',
                'Choose your plan in TERAPHON. A verified purchase sends an activation code by email.')
            txt = txt.replace(
                'When buying from a browser, choose the TERAPHON plan again on Creem.',
                'Open TERAPHON on your phone or tablet to purchase a plan.')
        txt=re.sub(r'(/assets/tera-site\.js)(?:\?v=[A-Za-z0-9._-]+)?',rf'\1?v={version}',txt)
        raw[n]=txt.encode('utf-8')
src=raw[js_path].decode('utf-8')
src=re.sub(r"('/assets/tera-i18n\.json)(?:\?v=[A-Za-z0-9._-]+)?(')",rf'\1?v={version}\2',src)
raw[js_path]=src.encode('utf-8')

# No change of any BrakeMonster payment/availability/config code.
for name,h in snapshot.items():
    if hashlib.sha256(raw[name]).hexdigest()!=h:
        raise SystemExit('Protected production file unexpectedly changed: '+name)
if raw['index.html'].count(b'data-tera-home-nav')!=1:
    raise SystemExit('Root navigation not unique')
if f'{bm_landing}/index.html' not in raw:
    raise SystemExit('Dedicated BrakeMonster menu landing page missing')
if old in raw[js_path].decode('utf-8'):
    raise SystemExit('Shared storefront redirect still present')

with tempfile.NamedTemporaryFile(dir=site.parent,suffix='.zip',delete=False) as f:
    tmp=Path(f.name)
try:
    with zipfile.ZipFile(tmp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
        z.comment=comment
        for name,body in raw.items():
            z.writestr(name,body)
    with zipfile.ZipFile(tmp) as z:
        if z.testzip() is not None:raise SystemExit('Merged site CRC failure')
    os.replace(tmp,site)
except Exception:
    tmp.unlink(missing_ok=True)
    raise
print('SUCCESS TERAPHON-first homepage and distinct BrakeMonster menu:',len(raw),'files; bytes',site.stat().st_size)

#!/usr/bin/env python3
"""Apply TERAPHON e-commerce patch onto current canonical site ZIP.

Idempotent; all existing BrakeMonster (buy.html, purchase.js, latest.json) retained.
Used directly by the repository's existing TERAPHON_SITE_HELP_PATCH.zip unpack workflow.
"""
from __future__ import annotations
import sys,zipfile,os,tempfile,re,hashlib
from pathlib import Path
from collections import OrderedDict

if len(sys.argv)!=3:
    raise SystemExit('Usage: apply_site_patch.py TERAPHONIA_Website.zip TERAPHON_SITE_HELP_PATCH.zip')
site, patch=map(Path,sys.argv[1:]);
if not site.is_file() or not patch.is_file():raise SystemExit('Missing site or patch')

with zipfile.ZipFile(site) as z:
    if z.testzip() is not None:raise SystemExit('Existing website ZIP invalid')
    raw={i.filename:z.read(i.filename) for i in z.infolist() if not i.is_dir()}
    saved={k:hashlib.sha256(v).hexdigest() for k,v in raw.items() if k in ('buy.html','purchase.js','commercial-config.json','releases/latest.json','help.html','help-content.js')}
    comment=z.comment

# Source archive may have a single top-level directory.
if 'index.html' not in raw:
    candidates=[n for n in raw if n.endswith('/index.html') and n.count('/') in (1,2)]
    prefix=next((n[:-10] for n in candidates if all(x.startswith(n[:-10]) for x in raw)),None)
    if prefix:
        raw.update({x[len(prefix):]:b for x,b in list(raw.items()) if x.startswith(prefix)})
    if 'index.html' not in raw:raise SystemExit('Existing ZIP has no root index.html')

with zipfile.ZipFile(patch) as z:
    if z.testzip() is not None:raise SystemExit('Patch ZIP corrupt')
    names=z.namelist()
    if len(names)!=len(set(names)):raise SystemExit('Duplicate patch entries')
    payload={n[8:]:z.read(n) for n in names if n.startswith('payload/') and not n.endswith('/')}
    section=z.read('tera-home-section.html').decode('utf-8')
    receiver_hero=z.read('receiver-hero-section.html').decode('utf-8')

# Protect production identity and billing config from accidental patch collision.
protected={'buy.html','purchase.js','commercial-config.json','releases/latest.json','help-content.js','help.html','download-release.js','release.js'}
if set(payload)&protected:raise SystemExit('Patch attempted to overwrite BrakeMonster production file')
for name, body in payload.items():
    if name.startswith('/') or '..' in Path(name).parts or '\\' in name:raise SystemExit('Unsafe path: '+name)
    if name.startswith('teraphon/receivers/') and name in raw:
        continue # Preserve existing receiver binaries and docs if newer.
    if name.startswith('assets/teraphon-receivers-') and name in raw:
        continue # Preserve current hero if already published.
    if name=='teraphon/app-release.json' and name in raw:
        # Preserve any pre-existing, independently verified release metadata.
        # Replace earlier unavailable/null metadata with the official GitHub release checker.
        try:
            import json
            older=json.loads(raw[name]); newer=json.loads(body)
            if older.get('available') is True and older.get('signed') is True and older.get('apkUrl') and older.get('sha256'):
                continue
        except Exception:
            pass
    raw[name]=body

index=raw['index.html'].decode('utf-8'); original=index
main=re.search(r'<main\b[^>]*>',index,re.I)
if not main:raise SystemExit('Current index has no main tag')
if '<!-- TERAPHON-HOMEPAGE-RECEIVERS-START -->' not in index and 'id="teraphon-home-receivers"' not in index:
    pos=main.end()
    index=index[:pos]+'\n'+receiver_hero+'\n'+index[pos:]
# Move the new section before BrakeMonster but after existing Receiver hero.
index=re.sub(r'<!-- TERAPHON-STORE-START -->.*?<!-- TERAPHON-STORE-END -->\s*','',index,flags=re.S)
location=index.find('<section class="stage"')
if location<0: location=index.find('<section class="stage ')
if location<0:
    # Most templates place BrakeMonster at the first h1/stage section.
    match=re.search(r'<section[^>]*\bclass=["\'][^"\']*\bstage\b',index)
    if match:location=match.start()
if location<0:
    location=index.find('</main>')
    if location<0:raise SystemExit('Cannot locate main content end')
index=index[:location]+section+'\n'+index[location:]

if 'data-tph-receivers-home-css' not in index:
    idx=index.lower().find('</head>')
    index=index[:idx]+'<link rel="stylesheet" href="/assets/teraphon-receivers-home.css" data-tph-receivers-home-css>\n'+index[idx:]
if 'data-tph-receivers-home-js' not in index:
    idx=index.lower().rfind('</body>')
    index=index[:idx]+'<script defer src="/assets/teraphon-receivers-home.js" data-tph-receivers-home-js></script>\n'+index[idx:]
if 'data-teraphon-commerce="css"' not in index:
    idx=index.lower().find('</head>')
    if idx<0:raise SystemExit('No head close')
    index=index[:idx]+'<link rel="stylesheet" href="/assets/tera-site.css" data-teraphon-commerce="css">\n'+index[idx:]
if 'data-teraphon-commerce="js"' not in index:
    idx=index.lower().rfind('</body>')
    if idx<0:raise SystemExit('No body close')
    index=index[:idx]+'<script src="/assets/tera-site.js" defer data-teraphon-commerce="js"></script>\n'+index[idx:]
if 'class="tera-header-link tera-header-highlight"' not in index:
    m=re.search(r'<nav\b[^>]*>.*?</nav>',index,re.I|re.S)
    if not m:raise SystemExit('No navbar')
    nav=m.group(0)
    extra='<a class="tera-header-link" href="/teraphon/" data-tera="nav">TERAPHON</a><a class="tera-header-link tera-header-highlight" href="/teraphon/plans/" data-tera="planNav">TERAPHON PLANS</a>'
    nav=nav.replace('</nav>',extra+'</nav>')
    index=index[:m.start()]+nav+index[m.end():]
if 'data-tera-return' not in index:
    m=re.search(r'<main\b[^>]*>',index,re.I)
    index=index[:m.end()]+'<div class="tera-announcement tera-width" role="status" aria-live="polite" data-tera-return></div>\n'+index[m.end():]
index=re.sub(r'<title>[^<]*</title>','<title>TERAPHONIA · TERAPHON Music Player & BrakeMonster PRO</title>',index,count=1,flags=re.I)
index=re.sub(r'<meta name="description" content="[^"]*"','<meta name="description" content="TERAPHON Android music player: 7-day trial, three-device license, wireless Windows and Android Receivers. BrakeMonster PRO remains available separately."',index,count=1,flags=re.I)
raw['index.html']=index.encode('utf-8')

# Optional label clarification: the original Android APK link is BrakeMonster, not TERAPHON.
if 'language.js' in raw:
    src=raw['language.js'].decode('utf-8')
    # Add French as a sixth language choice in the existing header without
    # changing the user's stored language preference or original help content.
    src=src.replace("['en','cnr','de','it','es'];", "['en','cnr','de','it','es','fr'];", 1)
    src=src.replace("['English','Crnogorski','Deutsch','Italiano','Español'];", "['English','Crnogorski','Deutsch','Italiano','Español','Français'];", 1)
    src=src.replace("es:['INICIO','APP ANDROID','PLANES PRO','AYUDA']};", "es:['INICIO','APP ANDROID','PLANES PRO','AYUDA'],fr:['ACCUEIL','BRAKEMONSTER','OFFRES BM','AIDE']};",1)
    src=src.replace("'ANDROID APP'","'BRAKEMONSTER'").replace("'APP ANDROID'","'BRAKEMONSTER'")
    src=src.replace("'PRO PLANS'","'BM PLANS'").replace("'PRO PLANOVI'","'BM PLANOVI'").replace("'PRO-TARIFE'","'BM-TARIFE'").replace("'PIANI PRO'","'PIANI BM'").replace("'PLANES PRO'","'PLANES BM'")
    raw['language.js']=src.encode('utf-8')

for name,h in saved.items():
    if hashlib.sha256(raw[name]).hexdigest()!=h:raise SystemExit('Protected BrakeMonster file changed: '+name)
if index.count('TERAPHON-STORE-START')!=1:raise SystemExit('Store section duplicated')
if index.count('data-tera-return')!=1:raise SystemExit('Purchase-return banner duplicated')
if 'teraphon/receivers/index.html' not in raw:raise SystemExit('Receiver page missing')

# Zip coherency and atomic replacement
with tempfile.NamedTemporaryFile(dir=site.parent,suffix='.zip',delete=False) as f:
    tmp=Path(f.name)
try:
    with zipfile.ZipFile(tmp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
        z.comment=comment
        for name,b in raw.items():z.writestr(name,b,compress_type=zipfile.ZIP_DEFLATED)
    with zipfile.ZipFile(tmp) as z:
        if z.testzip() is not None:raise SystemExit('Merged ZIP testzip failed')
    os.replace(tmp,site)
except Exception:
    tmp.unlink(missing_ok=True)
    raise
print('SUCCESS:',site,'files=',len(raw),'bytes=',site.stat().st_size,'original_homepage_bytes=',len(original),'patched_bytes=',len(index))

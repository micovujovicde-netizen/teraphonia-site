"""Apply the Android Receiver download and help update to the current site archive."""
from hashlib import sha256
from pathlib import Path
import json
import os
import sys
import tempfile
from zipfile import ZipFile, ZIP_DEFLATED

site, patch = map(Path, sys.argv[1:3])
with ZipFile(patch) as payload:
    expected = json.loads(payload.read('expected.json'))
    replacements = {name: payload.read('receiver-update/' + name) for name in expected}

with ZipFile(site) as existing:
    names = set(existing.namelist())
    changed = set()
    for name, checksum in expected.items():
        old = existing.read(name) if name in names else None
        if old == replacements[name]:
            continue
        if (None if old is None else sha256(old).hexdigest()) != checksum:
            raise SystemExit('Current site content changed since review: ' + name)
        changed.add(name)
    if not changed:
        print('Android Receiver Basic and help already current.')
        raise SystemExit(0)
    with tempfile.NamedTemporaryFile(dir=site.parent, suffix='.zip', delete=False) as temporary:
        output = Path(temporary.name)
    try:
        with ZipFile(output, 'w', ZIP_DEFLATED) as updated:
            updated.comment = existing.comment
            for member in existing.infolist():
                name = member.filename
                updated.writestr(member, replacements[name] if name in changed else existing.read(member))
            for name in changed - names:
                updated.writestr(name, replacements[name])
        with ZipFile(output) as updated:
            if updated.testzip() is not None:
                raise SystemExit('Merged site ZIP integrity check failed')
        os.replace(output, site)
    finally:
        output.unlink(missing_ok=True)
print('Updated Android Receiver Basic APK and localized help.')

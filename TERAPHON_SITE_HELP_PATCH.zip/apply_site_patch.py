#!/usr/bin/env python3
"""Safely merge TERAPHON help and user-supplied product art into the latest site ZIP.
No third-party Python dependencies. Existing unknown files and release manifests are preserved.
"""
import json, re, sys, tempfile, zipfile
from pathlib import Path

ARCHIVE=Path(sys.argv[1]) if len(sys.argv)>1 else Path('TERAPHONIA_Website.zip')
PATCH=Path(sys.argv[2]) if len(sys.argv)>2 else Path('TERAPHON_SITE_HELP_PATCH.zip')
ALLOWED_NEW={'teraphon/help/help.js','teraphon/help/guide.json',
             'assets/teraphon-monthly-1x1.png','assets/teraphon-yearly-1x1.png','assets/teraphon-lifetime-1x1.png'}
ALLOWED_REPLACE={'index.html','teraphon/help/index.html','teraphon/download/index.html',
                 'teraphon.css','teraphon.js','teraphon-i18n.json','teraphon-product.json'}
with zipfile.ZipFile(ARCHIVE) as original, zipfile.ZipFile(PATCH) as updates:
    original_paths=original.namelist()
    if len(original_paths)!=len(set(original_paths)):raise SystemExit('Duplicate paths in website ZIP')
    existing={name:original.read(name) for name in original_paths if not name.endswith('/')}
    def payload(path):return updates.read(path).decode('utf-8')
    for required in ALLOWED_REPLACE:
        if required not in existing:raise SystemExit('Site archive missing '+required)
    def txt(name):return existing[name].decode('utf-8')
    def put(name,text):existing[name]=text.encode('utf-8')

    # Add only approved originals and content files; never place patch scripts into public website.
    for key in ('monthly','yearly','lifetime'):
        public=f'assets/teraphon-{key}-1x1.png'
        existing[public]=updates.read(public)
    existing['teraphon/help/guide.json']=updates.read('template/guide.json')
    existing['teraphon/help/help.js']=updates.read('template/help.js')

    # Preserve the latest header and footer, replacing only the outdated TERAPHON HELP main.
    html=txt('teraphon/help/index.html');begin=html.find('<main id="main">');end=html.find('<footer>',begin)
    if begin<0 or end<0:raise SystemExit('TERAPHON help page changed: refusing overwrite')
    startline=html.rfind('\n',0,begin)+1
    endline=html.rfind('\n',0,end)+1
    main=payload('template/help-main.html')
    html=html[:startline]+main+html[endline:]
    script='<script src="/teraphon/help/help.js" defer></script>'
    if script not in html:
        match=re.search(r'<script\s+src="/teraphon.js"\s+defer\s*>\s*</script>',html)
        if not match:raise SystemExit('TERAPHON script reference not found in help page')
        html=html[:match.end()]+'\n    '+script+html[match.end():]
    put('teraphon/help/index.html',html)

    # Add user pictures to each plan card; keep all existing homepage layout changes.
    index=txt('index.html')
    for key,alt in [('monthly','Monthly plan — €3.50 per month'),('yearly','Yearly plan — €30 per year'),('lifetime','Lifetime plan — €60 once')]:
        path=f'/assets/teraphon-{key}-1x1.png'
        if path in index:continue
        img=f'<img class="price-art" src="{path}" alt="TERAPHON {alt}" width="1536" height="1536" loading="lazy" decoding="async">'
        pattern=r'(<article\s+class="price-plan"\s*>)(\s*)(<h3\s+data-i18n="'+key+r'")'
        index,count=re.subn(pattern,lambda m:m.group(1)+'\n            '+img+m.group(2)+m.group(3),index,count=1)
        if count!=1:raise SystemExit('Pricing card '+key+' not found; refusing to overwrite current index')
    # Link each existing TERAPHON plan to the matching Android purchase handler.
    for key in ('monthly','yearly','lifetime'):
        pattern=r'(<article\b[^>]*class="price-plan"[^>]*>)(.*?)(</article>)'
        def link_card(match):
            opening,body,closing=match.groups()
            if not re.search(r'data-i18n="'+key+r'"',body):return match.group(0)
            anchor='tera-plan-'+key
            if 'id="'+anchor+'"' not in opening:
                if re.search(r'\bid=',opening):raise SystemExit('Existing price card ID conflicts: '+key)
                opening=opening[:-1]+' id="'+anchor+'">'
            if 'data-tera-purchase="'+key+'"' not in body:
                link='<a class="tera-plan-buy" data-tera-purchase="'+key+'" data-i18n="tera_continue_purchase" href="intent://purchase/'+key+'#Intent;scheme=teraphonia;package=com.teraphonia.music;S.browser_fallback_url=https%3A%2F%2Fteraphonia.com%2Fteraphon%2Fdownload%2F;end">CONTINUE IN TERAPHON</a>'
                body=body.rstrip()+'\n            '+link+'\n          '
            return opening+body+closing
        index=re.sub(pattern,link_card,index,flags=re.S)
        if index.count('id="tera-plan-'+key+'"')!=1 or index.count('data-tera-purchase="'+key+'"')!=1:
            raise SystemExit('Unable to link TERAPHON plan '+key)
    put('index.html',index)

    # Keep CSS additions isolated and responsive. No changes to BrakeMonster styling.
    style=txt('teraphon.css');start='/* === TERAPHON HELP MOBILE PATCH START === */';end='/* === TERAPHON HELP MOBILE PATCH END === */'
    addition=payload('template/style-extra.css')
    if start in style:
        if end not in style:raise SystemExit('Corrupt style patch markers')
        style=style[:style.index(start)].rstrip('\n')+'\n'+addition.rstrip('\n')+'\n'+style[style.index(end)+len(end):].lstrip('\n')
    else:style=style.rstrip('\n')+'\n'+addition.rstrip('\n')+'\n'
    put('teraphon.css',style)

    # Always allow French in TERAPHON (never change BrakeMonster's separate language system).
    for file in ('index.html','teraphon/download/index.html','teraphon/help/index.html'):
        data=txt(file)
        if '<option value="fr">FR</option>' not in data:
            if '<option value="es">ES</option>' not in data:raise SystemExit('Language select changed in '+file)
            data=data.replace('<option value="es">ES</option>','<option value="es">ES</option>\n            <option value="fr">FR</option>',1)
        put(file,data)
    js=txt('teraphon.js')
    m=re.search(r'const supported\s*=\s*\[([^\]]+)\];',js)
    if not m:raise SystemExit('Language list not found in teraphon.js')
    if "'fr'" not in m.group(1):
        js=js[:m.start()]+m.group(0).replace('];',", 'fr'];")+js[m.end():]
    if "URLSearchParams(location.search)" not in js:
        find="      const saved = localStorage.getItem('bm-site-language');"
        if find not in js:raise SystemExit('Language preference code changed')
        js=js.replace(find,"      const requested = new URLSearchParams(location.search).get('lang');\n      if (supported.includes(requested)) return requested;\n"+find,1)
    put('teraphon.js',js)
    di=json.loads(txt('teraphon-i18n.json'))
    french=json.loads(payload('template/french.json'))
    di['fr']={**di['en'],**french}
    prices=json.loads(payload('template/pricing-text.json'))
    for lang,values in prices.items():
        if lang in di:di[lang].update(values)
    put('teraphon-i18n.json',json.dumps(di,ensure_ascii=False,indent=2)+'\n')

    # Update only plan amounts; NEVER change billing, checkout, API or licence status.
    prod=json.loads(txt('teraphon-product.json'));amount={'monthly':3.5,'yearly':30,'lifetime':60}
    for item in prod.get('plans',[]):
        if item.get('id') in amount:item['price']=amount[item['id']]
    put('teraphon-product.json',json.dumps(prod,ensure_ascii=False,indent=2)+'\n')

    names_after=set(existing)
    if names_after-set(original_paths)-ALLOWED_NEW:
        raise SystemExit('Unexpected new paths: '+str(names_after-set(original_paths)-ALLOWED_NEW))
    if not ALLOWED_NEW.issubset(names_after):
        raise SystemExit('Missing expected TERAPHON patch files')
    if not (set(original_paths)-names_after)<=set():
        raise SystemExit('A file was deleted')
    changed={name for name in existing if name in original_paths and existing[name]!=original.read(name)}
    if changed-ALLOWED_REPLACE:raise SystemExit('Unexpected changes to '+str(changed-ALLOWED_REPLACE))
    for must in ('brakemonster-pro/index.html','buy.html','releases/latest.json','release.js','commercial-config.json'):
        if existing[must]!=original.read(must):raise SystemExit('Protected BrakeMonster file changed: '+must)
    tmp=ARCHIVE.with_suffix('.patched.zip')
    with zipfile.ZipFile(tmp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as out:
        for name in sorted(existing):out.writestr(name,existing[name])
    with zipfile.ZipFile(tmp) as check:
        if check.testzip() is not None:raise SystemExit('ZIP failed integrity check')
        if not set(original_paths).issubset(set(check.namelist())):raise SystemExit('Missing original file')
    tmp.replace(ARCHIVE)
    print('PATCH OK: 6-language HELP + 3 original square product images; all unrelated site files retained.')

"""Replace the Android Receiver download and its manifest entry."""
import hashlib
import json
import pathlib
import sys
import tempfile
import zipfile

NAME = "TERAPHON RECEIEVER.APK"
APK_PATH = "teraphon/receivers/downloads/" + NAME
MANIFEST_PATH = "teraphon/receivers/manifest.json"
OLD_SHA = "888a4b415843953360071ceeb3f84288c817c3ca527a21863997908af5af74f7"
NEW_SHA = "761d16a659c6f9a1a6efe9f236dea06238edc0e57c906885bada2759ae32109b"

def digest(data):
    return hashlib.sha256(data).hexdigest()

def main(site, patch):
    with zipfile.ZipFile(patch) as payload:
        apk = payload.read(NAME)
    if digest(apk) != NEW_SHA:
        raise SystemExit("Incorrect signed Receiver APK")
    with zipfile.ZipFile(site) as original:
        if digest(original.read(APK_PATH)) not in {OLD_SHA, NEW_SHA}:
            raise SystemExit("The existing Receiver download has changed")
        manifest = json.loads(original.read(MANIFEST_PATH))
        entries = [item for item in manifest["assets"] if item.get("file") == NAME]
        if len(entries) != 1:
            raise SystemExit("Expected one Android Receiver manifest entry")
        entries[0].update(bytes=len(apk), sha256=NEW_SHA, versionName="1.10", versionCode=11)
        replacements = {
            APK_PATH: apk,
            MANIFEST_PATH: (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode(),
        }
        with tempfile.NamedTemporaryFile(dir=site.parent, prefix=".receiver-", suffix=".zip", delete=False) as f:
            temporary = pathlib.Path(f.name)
        try:
            with zipfile.ZipFile(temporary, "w") as updated:
                for info in original.infolist():
                    data = replacements[info.filename] if info.filename in replacements else original.read(info)
                    updated.writestr(info, data)
            with zipfile.ZipFile(temporary) as verified:
                if verified.testzip() is not None or verified.read(APK_PATH) != apk:
                    raise SystemExit("Updated website ZIP failed validation")
            temporary.replace(site)
        finally:
            temporary.unlink(missing_ok=True)

if __name__ == "__main__":
    main(*map(pathlib.Path, sys.argv[1:]))


(()=>{'use strict';
const API='https://teraphon-license.micovujovic-de.workers.dev/v1';
const STORE='https://www.creem.io/stores/teraphonia';
const LANGS=['en','cnr','de','it','es','fr'];
const defaultEn={nav:'TERAPHON',planNav:'TERAPHON PLANS',statusPending:'Checking secure checkout availability…',statusOff:'Checkout is not yet open. No payment will start.',statusReady:'Secure checkout is enabled. Final prices are on Creem.',statusDown:'Checkout cannot be verified. Payments remain disabled.',checkoutOff:'NOT YET AVAILABLE',checkoutReady:'SELECT ON CREEM',checkoutApp:'SECURE CHECKOUT',apkNotReady:'TERAPHON.APK is not yet available as a public release.',apkReady:'TERAPHON.APK is published on GitHub.',downloadApk:'TERAPHON.APK',onPayment:'Creem is verifying your payment. Check email for an activation code after confirmation.'};
let translations={en:defaultEn}, active='en';
function findLang(){let v='auto';try{v=localStorage.getItem('bm-site-language')||'auto'}catch(_){}if(LANGS.includes(v))return v;const arr=navigator.languages||[navigator.language||'en'];for(const l of arr){const k=String(l).toLowerCase().split('-')[0];if(['sr','bs','hr','me','sh'].includes(k))return 'cnr';if(LANGS.includes(k))return k;}return 'en'}
function tt(k){return translations[active]?.[k]||translations.en?.[k]||defaultEn[k]||k}
function updateLang(){active=findLang();document.querySelectorAll('[data-tera]').forEach(el=>{let k=el.getAttribute('data-tera');const value=tt(k);if(value!==k)el.textContent=value});document.querySelectorAll('.tera-lang select').forEach(el=>{if(el.value!==active)el.value=active});document.documentElement.lang=active==='cnr'?'cnr-ME':active;
const status=document.querySelector('[data-tera-status]');if(status&&status.dataset.teraHealth)status.textContent=tt(status.dataset.teraHealth);const announce=document.querySelector('[data-tera-return]');if(announce)announce.textContent=tt('onPayment');}
async function getHealth(){const controller=new AbortController();const tid=setTimeout(()=>controller.abort(),10000);try{const r=await fetch(API+'/health',{cache:'no-store',mode:'cors',signal:controller.signal});if(!r.ok)throw Error('status');const j=await r.json();if(j.status!=='online'||j.productConfigured!==true||j.billingEnabled!==true)return 'statusOff';return 'statusReady'}catch(_){return 'statusDown'}finally{clearTimeout(tid)}}
function safeURL(u){try{const q=new URL(u);return q.protocol==='https:'&&!q.username&&!q.password&&!q.port&&(q.hostname==='creem.io'||q.hostname.endsWith('.creem.io'))}catch(_){return false}}
let activePurchaseToken=null;
function stripPurchaseToken(){const match=new URLSearchParams(location.hash.replace(/^#/,''));const raw=match.get('device');if(/^[a-f0-9]{64}$/.test(raw||''))activePurchaseToken=raw; if(location.hash.includes('device='))history.replaceState(null,'',location.pathname+location.search)}
async function checkout(plan,button){const original=button.textContent;button.disabled=true;try{const r=await fetch(API+'/checkout',{method:'POST',mode:'cors',headers:{'Authorization':'Bearer '+activePurchaseToken,'Content-Type':'application/json'},body:JSON.stringify({plan}),signal:AbortSignal.timeout(16000),cache:'no-store'});if(!r.ok)throw Error('Checkout disabled');const data=await r.json();if(!safeURL(data.url))throw Error('Untrusted payment URL');location.assign(data.url);return;}catch(_){const status=document.querySelector('[data-tera-status]');if(status){status.dataset.teraHealth='statusDown';status.textContent=tt('statusDown')}button.disabled=false;button.textContent=original;}}
async function initPlans(){const buttons=[...document.querySelectorAll('.tera-buy[data-plan]')];const status=document.querySelector('[data-tera-status]');if(!buttons.length&&!status)return;stripPurchaseToken();const result=await getHealth();if(status){status.dataset.teraHealth=result;status.textContent=tt(result)}buttons.forEach(b=>{b.disabled=result!=='statusReady';b.setAttribute('aria-disabled',String(b.disabled));b.dataset.tera=result==='statusReady'?(activePurchaseToken?'checkoutApp':'checkoutReady'):'checkoutOff';b.textContent=tt(b.dataset.tera);if(!b.disabled)b.addEventListener('click',()=>{if(activePurchaseToken)checkout(b.dataset.plan,b);else location.assign(STORE)});});}
async function initAPK(){
const badge=document.querySelector('[data-tera-apk-status]');
const link=document.querySelector('[data-tera-apk-link]');
if(!badge)return;
if(link){link.hidden=true;link.removeAttribute('href');}
try{
 const mr=await fetch('/teraphon/app-release.json',{cache:'no-store'});
 if(!mr.ok)throw Error('manifest');
 const manifest=await mr.json();
 if(manifest.product!=='TERAPHON Android'||manifest.assetName!=='TERAPHON.APK'||
    !/^https:\/\/api\.github\.com\/repos\/micovujovicde-netizen\/TERAPHONIA-Android\/releases\/latest$/.test(manifest.releaseApi||''))throw Error('config');
 const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),12000);
 let release;
 try{
   const response=await fetch(manifest.releaseApi,{cache:'no-store',headers:{'Accept':'application/vnd.github+json'},signal:controller.signal});
   if(!response.ok)throw Error('unpublished');
   release=await response.json();
 }finally{clearTimeout(timeout)}
 if(release.draft||release.prerelease)throw Error('not public production');
 const asset=(release.assets||[]).find(a=>a.name==='TERAPHON.APK'&&a.state==='uploaded'&&a.size>1000000);
 if(!asset)throw Error('asset not published');
 // The asset URL must come from the official GitHub repo, never from untrusted metadata.
 const u=new URL(asset.browser_download_url);
 if(u.protocol!=='https:'||u.hostname!=='github.com'||
    !/^\/micovujovicde-netizen\/TERAPHONIA-Android\/releases\/download\/[A-Za-z0-9._-]+\/TERAPHON\.APK$/.test(u.pathname))throw Error('asset URL');
 // GitHub's digest, when populated, lets us reject an asset different from the user's checksum.
 const digest=String(asset.digest||'').toLowerCase();
 if(digest&& !/^sha256:[a-f0-9]{64}$/.test(digest))throw Error('digest format');
 if(digest&&manifest.sha256&&digest!=='sha256:'+manifest.sha256)throw Error('release SHA-256 mismatch');
 badge.dataset.tera='apkReady';badge.textContent=tt('apkReady');
 if(link){link.href=u.href;link.hidden=false;link.textContent='TERAPHON.APK';link.setAttribute('aria-label','Download TERAPHON.APK from the official GitHub Release');}
}catch(_){badge.dataset.tera='apkNotReady';badge.textContent=tt('apkNotReady');if(link)link.hidden=true;}
}
async function init(){const fullRoot=document.querySelector('body:not(.tera-page)');if(fullRoot){const oldSelect=document.querySelector('.language-picker select');if(oldSelect&&!Array.from(oldSelect.options).some(o=>o.value==='fr')){let opt=document.createElement('option');opt.value='fr';opt.textContent='Français';oldSelect.add(opt)}}document.querySelectorAll('.tera-lang select').forEach(sel=>{sel.value=findLang();sel.addEventListener('change',()=>{try{localStorage.setItem('bm-site-language',sel.value)}catch(_){}updateLang();document.dispatchEvent(new Event('tera-language-change'))})});try{const r=await fetch('/assets/tera-i18n.json');if(r.ok){const obj=await r.json();if(obj&&obj.en)translations=obj}}catch(_){}updateLang();window.addEventListener('bm-language-change',updateLang);document.querySelector('.language-picker select')?.addEventListener('change',updateLang);
if(new URLSearchParams(location.search).get('purchase')==='teraphon'){const el=document.querySelector('[data-tera-return]');if(el){el.classList.add('visible');el.textContent=tt('onPayment')}}await Promise.all([initPlans(),initAPK()]);}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();

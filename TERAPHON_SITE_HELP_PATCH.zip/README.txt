TERAPHON website patch — 6-language HELP and original 1:1 plan images.
Safe merge: apply_site_patch.py updates only TERAPHON HTML/JS/CSS/JSON and keeps all other site archive files unchanged.
Use TERAPHONIA_SITE_PATCH_APPLY.yml in .github/workflows/ and upload this archive to the repository root as TERAPHON_SITE_HELP_PATCH.zip.
No Cloudflare, Creem, BrakeMonster, or release configuration is changed.

Android v0.2.188 linked plans: all three price cards receive stable anchors and localized links back into the TERAPHON app for authenticated checkout. Billing remains unchanged. The same existing TERAPHONIA_SITE_PATCH_APPLY workflow applies this replacement patch.

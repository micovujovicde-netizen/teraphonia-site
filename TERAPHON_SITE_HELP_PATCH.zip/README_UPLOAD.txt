TERAPHONIA — odvojene stranice za TERAPHON i BrakeMonster PRO

U repozitorijumu micovujovicde-netizen/teraphonia-site zamijeni
TERAPHON_SITE_HELP_PATCH.zip ovim ZIP-om. Postojeći GitHub Actions
workflow „TERAPHON — apply HELP and product images” primjenjuje ga
na TERAPHONIA_Website.zip. Arhiva se učitava kao ZIP, bez raspakivanja.

Početna stranica prikazuje TERAPHON, njegove planove i Receivere.
MENI vodi na zasebnu stranicu BrakeMonster PRO i njegove planove.
Kupovina TERAPHON plana počinje u aplikaciji. Posjetilac koji dođe
iz pregledača ide na uputstvo za instalaciju i kupovinu u aplikaciji.

Ovo je patch za sajt. APK i source ZIP aplikacije imaju odvojen build.

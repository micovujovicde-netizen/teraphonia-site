TERAPHONIA — CLOUDFLARE R2 DIRECT APK DOWNLOAD

Official download URL:
https://download.teraphonia.com/TERAPHON.APK

Upload this archive as TERAPHON_SITE_HELP_PATCH.zip to repository root:
https://github.com/micovujovicde-netizen/teraphonia-site
Replace the existing file; the existing GitHub Action applies the patch and deploys the updated site.

The download page now opens the R2 URL directly. It never calls the GitHub API or opens the GitHub app.
All six languages use accurate direct-download messages.
The website manifest uses R2; it DOES NOT claim to verify the uploaded R2 APK file SHA256 or signature.
To change the APK later, upload a new signed TERAPHON.APK to Cloudflare R2 bucket teraphon-downloads under the same object name. The website URL remains stable.
BrakeMonster production billing and receivers are not modified.

TERAPHONIA — TERAPHON COMMERCIAL WEBSITE UPDATE
============================================

Upload this ZIP to GitHub repository micovujovicde-netizen/teraphonia-site
with the EXACT name:

    TERAPHON_SITE_HELP_PATCH.zip

It replaces the old patch archive. Your existing workflow
"TERAPHON — apply HELP and product images" will run automatically.
That workflow merges this patch into the CURRENT TERAPHONIA_Website.zip,
commits the canonical website ZIP and triggers the existing deploy.yml.

IMPORTANT
- Do NOT replace TERAPHONIA_Website.zip with this small patch.
- Do NOT upload both names (1).zip or (2).zip. File name must be exact.
- This patch PRESERVES existing BrakeMonster buy.html, purchase.js,
  commercial-config.json, release metadata, prices, and help pages.
- It PRESERVES existing receiver downloads and assets if already present,
  and restores them if missing.
- When applied repeatedly, it does not duplicate the TERAPHON section.

NEW PAGES
  /teraphon/            product overview
  /teraphon/plans/      3 plans + safe Creem connection
  /teraphon/help/       7 topics and support
  /teraphon/download/   official app release check + Receiver downloads
  /teraphon/receivers/ existing receivers

PRICE AND TRIAL
  €3.50 monthly, €30 yearly, €60 lifetime, 7 days without card,
  1 activation code for up to 3 Android devices.

6 LANGUAGES: English, Crnogorski, Deutsch, Italiano, Español, Français.

LIVE PAYMENT GATE
  The three plan buttons query TERAPHON License Worker /v1/health.
  They remain disabled while billingEnabled=false or the Worker is offline.
  When billingEnabled=true:
    - If opened from the app with #device=<token>, browser calls
      the protected /v1/checkout for a chosen plan and then Creem.
    - In a normal browser without a device token, the button opens
      the official Creem storefront, where the user chooses the plan.
  A Creem signed paid webhook, not this page, grants the licence and
  can email an activation code. End-to-end live mail is NOT verified yet.

APK SAFETY
  No verified signed current TERAPHON app APK was provided in this turn.
  /teraphon/app-release.json therefore correctly has available=false.
  It must only be marked available=true with a genuine signed APK link,
  versionCode, and SHA256 from a verified release.
  Do not republish an invalid old APK or confuse Receiver APK with app APK.

ADDITIONAL NOTES
  - LIVE billing currently OFF by user choice; do not change that until
    a complete checkout, webhook, license and email test passes.
  - Future GitHub Worker deployments must preserve the Cloudflare email and
    billing variables; review generated wrangler.toml before re-deploy.
  - Receiver ZIP and image links remain.
  - No API keys or personal secret values are included.

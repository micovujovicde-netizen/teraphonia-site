TERAPHON WEBSITE — PANORAMIC BANNER + CURRENT COMMERCIAL COPY

Upload TERAPHON_SITE_HELP_PATCH.zip to the existing public GitHub repository
https://github.com/micovujovicde-netizen/teraphonia-site
and replace the same named ZIP. The existing Action merges and deploys it.

Changed:
- Replaced placeholder note + TERAPHON with the user-approved panoramic woman/tablet/laptop/receiver/speakers image.
- Corrected out-of-date statements about billing not being enabled (six languages).
- Corrected the FAQ implying the TERAPHON.APK was still unpublished.
- Removed the initially visible 'NOT YET AVAILABLE' text on pricing buttons; status is still checked dynamically.
- Added a verified public GitHub APK download link as fallback when GitHub API is rate-limited.
- Aligned homepage TERAPHON language with selected website header language, if available.
- Left BrakeMonster billing, payment code, licenses, receivers and other releases untouched.

GitHub published APK URL:
https://github.com/micovujovicde-netizen/teraphonia-site/releases/download/teraphon-android/TERAPHON.APK
SHA256: 336b9bfa947d2e25c1fdbfb8aad498c6a908ab5d55068bd1a10c427bffbe137b

Note: billing status is still checked via the Worker at checkout; a live paid transaction and activation email delivery have not been independently verified.

NOV 23 LIVE TEXT CORRECTION: Remove obsolete LIVE billing copy from old homepage sections; do not touch BrakeMonster billing.

TERAPHONIA WEBSITE — TERAPHON first, BrakeMonster in MENU

Upload this zip as TERAPHON_SITE_HELP_PATCH.zip in the public
micovujovicde-netizen/teraphonia-site repository (replace the existing file).
The existing "TERAPHON — apply HELP and product images" GitHub Action reads
apply_site_patch.py from the archive and updates TERAPHONIA_Website.zip.

What this patch does:
- Removes BrakeMonster ads, pricing cards, download CTA from the main homepage.
- Adds mobile-accessible MENU with BrakeMonster PRO and its separate pricing.
- Preserves old BrakeMonster homepage material at /brakemonster/.
- Makes root nav/footers TERAPHON-first; adds direct TERAPHON APK CTA.
- Fixes critical wrong-product checkout: browser-only TERAPHON plan buttons no
  longer open the shared Creem store (where a user can buy BrakeMonster by mistake).
  They instead direct to TERAPHON app download. In-app checkout remains unchanged.
- Preserves BrakeMonster production payment, files, licences and existing Receivers.
- Works repeatedly and across 320-412dp mobile layouts without duplicated menu.

Important: The website's direct browser checkout is not currently configured
as a product-specific TERAPHON-only checkout. Buying in the TERAPHON app
is required until that is implemented safely. Never fabricate device tokens
in the browser because that may take one of three real-device license slots.

This zip is a WEBSITE PATCH, not an Android source archive or APK.

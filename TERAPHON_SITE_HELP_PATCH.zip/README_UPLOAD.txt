TERAPHON WEBSITE — LATEST PUBLIC APK DOWNLOAD

Upload as TERAPHON_SITE_HELP_PATCH.zip to the ROOT of:
https://github.com/micovujovicde-netizen/teraphonia-site
Replace existing file with the same name; the existing "apply HELP and product images" action merges it into the canonical website ZIP and deploys.

Official publicly published APK:
https://github.com/micovujovicde-netizen/teraphonia-site/releases/download/teraphon-android/TERAPHON.APK
SHA-256 at patch creation: 4ced427ef1afd1175d541a060b074df0ca8947c99bb50c98e12c92085d166b16

Fixes: removes stale pinned SHA condition from website availability checker; retains official GitHub release URL and strictly validates the published destination and digest syntax; refreshes cached website JS; corrects app-release.json digest.
Does not modify BrakeMonster purchase system, TERAPHON billing secrets, or receiver binaries.

# TERAPHONIA website

Static launch-ready informational landing page. No payment processing or data collection is enabled.

## Deploy via GitHub Pages

1. Create a public GitHub repository (for example `teraphonia-site`).
2. Upload `index.html` at the repository root.
3. Under **Settings → Pages**, choose **Deploy from a branch**, branch `main`, folder `/ (root)`.
4. After the default GitHub Pages URL works, configure the custom domain `teraphonia.com` in GitHub Pages settings.
5. In Cloudflare DNS, configure the apex domain using the current official GitHub Pages DNS instructions, then configure `www` if desired. Keep the existing `playlist.teraphonia.com` Worker record unchanged.
6. Verify HTTPS and site availability before requesting Creem re-review.

Pricing and free trial are labeled *planned* until checkout, trial, and licensing are implemented and approved.

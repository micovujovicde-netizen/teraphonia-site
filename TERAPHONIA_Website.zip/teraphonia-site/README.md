# TERAPHONIA website
ZIP contains one teraphonia-site/ root. Existing deploy.yml finds its index.html and copies the whole directory into _site.
No playlist Worker or existing DNS record changes. CNAME preserves teraphonia.com.
DOWNLOAD APP resolves releases/latest.json. Until available=true it links only to truthful release status.
Version, size and immutable GitHub Release APK URL are populated from the manifest, with no per-version hardcoded website URL.
Billing is disabled in commercial-config.json and separately gated by the server.
Only enable after actual merchant, checkout, server and tablet/phone verification.
HELP has 15 topics and the existing support email. Static pages require no third-party scripts.
Future releases: use release-tools/make_manifest.py outside the public website, attach signed APK to the repository release, then publish the verified manifest at releases/latest.json via this ZIP workflow.

## Pricing display update (2026-10-29)
Public pricing: Monthly €2.99, Yearly €19.90, Lifetime €39.00 one-time. All tiers same PRO access. No trial advertised. Checkout intentionally remains disabled until Creem products, server plan mapping, entitlement verification and test purchases are confirmed. Do not set billingEnabled=true solely because this ZIP was deployed.

"use strict";
(async () => {
 const status=document.getElementById('release-status'), details=document.getElementById('release-details'), button=document.getElementById('download');
 try {
  const response=await fetch('releases/latest.json',{cache:'no-store',signal:AbortSignal.timeout(10000)});
  if(!response.ok) throw Error(); const release=await response.json();
  if(release.available!==true){status.textContent='A verified, signed public APK is not available yet. Download opens this release status; no APK is offered.';return;}
  const url=new URL(release.apkUrl);
  if(release.applicationId!=='com.teraphonia.breakmonster.pro'||!Number.isSafeInteger(release.versionCode)||release.versionCode<1||!Number.isSafeInteger(release.sizeBytes)||release.sizeBytes<1||release.sizeBytes>536870912||!/^https:\/\/github\.com\/micovujovicde-netizen\/teraphonia-site\/releases\/download\/[^?#]+\.apk$/.test(url.href)||! /^[a-f0-9]{64}$/.test(release.sha256)||typeof release.versionName!=='string') throw Error();
  status.textContent='Official Android APK: '+release.versionName;
  details.textContent='Version code '+release.versionCode+' · '+(release.sizeBytes/1048576).toFixed(1)+' MB · SHA-256: '+release.sha256;
  details.style.overflowWrap='anywhere';button.href=url.href;button.textContent='DOWNLOAD APP · '+release.versionName;
 } catch (_) { status.textContent='Release information is unavailable. Please try again later. No unverified APK is offered.'; }
})();

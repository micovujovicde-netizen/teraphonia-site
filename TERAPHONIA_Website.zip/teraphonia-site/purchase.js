"use strict";
(async()=>{
 const status=document.getElementById('purchase-status'), button=document.getElementById('checkout');
 const token=new URLSearchParams(location.hash.slice(1)).get('device');
 // Fragment is never sent to the static host. Keep it only for this page's lifetime.
 history.replaceState(null,'',location.pathname);
 try {
  const response=await fetch('commercial-config.json',{cache:'no-store'});if(!response.ok)throw Error();
  const config=await response.json();if(config.billingEnabled!==true)return;
  if(config.apiBase!=='https://api.teraphonia.com/v1')throw Error();
  const health=await fetch(config.apiBase+'/health',{cache:'no-store',signal:AbortSignal.timeout(10000)});
  if(!health.ok||(await health.json()).billingEnabled!==true)throw Error();
  if(!/^[a-f0-9]{64}$/.test(token||'')){status.textContent='Open BUY PRO from your Android app to activate this installation.';return;}
  status.textContent='Seven days free, then €3 monthly. Review the exact charge date and cancellation terms in Creem checkout before confirming.';
  button.disabled=false;button.textContent='CONTINUE TO SECURE CHECKOUT';
  button.addEventListener('click',async()=>{
   button.disabled=true;
   try {
    const r=await fetch(config.apiBase+'/checkout',{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:'{}',signal:AbortSignal.timeout(20000)});
    if(!r.ok)throw Error();const result=await r.json();const u=new URL(result.url);
    if(u.protocol!=='https:'||u.username||!(u.hostname==='creem.io'||u.hostname.endsWith('.creem.io')))throw Error();
    location.assign(u.href);
   }catch(_){status.textContent='Checkout is unavailable. No payment was initiated on this page. Please try again later.';button.disabled=false;}
  });
 }catch(_){status.textContent='Billing verification is unavailable. Checkout remains disabled.';}
})();

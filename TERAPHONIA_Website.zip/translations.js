"use strict";
window.BM_TRANSLATIONS = {
  "TERAPHONIA · BrakeMonster PRO — Your Stage. Your Monster.": {
    "cnr": "TERAPHONIA · BrakeMonster PRO — Tvoja muzika. Tvoj svijet.",
    "de": "TERAPHONIA · BrakeMonster PRO — Deine Musik. Deine Welt.",
    "it": "TERAPHONIA · BrakeMonster PRO — La tua musica. Il tuo mondo.",
    "es": "TERAPHONIA · BrakeMonster PRO — Tu música. Tu mundo."
  },
  "HOME": {
    "cnr": "POČETNA",
    "de": "STARTSEITE",
    "it": "HOME",
    "es": "INICIO"
  },
  "ANDROID APP": {
    "cnr": "ANDROID APLIKACIJA",
    "de": "ANDROID-APP",
    "it": "APP ANDROID",
    "es": "APP ANDROID"
  },
  "PRO PLANS": {
    "cnr": "PRO PLANOVI",
    "de": "PRO-TARIFE",
    "it": "PIANI PRO",
    "es": "PLANES PRO"
  },
  "HELP": {
    "cnr": "POMOĆ",
    "de": "HILFE",
    "it": "GUIDA",
    "es": "AYUDA"
  },
  "TERAPHONIA PRESENTS • BRAKEMONSTER PRO": {
    "cnr": "TERAPHONIA PREDSTAVLJA • BRAKEMONSTER PRO",
    "de": "TERAPHONIA PRÄSENTIERT • BRAKEMONSTER PRO",
    "it": "TERAPHONIA PRESENTA • BRAKEMONSTER PRO",
    "es": "TERAPHONIA PRESENTA • BRAKEMONSTER PRO"
  },
  "YOUR MUSIC.": {
    "cnr": "TVOJA MUZIKA.",
    "de": "DEINE MUSIK.",
    "it": "LA TUA MUSICA.",
    "es": "TU MÚSICA."
  },
  "YOUR CHOICE.": {
    "cnr": "TVOJ IZBOR.",
    "de": "DEINE WAHL.",
    "it": "LA TUA SCELTA.",
    "es": "TU ELECCIÓN."
  },
  "A revolution in listening to, playing and organizing music. The whole world in your hand — just a few taps from your ideal musical galaxy.": {
    "cnr": "Revolucija u slušanju, puštanju i organizovanju muzike. Cijeli svijet na dlanu — samo nekoliko tapova do vaše idealne muzičke galaksije.",
    "de": "Eine Revolution beim Musikhören, Abspielen und Organisieren. Die ganze Welt in deiner Hand — nur wenige Tipps bis zu deiner idealen Musikgalaxie.",
    "it": "Una rivoluzione nell’ascolto, nella riproduzione e nell’organizzazione della musica. Il mondo nel palmo della mano — bastano pochi tocchi per raggiungere la tua galassia musicale ideale.",
    "es": "Una revolución para escuchar, reproducir y organizar música. El mundo en la palma de tu mano — a solo unos toques de tu galaxia musical ideal."
  },
  "YOU CHOOSE THE MUSIC": {
    "cnr": "TI BIRAŠ MUZIKU",
    "de": "DU WÄHLST DIE MUSIK",
    "it": "LA MUSICA LA SCEGLI TU",
    "es": "TÚ ELIGES LA MÚSICA"
  },
  "SMOOTH AUTO MIX": {
    "cnr": "GLATKI AUTO MIX PRELAZI",
    "de": "SANFTE AUTO-MIX-ÜBERGÄNGE",
    "it": "TRANSIZIONI FLUIDE CON AUTO MIX",
    "es": "TRANSICIONES SUAVES CON AUTO MIX"
  },
  "SAVE DEVICE STORAGE": {
    "cnr": "SAČUVAJ PROSTOR NA UREĐAJU",
    "de": "SPEICHERPLATZ SPAREN",
    "it": "RISPARMIA SPAZIO SUL DISPOSITIVO",
    "es": "AHORRA ESPACIO EN TU DISPOSITIVO"
  },
  "START FREE · NO PURCHASE REQUIRED": {
    "cnr": "POČNI BESPLATNO · BEZ KUPOVINE",
    "de": "KOSTENLOS STARTEN · KEIN KAUF NÖTIG",
    "it": "INIZIA GRATIS · NESSUN ACQUISTO RICHIESTO",
    "es": "EMPIEZA GRATIS · SIN COMPRA OBLIGATORIA"
  },
  "7 DAYS FREE TRIAL": {
    "cnr": "7 DANA BESPLATNE PROBE",
    "de": "7 TAGE KOSTENLOS TESTEN",
    "it": "7 GIORNI DI PROVA GRATUITA",
    "es": "7 DÍAS DE PRUEBA GRATIS"
  },
  "ALL PRO FEATURES UNLOCKED": {
    "cnr": "SVE PRO FUNKCIJE OTKLJUČANE",
    "de": "ALLE PRO-FUNKTIONEN FREIGESCHALTET",
    "it": "TUTTE LE FUNZIONI PRO SBLOCCATE",
    "es": "TODAS LAS FUNCIONES PRO DESBLOQUEADAS"
  },
  "For eligible new devices · Trial begins when confirmed by our license server": {
    "cnr": "Za nove uređaje koji ispunjavaju uslove · Proba počinje potvrdom našeg servera za licence",
    "de": "Für berechtigte neue Geräte · Testbeginn nach Bestätigung durch unseren Lizenzserver",
    "it": "Per i nuovi dispositivi idonei · La prova inizia dopo la conferma del nostro server licenze",
    "es": "Para nuevos dispositivos que cumplan los requisitos · La prueba comienza tras la confirmación de nuestro servidor de licencias"
  },
  "↓ DOWNLOAD FOR ANDROID": {
    "cnr": "↓ PREUZMI ZA ANDROID",
    "de": "↓ FÜR ANDROID HERUNTERLADEN",
    "it": "↓ SCARICA PER ANDROID",
    "es": "↓ DESCARGAR PARA ANDROID"
  },
  "EXPLORE PRO PLANS": {
    "cnr": "POGLEDAJ PRO PLANOVE",
    "de": "PRO-TARIFE ENTDECKEN",
    "it": "SCOPRI I PIANI PRO",
    "es": "EXPLORAR PLANES PRO"
  },
  "Android phones & tablets · Official APK · 7-day PRO trial for eligible new devices · Secure Creem checkout": {
    "cnr": "Android telefoni i tableti · Zvanični APK · 7 dana PRO probe za nove uređaje koji ispunjavaju uslove · Sigurno Creem plaćanje",
    "de": "Android-Smartphones und -Tablets · Offizielle APK · 7 Tage PRO-Test für berechtigte neue Geräte · Sichere Zahlung mit Creem",
    "it": "Telefoni e tablet Android · APK ufficiale · Prova PRO di 7 giorni per nuovi dispositivi idonei · Pagamento sicuro con Creem",
    "es": "Teléfonos y tabletas Android · APK oficial · Prueba PRO de 7 días para nuevos dispositivos aptos · Pago seguro con Creem"
  },
  "ONE MONSTER. THREE WAYS TO PLAY.": {
    "cnr": "JEDAN MONSTER. TRI NAČINA ZA MUZIKU.",
    "de": "EIN MONSTER. DREI WEGE ZUR MUSIK.",
    "it": "UN MONSTER. TRE MODI DI ASCOLTARE.",
    "es": "UN MONSTER. TRES FORMAS DE ESCUCHAR."
  },
  "Choose your backstage pass.": {
    "cnr": "Izaberi svoju PRO propusnicu.",
    "de": "Wähle deinen Backstage-Pass.",
    "it": "Scegli il tuo pass per il backstage.",
    "es": "Elige tu pase de backstage."
  },
  "Try all PRO features free for 7 days": {
    "cnr": "Isprobaj sve PRO funkcije besplatno 7 dana",
    "de": "Teste alle PRO-Funktionen 7 Tage kostenlos",
    "it": "Prova gratis tutte le funzioni PRO per 7 giorni",
    "es": "Prueba gratis todas las funciones PRO durante 7 días"
  },
  "on an eligible new device. After the trial, choose a plan to keep PRO online features unlocked.": {
    "cnr": "na novom uređaju koji ispunjava uslove. Poslije probe izaberi plan da zadržiš PRO online funkcije.",
    "de": "auf einem berechtigten neuen Gerät. Wähle danach einen Tarif, um die PRO-Onlinefunktionen weiter zu nutzen.",
    "it": "su un nuovo dispositivo idoneo. Dopo la prova, scegli un piano per continuare a usare le funzioni PRO online.",
    "es": "en un nuevo dispositivo apto. Después, elige un plan para seguir usando las funciones PRO en línea."
  },
  "01 / THE DJ": {
    "cnr": "01 / DJ",
    "de": "01 / DER DJ",
    "it": "01 / IL DJ",
    "es": "01 / EL DJ"
  },
  "MONTHLY": {
    "cnr": "MJESEČNO",
    "de": "MONATLICH",
    "it": "MENSILE",
    "es": "MENSUAL"
  },
  "per month · recurring subscription": {
    "cnr": "mjesečno · pretplata koja se obnavlja",
    "de": "pro Monat · wiederkehrendes Abonnement",
    "it": "al mese · abbonamento ricorrente",
    "es": "al mes · suscripción recurrente"
  },
  "All PRO features. Pay monthly and keep the party moving.": {
    "cnr": "Sve PRO funkcije. Plaćaj mjesečno i nastavi žurku.",
    "de": "Alle PRO-Funktionen. Monatlich zahlen und weiterfeiern.",
    "it": "Tutte le funzioni PRO. Paga ogni mese e continua la festa.",
    "es": "Todas las funciones PRO. Paga cada mes y que siga la fiesta."
  },
  "VIEW MONTHLY PLAN →": {
    "cnr": "MJESEČNI PLAN →",
    "de": "MONATSTARIF ANSEHEN →",
    "it": "VEDI IL PIANO MENSILE →",
    "es": "VER PLAN MENSUAL →"
  },
  "BEST VALUE": {
    "cnr": "NAJPOVOLJNIJE",
    "de": "BESTES PREIS-LEISTUNGS-VERHÄLTNIS",
    "it": "IL PIÙ CONVENIENTE",
    "es": "MEJOR RELACIÓN CALIDAD-PRECIO"
  },
  "02 / THE HEADLINER": {
    "cnr": "02 / ZVIJEZDA VEČERI",
    "de": "02 / DER HEADLINER",
    "it": "02 / LA STAR",
    "es": "02 / LA ESTRELLA"
  },
  "YEARLY": {
    "cnr": "GODIŠNJE",
    "de": "JÄHRLICH",
    "it": "ANNUALE",
    "es": "ANUAL"
  },
  "per year · recurring subscription": {
    "cnr": "godišnje · pretplata koja se obnavlja",
    "de": "pro Jahr · wiederkehrendes Abonnement",
    "it": "all’anno · abbonamento ricorrente",
    "es": "al año · suscripción recurrente"
  },
  "Full PRO access for 12 months. The show goes on.": {
    "cnr": "Puni PRO pristup 12 mjeseci. Predstava se nastavlja.",
    "de": "Voller PRO-Zugang für 12 Monate. Die Show geht weiter.",
    "it": "Accesso PRO completo per 12 mesi. Lo spettacolo continua.",
    "es": "Acceso PRO completo durante 12 meses. El espectáculo continúa."
  },
  "VIEW YEARLY PLAN →": {
    "cnr": "GODIŠNJI PLAN →",
    "de": "JAHRESTARIF ANSEHEN →",
    "it": "VEDI IL PIANO ANNUALE →",
    "es": "VER PLAN ANUAL →"
  },
  "03 / THE LEGEND": {
    "cnr": "03 / LEGENDA",
    "de": "03 / DIE LEGENDE",
    "it": "03 / LA LEGGENDA",
    "es": "03 / LA LEYENDA"
  },
  "LIFETIME": {
    "cnr": "DOŽIVOTNO",
    "de": "LEBENSLANG",
    "it": "A VITA",
    "es": "DE POR VIDA"
  },
  "one-time purchase": {
    "cnr": "jednokratna kupovina",
    "de": "einmaliger Kauf",
    "it": "acquisto unico",
    "es": "pago único"
  },
  "A permanent license for the purchased PRO edition. No subscription.": {
    "cnr": "Trajna licenca za kupljeno PRO izdanje. Bez pretplate.",
    "de": "Dauerhafte Lizenz für die gekaufte PRO-Ausgabe. Ohne Abonnement.",
    "it": "Licenza permanente per l’edizione PRO acquistata. Senza abbonamento.",
    "es": "Licencia permanente para la edición PRO adquirida. Sin suscripción."
  },
  "VIEW LIFETIME PLAN →": {
    "cnr": "DOŽIVOTNI PLAN →",
    "de": "LEBENSLANGEN TARIF ANSEHEN →",
    "it": "VEDI IL PIANO A VITA →",
    "es": "VER PLAN DE POR VIDA →"
  },
  "Automatic license activation starts from BUY PRO inside the Android app.": {
    "cnr": "Automatska aktivacija licence počinje preko BUY PRO u Android aplikaciji.",
    "de": "Die automatische Lizenzaktivierung beginnt über BUY PRO in der Android-App.",
    "it": "L’attivazione automatica della licenza inizia da BUY PRO nell’app Android.",
    "es": "La activación automática de la licencia comienza desde BUY PRO en la app Android."
  },
  "Visit our Creem storefront": {
    "cnr": "Posjeti našu Creem prodavnicu",
    "de": "Besuche unsere Creem-Storeseite",
    "it": "Visita la nostra vetrina Creem",
    "es": "Visita nuestra tienda en Creem"
  },
  "to see the official store.": {
    "cnr": "i pogledaj zvaničnu ponudu.",
    "de": "und entdecke den offiziellen Shop.",
    "it": "per vedere il negozio ufficiale.",
    "es": "para ver la oferta oficial."
  },
  "LISTEN MORE. MANAGE LESS.": {
    "cnr": "VIŠE MUZIKE. MANJE POSLA.",
    "de": "MEHR HÖREN. WENIGER VERWALTEN.",
    "it": "ASCOLTA DI PIÙ. GESTISCI DI MENO.",
    "es": "ESCUCHA MÁS. ORGANIZA MENOS."
  },
  "Your music. On your terms.": {
    "cnr": "Tvoja muzika. Po tvojim pravilima.",
    "de": "Deine Musik. Nach deinen Regeln.",
    "it": "La tua musica. Alle tue condizioni.",
    "es": "Tu música. A tu manera."
  },
  "01 • YOUR CHOICE": {
    "cnr": "01 • TVOJ IZBOR",
    "de": "01 • DEINE WAHL",
    "it": "01 • LA TUA SCELTA",
    "es": "01 • TU ELECCIÓN"
  },
  "Not an algorithm's playlist": {
    "cnr": "Tvoja playlista, tvoj izbor",
    "de": "Deine Playlist statt Algorithmus",
    "it": "Una playlist scelta da te",
    "es": "Una lista elegida por ti"
  },
  "You choose the songs, order and queue. No unwanted automatic recommendations deciding what you hear next.": {
    "cnr": "Ti biraš pjesme, redosljed i red za puštanje. Bez neželjenih automatskih preporuka za sljedeću pjesmu.",
    "de": "Du wählst Titel, Reihenfolge und Warteschlange. Keine unerwünschten automatischen Empfehlungen bestimmen den nächsten Titel.",
    "it": "Scegli brani, ordine e coda. Nessun suggerimento automatico indesiderato decide cosa ascolterai dopo.",
    "es": "Tú eliges las canciones, el orden y la cola. Sin recomendaciones automáticas no deseadas que decidan qué escucharás después."
  },
  "02 • SMOOTH TRANSITIONS": {
    "cnr": "02 • GLATKI PRELAZI",
    "de": "02 • SANFTE ÜBERGÄNGE",
    "it": "02 • TRANSIZIONI FLUIDE",
    "es": "02 • TRANSICIONES SUAVES"
  },
  "Hours of effortless music": {
    "cnr": "Sati muzike bez napora",
    "de": "Stundenlang entspannt Musik hören",
    "it": "Ore di musica senza pensieri",
    "es": "Horas de música sin esfuerzo"
  },
  "Auto Mix helps your favorite playlists flow from track to track while you enjoy the moment.": {
    "cnr": "Auto Mix povezuje pjesme iz omiljenih playlista dok ti uživaš u trenutku.",
    "de": "Auto Mix verbindet die Titel deiner Lieblingsplaylists, während du den Moment genießt.",
    "it": "Auto Mix collega i brani delle tue playlist preferite mentre ti godi il momento.",
    "es": "Auto Mix enlaza las canciones de tus listas favoritas mientras disfrutas del momento."
  },
  "03 • NO MP3 MOUNTAINS": {
    "cnr": "03 • BEZ BRDA MP3 FAJLOVA",
    "de": "03 • KEINE MP3-BERGE",
    "it": "03 • NIENTE MONTAGNE DI MP3",
    "es": "03 • SIN MONTAÑAS DE MP3"
  },
  "Keep storage for other things": {
    "cnr": "Sačuvaj prostor za druge stvari",
    "de": "Speicherplatz für andere Dinge",
    "it": "Conserva spazio per altre cose",
    "es": "Guarda espacio para otras cosas"
  },
  "Save your online playlist selections without downloading thousands of MP3 files. Online listening needs an internet connection.": {
    "cnr": "Sačuvaj izbor online playlista bez preuzimanja hiljada MP3 fajlova. Za online slušanje potreban je internet.",
    "de": "Speichere deine Online-Playlistauswahl, ohne Tausende MP3-Dateien herunterzuladen. Online-Wiedergabe benötigt Internet.",
    "it": "Salva le tue playlist online senza scaricare migliaia di MP3. Per l’ascolto online serve una connessione Internet.",
    "es": "Guarda tus listas en línea sin descargar miles de MP3. La escucha en línea requiere conexión a internet."
  },
  "MADE FOR EVERYDAY LISTENING": {
    "cnr": "ZA SVAKODNEVNO SLUŠANJE",
    "de": "FÜR MUSIK IM ALLTAG",
    "it": "PER L’ASCOLTO QUOTIDIANO",
    "es": "PARA ESCUCHAR A DIARIO"
  },
  "Set the mood. Enjoy the day.": {
    "cnr": "Stvori atmosferu. Uživaj u danu.",
    "de": "Schaffe Stimmung. Genieße den Tag.",
    "it": "Crea l’atmosfera. Goditi la giornata.",
    "es": "Crea ambiente. Disfruta del día."
  },
  "Restaurants & cafés": {
    "cnr": "Restorani i kafići",
    "de": "Restaurants und Cafés",
    "it": "Ristoranti e bar",
    "es": "Restaurantes y cafeterías"
  },
  "Prepare a playlist for your space and let the atmosphere flow. Public playback requires appropriate music rights.": {
    "cnr": "Pripremi playlistu za svoj prostor i prepusti se atmosferi. Za javno puštanje muzike potrebna su odgovarajuća prava.",
    "de": "Bereite eine Playlist für deinen Raum vor und genieße die Atmosphäre. Öffentliche Wiedergabe erfordert die entsprechenden Musikrechte.",
    "it": "Prepara una playlist per il tuo locale e lascia fluire l’atmosfera. La riproduzione pubblica richiede i diritti musicali appropriati.",
    "es": "Prepara una lista para tu local y deja fluir el ambiente. La reproducción pública requiere los derechos musicales correspondientes."
  },
  "Drivers": {
    "cnr": "Vozači",
    "de": "Autofahrer",
    "it": "Automobilisti",
    "es": "Conductores"
  },
  "Choose your music before you drive, then enjoy a long soundtrack without searching for the next song.": {
    "cnr": "Izaberi muziku prije vožnje i uživaj bez traženja sljedeće pjesme.",
    "de": "Wähle deine Musik vor der Fahrt und genieße sie, ohne nach dem nächsten Titel suchen zu müssen.",
    "it": "Scegli la musica prima di guidare e goditi un lungo ascolto senza cercare il prossimo brano.",
    "es": "Elige tu música antes de conducir y disfruta sin buscar la siguiente canción."
  },
  "Music enthusiasts": {
    "cnr": "Ljubitelji muzike",
    "de": "Musikbegeisterte",
    "it": "Appassionati di musica",
    "es": "Amantes de la música"
  },
  "At home or at a party: your favorite songs, in your order, with fine transitions.": {
    "cnr": "Kod kuće ili na žurci: omiljene pjesme, tvoj redosljed i fini prelazi.",
    "de": "Zu Hause oder auf einer Party: deine Lieblingssongs, deine Reihenfolge, sanfte Übergänge.",
    "it": "A casa o a una festa: i tuoi brani preferiti, nel tuo ordine, con transizioni curate.",
    "es": "En casa o en una fiesta: tus canciones favoritas, en tu orden y con buenas transiciones."
  },
  "READY TO ROCK?": {
    "cnr": "SPREMAN ZA MUZIKU?",
    "de": "BEREIT LOSZULEGEN?",
    "it": "PRONTO A SCATENARTI?",
    "es": "¿LISTO PARA LA MÚSICA?"
  },
  "Put the music back in your hands.": {
    "cnr": "Uzmi muziku u svoje ruke.",
    "de": "Nimm die Musik wieder selbst in die Hand.",
    "it": "Riprendi la musica nelle tue mani.",
    "es": "Vuelve a tener la música en tus manos."
  },
  "7 DAYS FREE TRIAL — ALL PRO FEATURES UNLOCKED.": {
    "cnr": "7 DANA BESPLATNE PROBE — SVE PRO FUNKCIJE OTKLJUČANE.",
    "de": "7 TAGE KOSTENLOS TESTEN — ALLE PRO-FUNKTIONEN FREIGESCHALTET.",
    "it": "7 GIORNI DI PROVA GRATUITA — TUTTE LE FUNZIONI PRO SBLOCCATE.",
    "es": "7 DÍAS DE PRUEBA GRATIS — TODAS LAS FUNCIONES PRO DESBLOQUEADAS."
  },
  "Enjoy hours of smooth transitions and your own playlists without filling the device with MP3 files. Download the official APK on an eligible new device, then choose a plan inside the app if you wish to continue after the trial.": {
    "cnr": "Uživaj satima u glatkim prelazima i svojim playlistama bez punjenja uređaja MP3 fajlovima. Preuzmi zvanični APK na novi uređaj koji ispunjava uslove, a poslije probe izaberi plan u aplikaciji ako želiš da nastaviš.",
    "de": "Genieße stundenlang sanfte Übergänge und eigene Playlists, ohne das Gerät mit MP3-Dateien zu füllen. Lade die offizielle APK auf ein berechtigtes neues Gerät und wähle nach der Testphase bei Bedarf einen Tarif in der App.",
    "it": "Goditi ore di transizioni fluide e le tue playlist senza riempire il dispositivo di MP3. Scarica l’APK ufficiale su un nuovo dispositivo idoneo, poi scegli un piano nell’app se desideri continuare dopo la prova.",
    "es": "Disfruta de horas de transiciones suaves y tus propias listas sin llenar el dispositivo de MP3. Descarga el APK oficial en un nuevo dispositivo apto y elige un plan en la app si deseas continuar después de la prueba."
  },
  "↓ DOWNLOAD BRAKEMONSTER PRO": {
    "cnr": "↓ PREUZMI BRAKEMONSTER PRO",
    "de": "↓ BRAKEMONSTER PRO HERUNTERLADEN",
    "it": "↓ SCARICA BRAKEMONSTER PRO",
    "es": "↓ DESCARGAR BRAKEMONSTER PRO"
  },
  "BRAKEMONSTER PRO PARTNERS": {
    "cnr": "BRAKEMONSTER PRO PARTNERI",
    "de": "BRAKEMONSTER PRO PARTNER",
    "it": "PARTNER BRAKEMONSTER PRO",
    "es": "SOCIOS DE BRAKEMONSTER PRO"
  },
  "SHARE THE MONSTER.": {
    "cnr": "PODIJELI MONSTERA.",
    "de": "TEILE DAS MONSTER.",
    "it": "CONDIVIDI IL MONSTER.",
    "es": "COMPARTE EL MONSTER."
  },
  "EARN 30%.": {
    "cnr": "ZARADI 30%.",
    "de": "VERDIENE 30 %.",
    "it": "GUADAGNA IL 30%.",
    "es": "GANA UN 30 %."
  },
  "Have an audience that loves music, driving, cafés or Android apps? Recommend BrakeMonster PRO and earn a": {
    "cnr": "Tvoja publika voli muziku, vožnju, kafiće ili Android aplikacije? Preporuči BrakeMonster PRO i zaradi",
    "de": "Deine Community liebt Musik, Autofahren, Cafés oder Android-Apps? Empfiehl BrakeMonster PRO und erhalte",
    "it": "Il tuo pubblico ama la musica, le auto, i bar o le app Android? Consiglia BrakeMonster PRO e guadagna una",
    "es": "¿Tu público disfruta de la música, la conducción, las cafeterías o las apps Android? Recomienda BrakeMonster PRO y gana una"
  },
  "30% commission on the first qualifying purchase": {
    "cnr": "30% provizije na prvu kupovinu koja ispunjava uslove",
    "de": "30 % Provision auf den ersten qualifizierten Kauf",
    "it": "commissione del 30% sul primo acquisto idoneo",
    "es": "comisión del 30 % en la primera compra que cumpla los requisitos"
  },
  "of each referred customer. No commissions on subscription renewals.": {
    "cnr": "svakog preporučenog kupca. Bez provizije na obnovu pretplate.",
    "de": "jedes vermittelten Kunden. Keine Provision auf Aboverlängerungen.",
    "it": "di ogni cliente presentato. Nessuna commissione sui rinnovi degli abbonamenti.",
    "es": "de cada cliente referido. Sin comisiones por renovaciones de suscripciones."
  },
  "Free to apply • Applications reviewed • Tracking and partner payouts managed by Creem": {
    "cnr": "Besplatna prijava • Prijave se pregledaju • Creem vodi praćenje i isplate partnerima",
    "de": "Kostenlose Bewerbung • Bewerbungen werden geprüft • Tracking und Partnerauszahlungen über Creem",
    "it": "Candidatura gratuita • Candidature esaminate • Tracciamento e pagamenti ai partner gestiti da Creem",
    "es": "Solicitud gratuita • Solicitudes revisadas • Seguimiento y pagos a socios gestionados por Creem"
  },
  "🦖 BECOME A PARTNER — 30% ↗": {
    "cnr": "🦖 POSTANI PARTNER — 30% ↗",
    "de": "🦖 PARTNER WERDEN — 30 % ↗",
    "it": "🦖 DIVENTA PARTNER — 30% ↗",
    "es": "🦖 HAZTE SOCIO — 30 % ↗"
  },
  "Join on Creem · No personal email invitation needed": {
    "cnr": "Prijavi se na Creem · Nije potreban lični poziv e-poštom",
    "de": "Anmeldung über Creem · Keine persönliche E-Mail-Einladung nötig",
    "it": "Iscriviti su Creem · Nessun invito personale via email necessario",
    "es": "Regístrate en Creem · No necesitas invitación personal por correo"
  },
  "THE WORLD BEHIND THE MUSIC": {
    "cnr": "SVIJET IZA MUZIKE",
    "de": "DIE WELT HINTER DER MUSIK",
    "it": "IL MONDO DIETRO LA MUSICA",
    "es": "EL MUNDO DETRÁS DE LA MÚSICA"
  },
  "More from TERAPHONIA": {
    "cnr": "Još iz TERAPHONIJE",
    "de": "Mehr von TERAPHONIA",
    "it": "Altro da TERAPHONIA",
    "es": "Más de TERAPHONIA"
  },
  "Original Music": {
    "cnr": "Autorska muzika",
    "de": "Eigene Musik",
    "it": "Musica originale",
    "es": "Música original"
  },
  "Discover original TERAPHONIA songs and compositions.": {
    "cnr": "Otkrij autorske pjesme i kompozicije TERAPHONIJE.",
    "de": "Entdecke eigene Songs und Kompositionen von TERAPHONIA.",
    "it": "Scopri i brani e le composizioni originali di TERAPHONIA.",
    "es": "Descubre las canciones y composiciones originales de TERAPHONIA."
  },
  "LISTEN →": {
    "cnr": "SLUŠAJ →",
    "de": "ANHÖREN →",
    "it": "ASCOLTA →",
    "es": "ESCUCHAR →"
  },
  "Stories": {
    "cnr": "Priče",
    "de": "Geschichten",
    "it": "Storie",
    "es": "Historias"
  },
  "A universe connecting legends, history and imagination.": {
    "cnr": "Svijet koji povezuje legende, istoriju i maštu.",
    "de": "Ein Universum aus Legenden, Geschichte und Fantasie.",
    "it": "Un universo che unisce leggende, storia e immaginazione.",
    "es": "Un universo que conecta leyendas, historia e imaginación."
  },
  "LEARN MORE →": {
    "cnr": "SAZNAJ VIŠE →",
    "de": "MEHR ERFAHREN →",
    "it": "SCOPRI DI PIÙ →",
    "es": "SABER MÁS →"
  },
  "Follow TERAPHONIA as a visual story, one episode at a time.": {
    "cnr": "Prati TERAPHONIJU kroz vizuelnu priču, epizodu po epizodu.",
    "de": "Erlebe TERAPHONIA als visuelle Geschichte, Folge für Folge.",
    "it": "Segui TERAPHONIA come racconto visivo, un episodio alla volta.",
    "es": "Sigue TERAPHONIA como historia visual, episodio a episodio."
  },
  "READ →": {
    "cnr": "ČITAJ →",
    "de": "LESEN →",
    "it": "LEGGI →",
    "es": "LEER →"
  },
  "Music. Stories. Software. All independent.": {
    "cnr": "Muzika. Priče. Softver. Sve nezavisno.",
    "de": "Musik. Geschichten. Software. Alles unabhängig.",
    "it": "Musica. Storie. Software. Tutto indipendente.",
    "es": "Música. Historias. Software. Todo independiente."
  },
  "© 2026 TERAPHONIA · Montenegro": {
    "cnr": "© 2026 TERAPHONIA · Crna Gora",
    "de": "© 2026 TERAPHONIA · Montenegro",
    "it": "© 2026 TERAPHONIA · Montenegro",
    "es": "© 2026 TERAPHONIA · Montenegro"
  },
  "APK Download": {
    "cnr": "Preuzmi APK",
    "de": "APK herunterladen",
    "it": "Scarica APK",
    "es": "Descargar APK"
  },
  "PRO Plans": {
    "cnr": "PRO planovi",
    "de": "PRO-Tarife",
    "it": "Piani PRO",
    "es": "Planes PRO"
  },
  "Help": {
    "cnr": "Pomoć",
    "de": "Hilfe",
    "it": "Guida",
    "es": "Ayuda"
  },
  "Earn 30% · Partners": {
    "cnr": "Zaradi 30% · Partneri",
    "de": "30 % verdienen · Partner",
    "it": "Guadagna il 30% · Partner",
    "es": "Gana un 30 % · Socios"
  },
  "Contact": {
    "cnr": "Kontakt",
    "de": "Kontakt",
    "it": "Contatti",
    "es": "Contacto"
  },
  "BrakeMonster PRO · Choose Your Plan | TERAPHONIA": {
    "cnr": "BrakeMonster PRO · Izaberi plan | TERAPHONIA",
    "de": "BrakeMonster PRO · Tarif wählen | TERAPHONIA",
    "it": "BrakeMonster PRO · Scegli il piano | TERAPHONIA",
    "es": "BrakeMonster PRO · Elige tu plan | TERAPHONIA"
  },
  "THE MONSTER HAS THREE SIDES": {
    "cnr": "MONSTER IMA TRI LICA",
    "de": "DAS MONSTER HAT DREI SEITEN",
    "it": "IL MONSTER HA TRE VOLTI",
    "es": "EL MONSTER TIENE TRES CARAS"
  },
  "CHOOSE YOUR": {
    "cnr": "IZABERI SVOJU",
    "de": "WÄHLE DEINEN",
    "it": "SCEGLI IL TUO",
    "es": "ELIGE TU"
  },
  "PRO PASS.": {
    "cnr": "PRO PROPUSNICU.",
    "de": "PRO-PASS.",
    "it": "PASS PRO.",
    "es": "PASE PRO."
  },
  "Hours of music, smooth Auto Mix transitions, no unwanted recommendations and no huge MP3 library needed. Every plan unlocks the same PRO tools on up to three active Android devices.": {
    "cnr": "Sati muzike, glatki Auto Mix prelazi, bez neželjenih preporuka i potrebe za velikom MP3 kolekcijom. Svaki plan otključava iste PRO alate na najviše tri aktivna Android uređaja.",
    "de": "Stundenlange Musik, sanfte Auto-Mix-Übergänge, keine unerwünschten Empfehlungen und keine riesige MP3-Sammlung nötig. Jeder Tarif schaltet dieselben PRO-Werkzeuge auf bis zu drei aktiven Android-Geräten frei.",
    "it": "Ore di musica, transizioni fluide con Auto Mix, nessun suggerimento indesiderato e nessuna enorme raccolta MP3 necessaria. Ogni piano sblocca gli stessi strumenti PRO su un massimo di tre dispositivi Android attivi.",
    "es": "Horas de música, transiciones suaves con Auto Mix, sin recomendaciones no deseadas ni enormes colecciones de MP3. Todos los planes desbloquean las mismas herramientas PRO en hasta tres dispositivos Android activos."
  },
  "NO PURCHASE REQUIRED TO TRY": {
    "cnr": "PROBA BEZ KUPOVINE",
    "de": "TESTEN OHNE KAUF",
    "it": "PROVA SENZA ACQUISTO",
    "es": "PRUEBA SIN COMPRA OBLIGATORIA"
  },
  "Available for eligible new devices · Choose a plan after your trial": {
    "cnr": "Za nove uređaje koji ispunjavaju uslove · Izaberi plan poslije probe",
    "de": "Für berechtigte neue Geräte · Tarif nach der Testphase wählen",
    "it": "Per nuovi dispositivi idonei · Scegli un piano dopo la prova",
    "es": "Para nuevos dispositivos aptos · Elige un plan después de la prueba"
  },
  "↓ DOWNLOAD & START YOUR FREE TRIAL": {
    "cnr": "↓ PREUZMI I POČNI BESPLATNU PROBU",
    "de": "↓ HERUNTERLADEN UND KOSTENLOS TESTEN",
    "it": "↓ SCARICA E INIZIA LA PROVA GRATUITA",
    "es": "↓ DESCARGA Y EMPIEZA LA PRUEBA GRATIS"
  },
  "Checking the LIVE billing service. To buy and link your license, open BUY PRO from the BrakeMonster Android app.": {
    "cnr": "Provjera servisa za naplatu. Za kupovinu i povezivanje licence otvori BUY PRO u BrakeMonster Android aplikaciji.",
    "de": "Der Zahlungsdienst wird geprüft. Öffne BUY PRO in der BrakeMonster-Android-App, um zu kaufen und die Lizenz zu verknüpfen.",
    "it": "Verifica del servizio di pagamento. Per acquistare e collegare la licenza, apri BUY PRO nell’app BrakeMonster per Android.",
    "es": "Comprobando el servicio de pago. Para comprar y vincular tu licencia, abre BUY PRO en la app BrakeMonster para Android."
  },
  "THE DJ": {
    "cnr": "DJ",
    "de": "DER DJ",
    "it": "IL DJ",
    "es": "EL DJ"
  },
  "Flexible access. Cancel future renewals under your plan terms.": {
    "cnr": "Fleksibilan pristup. Otkaži buduće obnove prema uslovima plana.",
    "de": "Flexibler Zugang. Künftige Verlängerungen gemäß den Tarifbedingungen kündbar.",
    "it": "Accesso flessibile. Annulla i rinnovi futuri secondo le condizioni del piano.",
    "es": "Acceso flexible. Cancela las futuras renovaciones según las condiciones del plan."
  },
  "CHECKING LIVE STORE": {
    "cnr": "PROVJERA PRODAVNICE",
    "de": "SHOP WIRD GEPRÜFT",
    "it": "VERIFICA DEL NEGOZIO",
    "es": "COMPROBANDO LA TIENDA"
  },
  "THE HEADLINER": {
    "cnr": "ZVIJEZDA VEČERI",
    "de": "DER HEADLINER",
    "it": "LA STAR",
    "es": "LA ESTRELLA"
  },
  "A year of full PRO access at a lower effective monthly price.": {
    "cnr": "Godina punog PRO pristupa uz niži prosječni mjesečni trošak.",
    "de": "Ein Jahr voller PRO-Zugang zu einem günstigeren rechnerischen Monatspreis.",
    "it": "Un anno di accesso PRO completo a un costo mensile effettivo inferiore.",
    "es": "Un año de acceso PRO completo con un coste mensual efectivo más bajo."
  },
  "THE LEGEND": {
    "cnr": "LEGENDA",
    "de": "DIE LEGENDE",
    "it": "LA LEGGENDA",
    "es": "LA LEYENDA"
  },
  "Permanent access to the purchased PRO license, subject to terms.": {
    "cnr": "Trajan pristup kupljenoj PRO licenci, u skladu sa uslovima.",
    "de": "Dauerhafter Zugang zur gekauften PRO-Lizenz gemäß den Bedingungen.",
    "it": "Accesso permanente alla licenza PRO acquistata, secondo le condizioni.",
    "es": "Acceso permanente a la licencia PRO adquirida, sujeto a las condiciones."
  },
  "Please check final prices and terms on the secure Creem checkout. First purchases should start inside the BrakeMonster app to link your installation automatically. The license is confirmed by our production server, not by this page.": {
    "cnr": "Provjeri konačne cijene i uslove na sigurnoj Creem stranici za plaćanje. Prvu kupovinu pokreni iz BrakeMonster aplikacije radi automatskog povezivanja instalacije. Licencu potvrđuje naš produkcioni server; ova stranica ne vrši aktivaciju.",
    "de": "Prüfe die endgültigen Preise und Bedingungen im sicheren Creem-Checkout. Starte den ersten Kauf in der BrakeMonster-App, damit die Installation automatisch verknüpft wird. Die Lizenz wird von unserem Produktionsserver bestätigt; diese Seite aktiviert sie nicht.",
    "it": "Controlla prezzi e condizioni finali nel pagamento sicuro Creem. Avvia il primo acquisto dall’app BrakeMonster per collegare automaticamente l’installazione. La licenza viene confermata dal nostro server di produzione; questa pagina non la attiva.",
    "es": "Comprueba los precios y condiciones finales en el pago seguro de Creem. Inicia la primera compra desde la app BrakeMonster para vincular automáticamente tu instalación. Nuestro servidor de producción confirma la licencia; esta página no la activa."
  },
  "HOW ACTIVATION WORKS": {
    "cnr": "KAKO RADI AKTIVACIJA",
    "de": "SO FUNKTIONIERT DIE AKTIVIERUNG",
    "it": "COME FUNZIONA L’ATTIVAZIONE",
    "es": "CÓMO FUNCIONA LA ACTIVACIÓN"
  },
  "Install. Try Free. Go PRO.": {
    "cnr": "Instaliraj. Probaj besplatno. Pređi na PRO.",
    "de": "Installieren. Kostenlos testen. PRO nutzen.",
    "it": "Installa. Prova gratis. Passa a PRO.",
    "es": "Instala. Prueba gratis. Pásate a PRO."
  },
  "Get the app": {
    "cnr": "Preuzmi aplikaciju",
    "de": "App herunterladen",
    "it": "Scarica l’app",
    "es": "Descarga la app"
  },
  "Download and install the official BrakeMonster PRO APK on Android.": {
    "cnr": "Preuzmi i instaliraj zvanični BrakeMonster PRO APK na Android.",
    "de": "Lade die offizielle BrakeMonster-PRO-APK herunter und installiere sie auf Android.",
    "it": "Scarica e installa l’APK ufficiale di BrakeMonster PRO su Android.",
    "es": "Descarga e instala el APK oficial de BrakeMonster PRO en Android."
  },
  "Try 7 days free": {
    "cnr": "Probaj besplatno 7 dana",
    "de": "7 Tage kostenlos testen",
    "it": "Prova gratis per 7 giorni",
    "es": "Prueba gratis durante 7 días"
  },
  "Eligible new devices can try all PRO features for 7 days. No purchase is required to begin the trial.": {
    "cnr": "Novi uređaji koji ispunjavaju uslove mogu koristiti sve PRO funkcije 7 dana. Kupovina nije potrebna za početak probe.",
    "de": "Berechtigte neue Geräte können alle PRO-Funktionen 7 Tage testen. Für den Testbeginn ist kein Kauf nötig.",
    "it": "I nuovi dispositivi idonei possono provare tutte le funzioni PRO per 7 giorni. Non serve acquistare per iniziare la prova.",
    "es": "Los nuevos dispositivos aptos pueden probar todas las funciones PRO durante 7 días. No se necesita comprar para comenzar la prueba."
  },
  "Buy & activate": {
    "cnr": "Kupi i aktiviraj",
    "de": "Kaufen und aktivieren",
    "it": "Acquista e attiva",
    "es": "Compra y activa"
  },
  "When ready, open BUY PRO in the app for purchase-linked activation. After server-confirmed payment, activate up to two more devices using your code.": {
    "cnr": "Kada budeš spreman, otvori BUY PRO u aplikaciji za aktivaciju povezanu sa kupovinom. Poslije serverske potvrde plaćanja kodom aktiviraj još najviše dva uređaja.",
    "de": "Öffne BUY PRO in der App für eine mit dem Kauf verknüpfte Aktivierung. Nach serverseitiger Zahlungsbestätigung kannst du mit deinem Code bis zu zwei weitere Geräte aktivieren.",
    "it": "Quando vuoi, apri BUY PRO nell’app per l’attivazione collegata all’acquisto. Dopo la conferma del pagamento dal server, attiva fino ad altri due dispositivi con il tuo codice.",
    "es": "Cuando quieras, abre BUY PRO en la app para activar la licencia vinculada a la compra. Tras confirmar el servidor el pago, activa hasta dos dispositivos más con tu código."
  },
  "ACTIVATION HELP": {
    "cnr": "POMOĆ ZA AKTIVACIJU",
    "de": "HILFE ZUR AKTIVIERUNG",
    "it": "GUIDA ALL’ATTIVAZIONE",
    "es": "AYUDA DE ACTIVACIÓN"
  },
  "Secure payments are processed through Creem.": {
    "cnr": "Sigurna plaćanja obrađuje Creem.",
    "de": "Sichere Zahlungen werden über Creem abgewickelt.",
    "it": "I pagamenti sicuri sono elaborati da Creem.",
    "es": "Los pagos seguros se procesan a través de Creem."
  },
  "Creem Store": {
    "cnr": "Creem prodavnica",
    "de": "Creem-Shop",
    "it": "Negozio Creem",
    "es": "Tienda Creem"
  },
  "Support": {
    "cnr": "Podrška",
    "de": "Support",
    "it": "Assistenza",
    "es": "Soporte"
  },
  "Home": {
    "cnr": "Početna",
    "de": "Startseite",
    "it": "Home",
    "es": "Inicio"
  },
  "RETURN TO BRAKEMONSTER · TERAPHONIA": {
    "cnr": "POVRATAK U BRAKEMONSTER · TERAPHONIA",
    "de": "ZURÜCK ZU BRAKEMONSTER · TERAPHONIA",
    "it": "TORNA A BRAKEMONSTER · TERAPHONIA",
    "es": "VOLVER A BRAKEMONSTER · TERAPHONIA"
  },
  "RETURN TO BRAKEMONSTER": {
    "cnr": "VRATI SE U BRAKEMONSTER",
    "de": "ZURÜCK ZU BRAKEMONSTER",
    "it": "TORNA A BRAKEMONSTER",
    "es": "VOLVER A BRAKEMONSTER"
  },
  "Return to the app and check HELP / ABOUT to refresh the server-confirmed license status. This page does not grant PRO access or confirm a successful payment.": {
    "cnr": "Vrati se u aplikaciju i otvori HELP / ABOUT da osvježiš status licence potvrđen na serveru. Ova stranica ne daje PRO pristup niti potvrđuje uspješno plaćanje.",
    "de": "Kehre zur App zurück und öffne HELP / ABOUT, um den vom Server bestätigten Lizenzstatus zu aktualisieren. Diese Seite gewährt keinen PRO-Zugang und bestätigt keine erfolgreiche Zahlung.",
    "it": "Torna nell’app e apri HELP / ABOUT per aggiornare lo stato della licenza confermato dal server. Questa pagina non concede l’accesso PRO e non conferma il buon esito del pagamento.",
    "es": "Vuelve a la app y abre HELP / ABOUT para actualizar el estado de licencia confirmado por el servidor. Esta página no concede acceso PRO ni confirma un pago correcto."
  },
  "SUBSCRIPTION HELP": {
    "cnr": "POMOĆ ZA PRETPLATU",
    "de": "HILFE ZUM ABONNEMENT",
    "it": "GUIDA ALL’ABBONAMENTO",
    "es": "AYUDA DE SUSCRIPCIÓN"
  },
  "BACK TO TOP": {
    "cnr": "NA VRH",
    "de": "NACH OBEN",
    "it": "TORNA IN ALTO",
    "es": "VOLVER ARRIBA"
  },
  "Technical support:": {
    "cnr": "Tehnička podrška:",
    "de": "Technischer Support:",
    "it": "Assistenza tecnica:",
    "es": "Soporte técnico:"
  },
  "Download BrakeMonster PRO for Android | TERAPHONIA": {
    "cnr": "Preuzmi BrakeMonster PRO za Android | TERAPHONIA",
    "de": "BrakeMonster PRO für Android herunterladen | TERAPHONIA",
    "it": "Scarica BrakeMonster PRO per Android | TERAPHONIA",
    "es": "Descargar BrakeMonster PRO para Android | TERAPHONIA"
  },
  "OFFICIAL ANDROID RELEASE": {
    "cnr": "ZVANIČNO ANDROID IZDANJE",
    "de": "OFFIZIELLE ANDROID-VERSION",
    "it": "VERSIONE ANDROID UFFICIALE",
    "es": "VERSIÓN OFICIAL PARA ANDROID"
  },
  "DOWNLOAD": {
    "cnr": "PREUZMI",
    "de": "HERUNTERLADEN",
    "it": "SCARICA",
    "es": "DESCARGAR"
  },
  "Your music. Your choice. Enjoy hours of smooth Auto Mix transitions, play your own online playlists and avoid filling your device with thousands of MP3 files. Online listening requires internet.": {
    "cnr": "Tvoja muzika. Tvoj izbor. Uživaj satima u glatkim Auto Mix prelazima, puštaj svoje online playliste i sačuvaj uređaj od hiljada MP3 fajlova. Online slušanje zahtijeva internet.",
    "de": "Deine Musik. Deine Wahl. Genieße stundenlang sanfte Auto-Mix-Übergänge und eigene Online-Playlists, ohne dein Gerät mit Tausenden MP3-Dateien zu füllen. Online-Wiedergabe benötigt Internet.",
    "it": "La tua musica. La tua scelta. Goditi ore di transizioni fluide con Auto Mix e le tue playlist online senza riempire il dispositivo di migliaia di MP3. L’ascolto online richiede Internet.",
    "es": "Tu música. Tu elección. Disfruta de horas de transiciones suaves con Auto Mix y tus propias listas en línea sin llenar tu dispositivo de miles de MP3. La escucha en línea requiere internet."
  },
  "TRY BEFORE YOU BUY": {
    "cnr": "PROBAJ PRIJE KUPOVINE",
    "de": "VOR DEM KAUF TESTEN",
    "it": "PROVA PRIMA DI ACQUISTARE",
    "es": "PRUEBA ANTES DE COMPRAR"
  },
  "For eligible new devices · No purchase required to begin": {
    "cnr": "Za nove uređaje koji ispunjavaju uslove · Početak bez kupovine",
    "de": "Für berechtigte neue Geräte · Kein Kauf zum Start nötig",
    "it": "Per nuovi dispositivi idonei · Nessun acquisto richiesto per iniziare",
    "es": "Para nuevos dispositivos aptos · Sin compra obligatoria para empezar"
  },
  "Android 8.0+ · Phones & tablets · Direct from our official GitHub release": {
    "cnr": "Android 8.0+ · Telefoni i tableti · Direktno sa našeg zvaničnog GitHub izdanja",
    "de": "Android 8.0+ · Smartphones und Tablets · Direkt aus unserer offiziellen GitHub-Veröffentlichung",
    "it": "Android 8.0+ · Telefoni e tablet · Dalla nostra versione ufficiale su GitHub",
    "es": "Android 8.0+ · Teléfonos y tabletas · Desde nuestra versión oficial en GitHub"
  },
  "SIGNED APK · AUTOMATIC RELEASE CHECK": {
    "cnr": "POTPISANI APK · AUTOMATSKA PROVJERA IZDANJA",
    "de": "SIGNIERTE APK · AUTOMATISCHE VERSIONSPRÜFUNG",
    "it": "APK FIRMATO · VERIFICA AUTOMATICA DELLA VERSIONE",
    "es": "APK FIRMADO · VERIFICACIÓN AUTOMÁTICA DE LA VERSIÓN"
  },
  "Install the monster.": {
    "cnr": "Instaliraj Monstera.",
    "de": "Installiere das Monster.",
    "it": "Installa il Monster.",
    "es": "Instala el Monster."
  },
  "Free 7-day PRO trial": {
    "cnr": "Besplatna PRO proba od 7 dana",
    "de": "Kostenloser 7-Tage-PRO-Test",
    "it": "Prova PRO gratuita di 7 giorni",
    "es": "Prueba PRO gratuita de 7 días"
  },
  "on eligible devices — all PRO features available during the trial.": {
    "cnr": "na uređajima koji ispunjavaju uslove — sve PRO funkcije dostupne tokom probe.",
    "de": "auf berechtigten Geräten — alle PRO-Funktionen während der Testphase verfügbar.",
    "it": "sui dispositivi idonei — tutte le funzioni PRO disponibili durante la prova.",
    "es": "en dispositivos aptos — todas las funciones PRO disponibles durante la prueba."
  },
  "Checking the official release…": {
    "cnr": "Provjera zvaničnog izdanja…",
    "de": "Offizielle Version wird geprüft…",
    "it": "Verifica della versione ufficiale…",
    "es": "Comprobando la versión oficial…"
  },
  "Release details will appear after verification.": {
    "cnr": "Podaci o izdanju pojaviće se nakon provjere.",
    "de": "Versionsdetails erscheinen nach der Prüfung.",
    "it": "I dettagli della versione appariranno dopo la verifica.",
    "es": "Los detalles de la versión aparecerán tras la verificación."
  },
  "VERIFYING APK…": {
    "cnr": "PROVJERA APK-a…",
    "de": "APK WIRD GEPRÜFT…",
    "it": "VERIFICA APK…",
    "es": "VERIFICANDO APK…"
  },
  "HOW TO INSTALL": {
    "cnr": "KAKO INSTALIRATI",
    "de": "INSTALLATIONSANLEITUNG",
    "it": "COME INSTALLARE",
    "es": "CÓMO INSTALAR"
  },
  "SHA-256 · file verification": {
    "cnr": "SHA-256 · provjera fajla",
    "de": "SHA-256 · Dateiprüfung",
    "it": "SHA-256 · verifica file",
    "es": "SHA-256 · verificación del archivo"
  },
  "The APK link is enabled only when the public release file and its SHA-256 digest match the published release metadata. Do not uninstall your existing app before updating.": {
    "cnr": "APK link se uključuje tek kada javni fajl i njegov SHA-256 odgovaraju objavljenim podacima izdanja. Ne deinstaliraj postojeću aplikaciju prije ažuriranja.",
    "de": "Der APK-Link wird erst freigeschaltet, wenn die öffentliche Datei und ihr SHA-256-Wert mit den veröffentlichten Versionsdaten übereinstimmen. Deinstalliere die vorhandene App vor einem Update nicht.",
    "it": "Il link APK si attiva solo quando il file pubblico e il suo SHA-256 corrispondono ai dati pubblicati della versione. Non disinstallare l’app prima di aggiornare.",
    "es": "El enlace al APK se activa cuando el archivo público y su SHA-256 coinciden con los datos publicados de la versión. No desinstales la app antes de actualizar."
  },
  "THREE EASY STEPS": {
    "cnr": "TRI JEDNOSTAVNA KORAKA",
    "de": "DREI EINFACHE SCHRITTE",
    "it": "TRE SEMPLICI PASSI",
    "es": "TRES PASOS SENCILLOS"
  },
  "From download to DJ.": {
    "cnr": "Od preuzimanja do DJ-a.",
    "de": "Vom Download zum DJ.",
    "it": "Dal download al DJ.",
    "es": "De la descarga a DJ."
  },
  "Download": {
    "cnr": "Preuzmi",
    "de": "Herunterladen",
    "it": "Scarica",
    "es": "Descargar"
  },
  "Press DOWNLOAD APK above. Your browser opens our signed release file on GitHub.": {
    "cnr": "Pritisni PREUZMI APK iznad. Browser otvara naš potpisani fajl na GitHubu.",
    "de": "Drücke oben APK HERUNTERLADEN. Dein Browser öffnet unsere signierte Datei auf GitHub.",
    "it": "Premi SCARICA APK qui sopra. Il browser apre il nostro file firmato su GitHub.",
    "es": "Pulsa DESCARGAR APK arriba. El navegador abre nuestro archivo firmado en GitHub."
  },
  "Install": {
    "cnr": "Instaliraj",
    "de": "Installieren",
    "it": "Installa",
    "es": "Instalar"
  },
  "Open the downloaded APK. Android may ask you to allow installation from your browser for this file.": {
    "cnr": "Otvori preuzeti APK. Android može tražiti dozvolu za instalaciju ovog fajla iz browsera.",
    "de": "Öffne die heruntergeladene APK. Android fragt möglicherweise nach der Erlaubnis, diese Datei über deinen Browser zu installieren.",
    "it": "Apri l’APK scaricato. Android potrebbe chiedere di consentire l’installazione di questo file dal browser.",
    "es": "Abre el APK descargado. Android puede pedir permiso para instalar este archivo desde el navegador."
  },
  "Try PRO free": {
    "cnr": "Probaj PRO besplatno",
    "de": "PRO kostenlos testen",
    "it": "Prova PRO gratis",
    "es": "Prueba PRO gratis"
  },
  "Open the app to start your eligible 7-day PRO trial, with all PRO features unlocked. You can later choose BUY PRO for a paid license or activate an existing license.": {
    "cnr": "Otvori aplikaciju i započni PRO probu od 7 dana ako uređaj ispunjava uslove, sa svim PRO funkcijama. Kasnije izaberi BUY PRO za kupovinu ili aktiviraj postojeću licencu.",
    "de": "Öffne die App, um den 7-Tage-PRO-Test auf einem berechtigten Gerät mit allen PRO-Funktionen zu starten. Später kannst du über BUY PRO eine Lizenz kaufen oder eine vorhandene aktivieren.",
    "it": "Apri l’app per iniziare la prova PRO di 7 giorni su un dispositivo idoneo, con tutte le funzioni sbloccate. In seguito puoi acquistare da BUY PRO o attivare una licenza esistente.",
    "es": "Abre la app para iniciar la prueba PRO de 7 días en un dispositivo apto, con todas las funciones desbloqueadas. Después puedes comprar desde BUY PRO o activar una licencia existente."
  },
  "Already using BrakeMonster?": {
    "cnr": "Već koristiš BrakeMonster?",
    "de": "Nutzt du BrakeMonster bereits?",
    "it": "Usi già BrakeMonster?",
    "es": "¿Ya usas BrakeMonster?"
  },
  "Install the signed update over the existing app. Don't uninstall first or you may lose locally saved data.": {
    "cnr": "Instaliraj potpisano ažuriranje preko postojeće aplikacije. Ne deinstaliraj je jer možeš izgubiti lokalno sačuvane podatke.",
    "de": "Installiere das signierte Update über die vorhandene App. Deinstalliere sie nicht vorher, da lokal gespeicherte Daten verloren gehen können.",
    "it": "Installa l’aggiornamento firmato sopra l’app esistente. Non disinstallarla prima, potresti perdere i dati locali.",
    "es": "Instala la actualización firmada sobre la app existente. No la desinstales antes, podrías perder los datos locales."
  },
  "The 7-day trial does not restart on reinstall or update.": {
    "cnr": "Proba od 7 dana ne počinje ponovo poslije reinstalacije ili ažuriranja.",
    "de": "Der 7-Tage-Test beginnt nach Neuinstallation oder Update nicht erneut.",
    "it": "La prova di 7 giorni non riparte con reinstallazioni o aggiornamenti.",
    "es": "La prueba de 7 días no se reinicia al reinstalar o actualizar."
  },
  "After expiry, PRO-only online features require an active license; basic local playback remains available.": {
    "cnr": "Nakon isteka PRO online funkcije zahtijevaju aktivnu licencu; osnovno lokalno puštanje ostaje dostupno.",
    "de": "Nach Ablauf benötigen die PRO-Onlinefunktionen eine aktive Lizenz; die einfache lokale Wiedergabe bleibt verfügbar.",
    "it": "Alla scadenza, le funzioni PRO online richiedono una licenza attiva; la riproduzione locale di base resta disponibile.",
    "es": "Al caducar, las funciones PRO en línea requieren una licencia activa; la reproducción local básica sigue disponible."
  },
  "Need a hand?": {
    "cnr": "Treba ti pomoć?",
    "de": "Brauchst du Hilfe?",
    "it": "Serve una mano?",
    "es": "¿Necesitas ayuda?"
  },
  "For installation, purchase questions or licensing, see": {
    "cnr": "Za instalaciju, kupovinu ili licencu pogledaj",
    "de": "Bei Fragen zu Installation, Kauf oder Lizenz siehe",
    "it": "Per installazione, acquisti o licenze, consulta",
    "es": "Para instalación, compras o licencias, consulta"
  },
  "or write to": {
    "cnr": "ili piši na",
    "de": "oder schreibe an",
    "it": "oppure scrivi a",
    "es": "o escribe a"
  },
  "VIEW ALL PRO PLANS": {
    "cnr": "SVI PRO PLANOVI",
    "de": "ALLE PRO-TARIFE ANSEHEN",
    "it": "VEDI TUTTI I PIANI PRO",
    "es": "VER TODOS LOS PLANES PRO"
  },
  "BACK TO TERAPHONIA": {
    "cnr": "NAZAD NA TERAPHONIJU",
    "de": "ZURÜCK ZU TERAPHONIA",
    "it": "TORNA A TERAPHONIA",
    "es": "VOLVER A TERAPHONIA"
  },
  "Official BrakeMonster PRO Android downloads.": {
    "cnr": "Zvanična preuzimanja BrakeMonster PRO aplikacije za Android.",
    "de": "Offizielle BrakeMonster-PRO-Downloads für Android.",
    "it": "Download ufficiali di BrakeMonster PRO per Android.",
    "es": "Descargas oficiales de BrakeMonster PRO para Android."
  },
  "The online store is temporarily closed. No payment can be initiated.": {
    "cnr": "Online prodavnica je privremeno zatvorena. Plaćanje nije moguće pokrenuti.",
    "de": "Der Onlineshop ist vorübergehend geschlossen. Es kann keine Zahlung gestartet werden.",
    "it": "Il negozio online è temporaneamente chiuso. Non è possibile avviare pagamenti.",
    "es": "La tienda en línea está cerrada temporalmente. No se puede iniciar ningún pago."
  },
  "BRAKEMONSTER PRO STORE IS OPEN. For secure automatic activation, install the Android app and open BUY PRO there. A normal browser visit has no installation token.": {
    "cnr": "BRAKEMONSTER PRO PRODAVNICA JE OTVORENA. Za sigurnu automatsku aktivaciju instaliraj Android aplikaciju i u njoj otvori BUY PRO. Obična posjeta iz browsera nema identifikator instalacije.",
    "de": "DER BRAKEMONSTER-PRO-SHOP IST GEÖFFNET. Installiere für eine sichere automatische Aktivierung die Android-App und öffne dort BUY PRO. Ein normaler Browserbesuch enthält keinen Installationstoken.",
    "it": "IL NEGOZIO BRAKEMONSTER PRO È APERTO. Per l’attivazione automatica sicura, installa l’app Android e apri BUY PRO al suo interno. Una normale visita dal browser non include il token dell’installazione.",
    "es": "LA TIENDA BRAKEMONSTER PRO ESTÁ ABIERTA. Para una activación automática segura, instala la app Android y abre BUY PRO dentro de ella. Una visita normal desde el navegador no contiene el identificador de instalación."
  },
  "GET THE APP TO BUY": {
    "cnr": "PREUZMI APP ZA KUPOVINU",
    "de": "ZUM KAUF APP HERUNTERLADEN",
    "it": "SCARICA L’APP PER ACQUISTARE",
    "es": "DESCARGA LA APP PARA COMPRAR"
  },
  "Review the final Creem price and terms before confirming payment.": {
    "cnr": "Provjeri konačnu Creem cijenu i uslove prije potvrde plaćanja.",
    "de": "Prüfe den endgültigen Creem-Preis und die Bedingungen, bevor du die Zahlung bestätigst.",
    "it": "Controlla il prezzo e le condizioni finali di Creem prima di confermare il pagamento.",
    "es": "Revisa el precio y las condiciones finales de Creem antes de confirmar el pago."
  },
  "CONTINUE TO SECURE CHECKOUT": {
    "cnr": "NASTAVI NA SIGURNO PLAĆANJE",
    "de": "WEITER ZUR SICHEREN ZAHLUNG",
    "it": "CONTINUA AL PAGAMENTO SICURO",
    "es": "CONTINUAR AL PAGO SEGURO"
  },
  "Checkout is currently unavailable. No payment was initiated by this page.": {
    "cnr": "Plaćanje trenutno nije dostupno. Ova stranica nije pokrenula plaćanje.",
    "de": "Die Zahlung ist derzeit nicht verfügbar. Diese Seite hat keine Zahlung gestartet.",
    "it": "Il pagamento non è al momento disponibile. Questa pagina non ha avviato alcun pagamento.",
    "es": "El pago no está disponible en este momento. Esta página no ha iniciado ningún pago."
  },
  "We could not verify the billing service. Checkout remains disabled.": {
    "cnr": "Nije moguće provjeriti servis za naplatu. Plaćanje ostaje isključeno.",
    "de": "Der Zahlungsdienst konnte nicht überprüft werden. Die Zahlung bleibt deaktiviert.",
    "it": "Impossibile verificare il servizio di pagamento. Il pagamento resta disattivato.",
    "es": "No se pudo verificar el servicio de pago. El pago permanece desactivado."
  },
  "Visit Help for assistance.": {
    "cnr": "Pogledaj POMOĆ za podršku.",
    "de": "Hilfe findest du unter HILFE.",
    "it": "Consulta la GUIDA per assistenza.",
    "es": "Consulta AYUDA para obtener asistencia."
  },
  "Language": {
    "cnr": "Jezik",
    "de": "Sprache",
    "it": "Lingua",
    "es": "Idioma"
  },
  "Automatic": {
    "cnr": "Automatski",
    "de": "Automatisch",
    "it": "Automatico",
    "es": "Automático"
  },
  "Main navigation": {
    "cnr": "Glavna navigacija",
    "de": "Hauptnavigation",
    "it": "Navigazione principale",
    "es": "Navegación principal"
  },
  "TERAPHONIA home": {
    "cnr": "TERAPHONIA početna",
    "de": "TERAPHONIA Startseite",
    "it": "TERAPHONIA home",
    "es": "TERAPHONIA inicio"
  },
  "Seven-day free trial": {
    "cnr": "Sedam dana besplatne probe",
    "de": "Sieben Tage kostenlos testen",
    "it": "Sette giorni di prova gratuita",
    "es": "Siete días de prueba gratis"
  },
  "BrakeMonster PRO plans": {
    "cnr": "BrakeMonster PRO planovi",
    "de": "BrakeMonster PRO-Tarife",
    "it": "Piani BrakeMonster PRO",
    "es": "Planes de BrakeMonster PRO"
  },
  "APK download": {
    "cnr": "Preuzimanje APK-a",
    "de": "APK-Download",
    "it": "Download APK",
    "es": "Descarga del APK"
  },
  "Install steps": {
    "cnr": "Koraci instalacije",
    "de": "Installationsschritte",
    "it": "Passaggi di installazione",
    "es": "Pasos de instalación"
  },
  "Animated BrakeMonster title, T-Rex DJ and two pterodactyl DJs": {
    "cnr": "Živi BrakeMonster naslov, T-Rex DJ i dvije pterodaktil DJ bake",
    "de": "Animierter BrakeMonster-Titel, T-Rex-DJ und zwei Pterodaktylus-DJs",
    "it": "Titolo animato BrakeMonster, T-Rex DJ e due DJ pterodattili",
    "es": "Título animado BrakeMonster, T-Rex DJ y dos DJ pterodáctilos"
  },
  "Young T-Rex DJ in an oversized MONTHLY cap with two pterodactyl record players": {
    "cnr": "Mladi T-Rex DJ s velikom kapom MONTHLY i dva pterodaktil gramofona",
    "de": "Junger T-Rex-DJ mit großer MONTHLY-Kappe und zwei Pterodaktylus-Plattenspielern",
    "it": "Giovane T-Rex DJ con grande cappello MONTHLY e due giradischi pterodattili",
    "es": "Joven T-Rex DJ con gorra grande MONTHLY y dos tocadiscos pterodáctilos"
  },
  "Elvis-style T-Rex performing under the neon Monster of the Year sign": {
    "cnr": "T-Rex u Elvis stilu ispod neonskog natpisa Monster of the Year",
    "de": "T-Rex im Elvis-Stil unter dem Neonschild Monster of the Year",
    "it": "T-Rex in stile Elvis sotto l’insegna al neon Monster of the Year",
    "es": "T-Rex al estilo Elvis bajo el letrero de neón Monster of the Year"
  },
  "Elder Elvis-style T-Rex reading the BrakeMonster for Lifetime newspaper": {
    "cnr": "Stari T-Rex u Elvis stilu čita novine BrakeMonster for Lifetime",
    "de": "Älterer T-Rex im Elvis-Stil liest die Zeitung BrakeMonster for Lifetime",
    "it": "T-Rex anziano in stile Elvis legge il giornale BrakeMonster for Lifetime",
    "es": "T-Rex mayor al estilo Elvis lee el periódico BrakeMonster for Lifetime"
  },
  "T-Rex DJ with MONTHLY cap": {
    "cnr": "T-Rex DJ s kapom MONTHLY",
    "de": "T-Rex-DJ mit MONTHLY-Kappe",
    "it": "T-Rex DJ con cappello MONTHLY",
    "es": "T-Rex DJ con gorra MONTHLY"
  },
  "Elvis T-Rex under Monster of the Year neon": {
    "cnr": "Elvis T-Rex ispod neona Monster of the Year",
    "de": "Elvis-T-Rex unter dem Neonzeichen Monster of the Year",
    "it": "T-Rex Elvis sotto il neon Monster of the Year",
    "es": "T-Rex Elvis bajo el neón Monster of the Year"
  },
  "Older T-Rex reading BrakeMonster for Lifetime newspaper": {
    "cnr": "Stari T-Rex čita novine BrakeMonster for Lifetime",
    "de": "Älterer T-Rex liest die Zeitung BrakeMonster for Lifetime",
    "it": "T-Rex anziano legge il giornale BrakeMonster for Lifetime",
    "es": "T-Rex mayor lee el periódico BrakeMonster for Lifetime"
  },
  "BrakeMonster PRO green T-Rex app icon": {
    "cnr": "Zelena T-Rex ikonica BrakeMonster PRO aplikacije",
    "de": "Grünes T-Rex-App-Symbol von BrakeMonster PRO",
    "it": "Icona verde T-Rex dell’app BrakeMonster PRO",
    "es": "Icono verde T-Rex de la app BrakeMonster PRO"
  },
  "Help topics": {
    "cnr": "Teme pomoći",
    "de": "Hilfethemen",
    "it": "Argomenti della guida",
    "es": "Temas de ayuda"
  },
  "BrakeMonster PRO · Help & stage guide": {
    "cnr": "BrakeMonster PRO · Pomoć i uputstvo",
    "de": "BrakeMonster PRO · Hilfe und Bühnenleitfaden",
    "it": "BrakeMonster PRO · Guida e uso sul palco",
    "es": "BrakeMonster PRO · Ayuda y guía para el escenario"
  }
};

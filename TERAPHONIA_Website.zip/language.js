'use strict';
(() => {
  const supported=['en','cnr','de','it','es'];
  const names=['English','Crnogorski','Deutsch','Italiano','Español'];
  let chosen='auto';
  try { chosen=localStorage.getItem('bm-site-language')||'auto'; } catch (_) {}
  function resolve(value) {
    if (supported.includes(value)) return value;
    for (const value of navigator.languages||[navigator.language||'en']) {
      const lang=value.toLowerCase().split('-')[0];
      if (['cnr','sr','hr','bs','sh','me'].includes(lang)) return 'cnr';
      if (supported.includes(lang)) return lang;
    }
    return 'en';
  }
  const nav={en:['HOME','ANDROID APP','PRO PLANS','HELP'],cnr:['POČETNA','ANDROID APP','PRO PLANOVI','HELP'],de:['STARTSEITE','ANDROID APP','PRO-TARIFE','HILFE'],it:['HOME','APP ANDROID','PIANI PRO','GUIDA'],es:['INICIO','APP ANDROID','PLANES PRO','AYUDA']};
  const wrap=document.createElement('label');wrap.className='language-picker';
  wrap.append(document.createTextNode('Language / Jezik '));
  const select=document.createElement('select');select.setAttribute('aria-label','Language / Jezik');
  [['auto','Auto'],...supported.map((l,i)=>[l,names[i]])].forEach(([value,title])=>{const o=document.createElement('option');o.value=value;o.textContent=title;select.append(o);});
  select.value=supported.includes(chosen)?chosen:'auto';wrap.append(select);document.querySelector('header')?.append(wrap);
  function apply() {
    const lang=resolve(select.value);window.BM_LANGUAGE=lang;document.documentElement.lang=lang==='cnr'?'cnr-ME':lang;
    document.querySelectorAll('header nav a').forEach((a,i)=>{if(nav[lang][i]) a.textContent=nav[lang][i];});
    const d=window.BM_HELP?.[lang];
    if (d && document.getElementById('guide')) {
      const u=d.ui;
      document.title='BrakeMonster PRO · '+nav[lang][3];
      document.querySelector('.hero .eyebrow').textContent=u[0];document.querySelector('.hero h1').textContent=u[1];
      document.querySelector('.hero .lead').textContent=u[2];document.querySelector('.hero .note').textContent=u[10];
      document.querySelector('#guide h2').textContent=u[3];
      document.querySelectorAll('.topic').forEach((section,i)=>{
        section.querySelector('h2').textContent=d.topics[i][0];section.querySelector('p:not(.eyebrow)').textContent=d.topics[i][1];
        section.querySelector('.eyebrow').textContent=String(i+1).padStart(2,'0')+' / '+nav[lang][3];
        section.querySelector('a').textContent=u[4];document.querySelectorAll('.topic-nav a')[i].textContent=d.topics[i][0];
      });
      document.querySelector('.status-card h2').textContent=u[5];document.querySelector('.status-card p').textContent=u[6];document.querySelector('.status-card .button').textContent=u[7];
      document.querySelector('footer a').textContent=u[8];document.querySelector('footer a:last-child').textContent=u[9];
    }
    window.dispatchEvent(new Event('bm-language-change'));
  }
  select.addEventListener('change',()=>{try{localStorage.setItem('bm-site-language',select.value);}catch(_){} apply();});apply();
})();

'use strict';
(() => {
  const supported=['en','cnr','de','it','es'];
  const names=['English','Crnogorski','Deutsch','Italiano','Español'];
  let chosen='auto';
  try { chosen=localStorage.getItem('bm-site-language')||'auto'; } catch (_) {}
  function resolve(value) {
    if(supported.includes(value)) return value;
    for(const locale of navigator.languages||[navigator.language||'en']) {
      const lang=locale.toLowerCase().split('-')[0];
      if(['cnr','sr','hr','bs','sh','me'].includes(lang)) return 'cnr';
      if(supported.includes(lang)) return lang;
    }
    return 'en';
  }
  let lang=resolve(chosen);
  const originalText=new WeakMap(), originalAttrs=new WeakMap();
  function translate(source) { return window.BM_TRANSLATIONS?.[source]?.[lang]||source; }
  window.BM_I18N={text:translate};
  const wrap=document.createElement('label');wrap.className='language-picker';
  const caption=document.createElement('span');wrap.append(caption);
  const select=document.createElement('select');
  [['auto','Automatic'],...supported.map((l,i)=>[l,names[i]])].forEach(([value,title])=>{
    const option=document.createElement('option');option.value=value;option.textContent=title;select.append(option);
  });
  select.value=supported.includes(chosen)?chosen:'auto';wrap.append(select);
  (document.querySelector('.site-header .header-inner')||document.querySelector('header'))?.append(wrap);
  function apply() {
    lang=resolve(select.value);window.BM_LANGUAGE=lang;
    document.documentElement.lang=lang==='cnr'?'cnr-ME':lang;
    // Keep original text nodes so repeated switching retains links, emphasis and event handlers.
    const walker=document.createTreeWalker(document.documentElement,NodeFilter.SHOW_TEXT);
    const nodes=[];while(walker.nextNode()) nodes.push(walker.currentNode);
    for(const node of nodes) {
      if(node.parentElement?.closest('script,style,.language-picker,#purchase-status,.checkout-plan,#release-status,#release-details,#download,#release-hash,.topic,.topic-nav'))continue;
      if(!originalText.has(node))originalText.set(node,node.nodeValue);
      const source=originalText.get(node), trimmed=source.trim();
      if(trimmed)node.nodeValue=source.replace(trimmed,translate(trimmed));
    }
    for(const el of document.querySelectorAll('[aria-label],[alt],[title],meta[name="description"]')) {
      if(el.closest('.language-picker'))continue;
      if(!originalAttrs.has(el)) {
        const attrs={};for(const name of ['aria-label','alt','title','content'])if(el.hasAttribute(name))attrs[name]=el.getAttribute(name);
        originalAttrs.set(el,attrs);
      }
      for(const [name,value] of Object.entries(originalAttrs.get(el)))el.setAttribute(name,translate(value));
    }
    caption.textContent=translate('Language')+' ';
    select.setAttribute('aria-label',translate('Language'));select.options[0].textContent=translate('Automatic');
    const d=window.BM_HELP?.[lang];
    if(d&&document.getElementById('guide')) {
      const u=d.ui;
      document.title='BrakeMonster PRO · '+translate('HELP');
      document.querySelector('.hero .eyebrow').textContent=u[0];document.querySelector('.hero h1').textContent=u[1];
      document.querySelector('.hero .lead').textContent=u[2];document.querySelector('.hero .note').textContent=u[10];
      document.querySelector('#guide h2').textContent=u[3];
      document.querySelectorAll('.topic').forEach((section,i)=>{
        section.querySelector('h2').textContent=d.topics[i][0];section.querySelector('p:not(.eyebrow)').textContent=d.topics[i][1];
        section.querySelector('.eyebrow').textContent=String(i+1).padStart(2,'0')+' / '+translate('HELP');
        section.querySelector('a').textContent=u[4];document.querySelectorAll('.topic-nav a')[i].textContent=d.topics[i][0];
      });
      document.querySelector('.status-card h2').textContent=u[5];document.querySelector('.status-card p').textContent=u[6];document.querySelector('.status-card .button').textContent=u[7];
      document.querySelector('footer a').textContent=u[8];document.querySelector('footer a:last-child').textContent=u[9];
    }
    window.dispatchEvent(new Event('bm-language-change'));
  }
  select.addEventListener('change',()=>{try{localStorage.setItem('bm-site-language',select.value);}catch(_){}apply();});apply();
})();

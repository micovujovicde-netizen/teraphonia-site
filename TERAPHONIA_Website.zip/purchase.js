"use strict";
(async()=>{
  const status=document.getElementById('purchase-status');
  const buttons=Array.from(document.querySelectorAll('.checkout-plan'));
  const token=new URLSearchParams(location.hash.slice(1)).get('device');
  // Device token stays in a URL fragment on arrival, then is removed from history.
  history.replaceState(null,'',location.pathname);
  try {
    const response=await fetch('commercial-config.json',{cache:'no-store'});
    if(!response.ok)throw new Error('config');
    const cfg=await response.json();
    if(cfg.billingEnabled!==true) { status.textContent='The online store is temporarily closed. No payment can be initiated.'; return; }
    if(cfg.apiBase!=='https://brakemonster-license.micovujovic-de.workers.dev/v1')throw new Error('api');
    const health=await fetch(cfg.apiBase+'/health',{cache:'no-store',signal:AbortSignal.timeout(10000)});
    if(!health.ok || (await health.json()).billingEnabled!==true)throw new Error('health');
    if(!/^[a-f0-9]{64}$/.test(token||'')) {
      status.textContent='BRAKEMONSTER PRO STORE IS OPEN. For secure automatic activation, install the Android app and open BUY PRO there. A normal browser visit has no installation token.';
      buttons.forEach(b=>{
        b.disabled=false;
        b.textContent='GET THE APP TO BUY';
        b.addEventListener('click',()=>{location.assign('index.html#download-panel');});
      });
      return;
    }
    status.textContent='Review the final Creem price and terms before confirming payment.';
    buttons.forEach(b=>{
      b.disabled=false;b.textContent='CONTINUE TO SECURE CHECKOUT';
      b.addEventListener('click',async()=>{
        buttons.forEach(x=>x.disabled=true);
        try {
          const r=await fetch(cfg.apiBase+'/checkout',{
            method:'POST',
            headers:{'Authorization':'Bearer '+token,'Content-Type':'application/json'},
            body:JSON.stringify({plan:b.dataset.plan}),
            signal:AbortSignal.timeout(20000)
          });
          if(!r.ok)throw new Error('checkout');
          const payload=await r.json();const u=new URL(payload.url);
          if(u.protocol!=='https:' || u.username || u.password || u.port ||
             !(u.hostname==='creem.io'||u.hostname.endsWith('.creem.io')))throw new Error('url');
          location.assign(u.href);
        }catch(e){
          status.textContent='Checkout is currently unavailable. No payment was initiated by this page.';
          buttons.forEach(x=>x.disabled=false);
        }
      });
    });
  }catch(e){
    status.textContent='We could not verify the billing service. Checkout remains disabled.';
  }
})();

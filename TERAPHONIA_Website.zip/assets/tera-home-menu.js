/* The original BM language.js controls its own pages. Keep only the homepage
   product navigation localized after that script runs, without changing it. */
(()=>{'use strict';
const labels={
 en:{home:'HOME',download:'DOWNLOAD TERAPHON',plans:'TERAPHON PLANS',help:'HELP',menu:'MENU',bm:'BrakeMonster PRO',bmSub:'Separate Android app',bmPlans:'BrakeMonster PRO plans',bmPlansSub:'Separate purchase and licence',contact:'CONTACT'},
 cnr:{home:'POČETNA',download:'PREUZMI TERAPHON',plans:'TERAPHON PLANOVI',help:'POMOĆ',menu:'MENI',bm:'BrakeMonster PRO',bmSub:'Odvojena Android aplikacija',bmPlans:'BrakeMonster PRO planovi',bmPlansSub:'Zasebna kupovina i licenca',contact:'KONTAKT'},
 de:{home:'START',download:'TERAPHON DOWNLOAD',plans:'TERAPHON TARIFE',help:'HILFE',menu:'MENÜ',bm:'BrakeMonster PRO',bmSub:'Separate Android-App',bmPlans:'BrakeMonster PRO Tarife',bmPlansSub:'Separater Kauf und Lizenz',contact:'KONTAKT'},
 it:{home:'HOME',download:'SCARICA TERAPHON',plans:'PIANI TERAPHON',help:'AIUTO',menu:'MENU',bm:'BrakeMonster PRO',bmSub:'App Android separata',bmPlans:'Piani BrakeMonster PRO',bmPlansSub:'Acquisto e licenza separati',contact:'CONTATTO'},
 es:{home:'INICIO',download:'DESCARGAR TERAPHON',plans:'PLANES TERAPHON',help:'AYUDA',menu:'MENÚ',bm:'BrakeMonster PRO',bmSub:'Aplicación Android distinta',bmPlans:'Planes BrakeMonster PRO',bmPlansSub:'Compra y licencia separadas',contact:'CONTACTO'},
 fr:{home:'ACCUEIL',download:'TÉLÉCHARGER TERAPHON',plans:'OFFRES TERAPHON',help:'AIDE',menu:'MENU',bm:'BrakeMonster PRO',bmSub:'Application Android séparée',bmPlans:'Offres BrakeMonster PRO',bmPlansSub:'Achat et licence séparés',contact:'CONTACT'}
};
function apply(){
 const nav=document.querySelector('nav[data-tera-home-nav]');if(!nav)return;
 let lang=document.querySelector('#language, .language-picker select')?.value;
 if(!labels[lang]){try{lang=localStorage.getItem('bm-site-language')}catch(_){}}
 if(!labels[lang]){const l=(navigator.language||'en').toLowerCase().split('-')[0];lang=['sr','bs','hr','me','cnr'].includes(l)?'cnr':l}
 const dict=labels[lang]||labels.en;
 document.querySelectorAll('[data-tera-home-label]').forEach(node=>{
   const key=node.getAttribute('data-tera-home-label'); if(dict[key]) node.textContent=dict[key];
 });
}
document.querySelector('#language, .language-picker select')?.addEventListener('change',apply);
window.addEventListener('bm-language-change',apply);
window.addEventListener('storage',apply);
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',apply);else apply();
})();

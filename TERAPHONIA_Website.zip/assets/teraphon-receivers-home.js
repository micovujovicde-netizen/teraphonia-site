(() => {
  'use strict';
  const strings = {
    en: {kicker:'YOUR MUSIC · YOUR PLACE · YOUR CONTROL',description:'Send TERAPHON music wirelessly to your existing sound system. Choose your Windows PC or a second Android phone.',wifi:'CD-quality Wi-Fi audio · 4-digit PIN · No manual IP',button:'DOWNLOAD RECEIVERS',note:'See connection guides for Windows and Android.'},
    cnr:{kicker:'TVOJA MUZIKA · TVOJ PROSTOR · TVOJA KONTROLA',description:'Šalji muziku iz TERAPHON-a bežično na postojeće ozvučenje. Izaberi Windows računar ili drugi Android telefon.',wifi:'CD kvalitet preko Wi-Fi mreže · PIN od 4 cifre · Bez ručne IP adrese',button:'PREUZMI RECEIVERE',note:'Pogledaj uputstva za Windows i Android.'},
    de: {kicker:'DEINE MUSIK · DEIN ORT · DEINE KONTROLLE',description:'Übertrage Musik aus TERAPHON kabellos auf deine bestehende Soundanlage – über einen Windows-PC oder ein zweites Android-Gerät.',wifi:'CD-Qualität über WLAN · 4-stellige PIN · Keine manuelle IP',button:'RECEIVER HERUNTERLADEN',note:'Anleitungen für Windows und Android ansehen.'},
    it: {kicker:'LA TUA MUSICA · IL TUO SPAZIO · IL TUO CONTROLLO',description:'Invia la musica di TERAPHON al tuo impianto audio tramite un PC Windows o un secondo dispositivo Android.',wifi:'Qualità CD via Wi-Fi · PIN a 4 cifre · Nessun IP manuale',button:'SCARICA I RECEIVER',note:'Consulta le guide per Windows e Android.'},
    es: {kicker:'TU MÚSICA · TU ESPACIO · TU CONTROL',description:'Envía música desde TERAPHON a tu equipo de sonido por Wi-Fi, usando un PC Windows u otro dispositivo Android.',wifi:'Calidad CD por Wi-Fi · PIN de 4 dígitos · Sin IP manual',button:'DESCARGAR RECEPTORES',note:'Consulta las guías de conexión para Windows y Android.'},
    fr: {kicker:'VOTRE MUSIQUE · VOTRE ESPACE · VOTRE CONTRÔLE',description:'Diffusez la musique de TERAPHON vers votre installation audio par Wi-Fi, avec un PC Windows ou un second appareil Android.',wifi:'Qualité CD via Wi-Fi · Code PIN à 4 chiffres · Sans IP manuelle',button:'TÉLÉCHARGER LES RÉCEPTEURS',note:'Consultez les guides Windows et Android.'}
  };
  function resolveLanguage() {
    const declared = window.BM_LANGUAGE;
    if (Object.prototype.hasOwnProperty.call(strings, declared)) return declared;
    try {const v=localStorage.getItem('bm-site-language');if(Object.prototype.hasOwnProperty.call(strings,v))return v;} catch (_) {}
    const lang=(document.documentElement.lang||navigator.language||'en').toLowerCase().split('-')[0];
    if(['me','sr','hr','bs','cnr'].includes(lang))return 'cnr';
    return Object.prototype.hasOwnProperty.call(strings,lang)?lang:'en';
  }
  const networkCopy = {
  "en": [
    "You no longer need to break through walls at your property and run tens of metres of cable through them.",
    "Enlarge network illustration",
    "Close illustration"
  ],
  "cnr": [
    "Ne morate više lomiti zidove na vašem objektu i vući na desetine metara kablova kroz njih",
    "Uvećaj ilustraciju mreže",
    "Zatvori ilustraciju"
  ],
  "de": [
    "Sie müssen in Ihrem Gebäude keine Wände mehr aufbrechen und keine Dutzenden Meter Kabel verlegen.",
    "Netzwerkgrafik vergrößern",
    "Grafik schließen"
  ],
  "it": [
    "Non dovete più rompere i muri della vostra struttura e farvi passare decine di metri di cavi.",
    "Ingrandisci lo schema di rete",
    "Chiudi lo schema"
  ],
  "es": [
    "Ya no tienes que romper las paredes de tu establecimiento ni pasar decenas de metros de cable por ellas.",
    "Ampliar la ilustración de la red",
    "Cerrar la ilustración"
  ],
  "fr": [
    "Vous n’avez plus à ouvrir les murs de votre établissement ni à y faire passer des dizaines de mètres de câbles.",
    "Agrandir le schéma du réseau",
    "Fermer le schéma"
  ]
};

  const cambridgeCopy = {
  "en": [
    "Your Cambridge plays again. Just one tap.",
    "Enlarge Cambridge illustration",
    "TERAPHON on a phone with three Cambridge Audio players displaying TERAPHON"
  ],
  "cnr": [
    "Vaš Cambridge ponovo svira. Dovoljan je jedan dodir.",
    "Uvećaj Cambridge ilustraciju",
    "TERAPHON na telefonu i na ekranima tri Cambridge Audio plejera"
  ],
  "de": [
    "Ihr Cambridge spielt wieder. Ein Fingertipp genügt.",
    "Cambridge-Illustration vergrößern",
    "TERAPHON auf einem Smartphone und auf den Displays dreier Cambridge-Audio-Player"
  ],
  "it": [
    "Il tuo Cambridge torna a suonare. Basta un tocco.",
    "Ingrandisci l’illustrazione Cambridge",
    "TERAPHON sul telefono e sui display di tre lettori Cambridge Audio"
  ],
  "es": [
    "Tu Cambridge vuelve a sonar. Basta con un toque.",
    "Ampliar la ilustración de Cambridge",
    "TERAPHON en un teléfono y en las pantallas de tres reproductores Cambridge Audio"
  ],
  "fr": [
    "Votre Cambridge joue à nouveau. Un seul geste suffit.",
    "Agrandir l’illustration Cambridge",
    "TERAPHON sur un téléphone et sur les écrans de trois lecteurs Cambridge Audio"
  ]
};

  function wireViewer(prefix) {
    const launch = document.getElementById(prefix + '-open');
    const viewer = document.getElementById(prefix + '-viewer');
    const exit = document.getElementById(prefix + '-close');
    if (!launch || !viewer || !exit || typeof viewer.showModal !== 'function') return;
    launch.addEventListener('click', event => {
      if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      event.preventDefault();
      viewer.showModal();
      document.documentElement.classList.add('tph-network-expanded');
    });
    exit.addEventListener('click', () => viewer.close());
    viewer.addEventListener('close', () => {
      document.documentElement.classList.remove('tph-network-expanded');
      launch.focus({preventScroll:true});
    });
  }

  wireViewer('tph-network');
  wireViewer('tph-cambridge');

  function update() {
    const language = resolveLanguage();
    const t = strings[language];
    const lead = document.getElementById('tph-network-lead');
    const launch = document.getElementById('tph-network-open');
    const exit = document.getElementById('tph-network-close');
    if (lead && launch && exit) {
      const [text, expand, close] = networkCopy[language];
      lead.textContent = text;
      launch.setAttribute('aria-label', expand);
      exit.setAttribute('aria-label', close);
    }
    const cambridgeLaunch = document.getElementById('tph-cambridge-open');
    const cambridgeExit = document.getElementById('tph-cambridge-close');
    if (cambridgeLaunch && cambridgeExit) {
      const [tagline, expand, description] = cambridgeCopy[language];
      const cambridgeLead = document.getElementById('tph-cambridge-lead');
      if (cambridgeLead) cambridgeLead.textContent = tagline;
      cambridgeLaunch.setAttribute('aria-label', expand);
      cambridgeExit.setAttribute('aria-label', networkCopy[language][2]);
      document.querySelectorAll('#tph-cambridge-open img, #tph-cambridge-viewer img')
        .forEach(img => { img.alt = description; });
    }
    document.querySelectorAll('#teraphon-home-receivers [data-tph-rx]').forEach(el=>{
      const key=el.dataset.tphRx;
      if(t[key])el.textContent=t[key];
    });
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',update);else update();
  window.addEventListener('bm-language-change',update);
})();
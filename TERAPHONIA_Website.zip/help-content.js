window.BM_HELP = {
  "en": {
    "ui": [
      "THE BRAKEMONSTER GUIDE",
      "READY. SET. PLAY.",
      "Your guide for Android phones and tablets.",
      "WHAT DO YOU NEED?",
      "BACK TO GUIDE ↑",
      "LET’S GET YOU PLAYING.",
      "Include your app version and device model.",
      "EMAIL SUPPORT",
      "HOME",
      "BACK TO TOP ↑",
      "Updated 7 November 2026 · v276 / 1.0.188-pro.136"
    ],
    "topics": [
      [
        "INSTALL & UPDATE",
        "Download only the signed APK linked on this website. Allow installation from your browser when Android asks. For an update, install over the existing app; keep the same signing identity. Do not uninstall to update: uninstalling can erase playlists, settings and your installation identity. BACKUP ALL first. If no verified APK is published, the download stays unavailable. In the app, CHECK FOR UPDATES checks for a newer release. UPDATE first downloads and verifies the APK; Android must then confirm installation. If Android asks for permission to install from this source, grant it and return to the app. The app can reopen a stalled installation prompt and reports success only after the installed version is confirmed. If installation still does not start, open the downloaded APK again. Keep your app and playlists installed."
      ],
      [
        "START HERE",
        "Open LOCAL FILES to choose a music folder, or use WEB SEARCH. QUEUE is your performance queue. Select a song to play; PLAY / PAUSE, BACK, NEXT and STOP remain in the lower player controls. Use the progress rope to seek. Keep a tested local playlist ready for your performance."
      ],
      [
        "LOCAL FILES",
        "Choose a folder and grant Android access when asked. Local MP3, FLAC and WAV files require readable files and valid folder permission. If a folder was moved or permission was removed, select it again. LOCAL SEARCH filters local songs. Missing files must be relinked or removed; their playlist entry does not restore the audio file."
      ],
      [
        "QUEUE & WEB SEARCH",
        "Use WEB SEARCH to find a song. With ADD TO QUEUE enabled, selections go to QUEUE without interrupting playback. With that toggle off, a web selection is saved behind the current song in the playing playlist; when nothing plays it goes to QUEUE. Songs saved into the playing playlist stay there after restart, and corresponding queue copies are removed. Verify the destination before adding a large set."
      ],
      [
        "PLAYLISTS & BMQ",
        "Tap a playlist stone to open it. Long-press for MOVE, RENAME and DELETE where allowed. The welcome playlist and QUEUE have protections. SAVE AS PL saves the queue as a playlist. A .bmq entry is a saved web-song reference, not an MP3 download; playback depends on internet and source availability. EDIT changes the entry details. CLEAR applies to QUEUE."
      ],
      [
        "XL · FULL / BACK · + / −",
        "XL opens the large vertical playlist chooser. NORMAL returns to the compact view. FULL expands the song list or browser; BACK restores the previous layout. + / − adjust the display size in that view. Long-press an XL playlist, choose MOVE, then drag to a destination and release, or tap a destination stone. Hold near an edge to scroll while moving. Pinned navigation and protected playlists are not move targets."
      ],
      [
        "MIX & ROLLMONSTER FX",
        "MIX opens the dual-deck controls and crossfader. AUTO MIX handles transitions; allow the next track to buffer. WAIT means the next audio is not ready yet. FX opens RollMonster: beat-timed effects and loop controls. Turn LOOP off to return to normal playback. Test your network and Bluetooth connection before a show; online sources may buffer."
      ],
      [
        "BACKUP & RESTORE",
        "Open HELP / ABOUT and choose BACKUP ALL. Save the ZIP somewhere safe. Use the backup import option to restore a compatible backup. WAIT and a rotating indicator mean an operation is still running. Playlist loading also shows a progress indicator. A playlist backup does not include paid-license ownership or necessarily include the original local audio files; keep those separately."
      ],
      [
        "ACTIVATE PRO · THREE DEVICES",
        "Start the first purchase from BUY PRO inside the app so the installation is linked. After payment, return to the app and wait for the server check. On a second or third device, open HELP / ABOUT → ACTIVATE PRO, enter the same BM1 code and tap ACTIVATE. PRO is shown only after the server confirms an active paid license. One purchased license supports at most three active installations; a fourth is refused until a slot is released. TEST purchases and codes do not activate production."
      ],
      [
        "MY DEVICES & REPLACEMENT",
        "On an active paid license, open HELP / ABOUT → MY DEVICES. Choose SHOW ACTIVATION CODE and COPY ACTIVATION CODE to use it on your other devices. Review the occupied slots; THIS DEVICE identifies the current installation. To replace a device, choose its RELEASE button and confirm, then activate the replacement. Releasing a slot does not delete the purchased license. Keep the code private. Reinstalling may create a new installation identity, so do not uninstall to update."
      ],
      [
        "PLANS & RENEWAL",
        "A new eligible device receives a seven-day PRO trial from its first server-confirmed trial start. Rechecking, updating or reinstalling does not restart that recorded period. After expiry, PRO-only online features are locked; basic local playback remains available. Trial works independently of checkout availability. Monthly: €2.99, recurring. Yearly: €19.90, recurring. Lifetime: €39, one-time. Checkout is available when the live billing service confirms that sales are open. Review the final Creem terms before purchase. MANAGE SUBSCRIPTION manages recurring plans. Activation and verification need internet; renewal grace is determined by the server."
      ],
      [
        "TROUBLESHOOTING & SUPPORT",
        "Still seeing TRIAL after payment? Reconnect to the internet, return to the app and reopen HELP / ABOUT so the server can refresh your license. Make sure you started the purchase from BUY PRO on this device. Do not buy repeatedly to diagnose an activation issue. For another device, use ACTIVATE PRO with your activation code. If an issue persists, email support with your app version, device model and the exact error. Keep activation codes and payment details private."
      ],
      [
        "RADIO · COUNTRIES & STATIONS",
        "Open RADIO → COUNTRY, choose a country, then tap a station to play it through QUEUE. Tap ☆ beside a country to pin it at the top: the first selected country stays first, the next goes below it. Tap ★ again to unpin it. Pinning a country does not open or play a station. Station availability and loading depend on the broadcaster and your internet connection."
      ],
      [
        "RADIO FAVORITES · REORDER",
        "While a radio station is shown in QUEUE, tap its ★ to save it. Open RADIO → ★ FAVORITES for saved stations. Long-press a favorite, drag it up or down, then release to save the new order. Hold near the top or bottom edge to scroll while dragging. Tap a favorite to play it; use its remove control to delete only that saved favorite. Country pins and saved radio stations are included in compatible BACKUP ALL backups."
      ],
      [
        "ACTIVE PLAYLIST & LIVE QUEUE",
        "The playlist that is actually playing shows a large transparent play triangle on its stone button. The animated stone DJ console is the QUEUE button and has no extra triangle. You can browse the button row freely: after 10 seconds without touching, scrolling or flinging, the playing button returns to view. It is centered where space allows; buttons at the beginning, including QUEUE, stay toward the left when they cannot reach the center. The return pauses during dragging, moving or an open playlist menu."
      ]
    ]
  },
  "cnr": {
    "ui": [
      "BRAKEMONSTER UPUTSTVO",
      "SPREMNI. PLAY.",
      "Uputstvo za Android telefon i tablet.",
      "ŠTO TI TREBA?",
      "NA UPUTSTVO ↑",
      "PUSTIMO MUZIKU.",
      "Pošalji verziju aplikacije i model uređaja.",
      "PIŠI PODRŠCI",
      "POČETNA",
      "NA VRH ↑",
      "Ažurirano 7. novembra 2026 · v276 / 1.0.188-pro.136"
    ],
    "topics": [
      [
        "INSTALACIJA I UPDATE",
        "Preuzmi potpisani APK sa ovog sajta. Kada Android zatraži, dozvoli instalaciju iz browsera. Update instaliraj preko postojeće aplikacije, bez deinstalacije: ona može obrisati playliste, podešavanja i identitet instalacije. Prvo napravi BACKUP ALL. Download se uključuje tek kada je javni APK objavljen i provjeren. U aplikaciji CHECK FOR UPDATES provjerava novo izdanje. UPDATE prvo preuzima i provjerava APK; zatim potvrdi instalaciju u Androidu. Ako traži dozvolu za instalaciju iz ovog izvora, odobri je i vrati se u aplikaciju. Aplikacija može ponovo otvoriti zastali upit i prikazuje uspjeh tek kada potvrdi instaliranu verziju. Ako instalacija ipak ne počne, ponovo otvori preuzeti APK. Sačuvaj instaliranu aplikaciju i playliste."
      ],
      [
        "POČETAK",
        "Otvori LOCAL FILES i izaberi muzički folder ili koristi WEB SEARCH. QUEUE je red pjesama za puštanje. Dodirni pjesmu za PLAY; PLAY / PAUSE, BACK, NEXT i STOP su u donjoj traci. Konopac napretka služi za pomjeranje kroz pjesmu. Za nastup pripremi i provjerenu lokalnu playlistu."
      ],
      [
        "LOCAL FILES",
        "Izaberi folder i odobri Android pristup. MP3, FLAC i WAV moraju biti čitljivi. Ako je folder premješten ili je dozvola uklonjena, izaberi ga ponovo. LOCAL SEARCH pretražuje lokalne pjesme. Fajl koji nedostaje poveži ponovo ili ukloni: zapis u playlisti ne vraća sam audio fajl."
      ],
      [
        "QUEUE I WEB SEARCH",
        "Uz uključeno ADD TO QUEUE, web izbor ide u QUEUE bez prekidanja muzike. Kada je isključeno, izbor se čuva iza trenutne pjesme u playlisti koja svira; ako ništa ne svira, ide u QUEUE. Pjesme dodate playlisti ostaju poslije restarta, a odgovarajuće kopije iz reda se uklanjaju. Prije većeg dodavanja provjeri odredište."
      ],
      [
        "PLAYLISTE I BMQ",
        "Dodirni kameno dugme playliste. Dugi pritisak otvara MOVE, preimenovanje i brisanje gdje je dozvoljeno. WELCOME i QUEUE imaju zaštite. SAVE AS PL čuva red kao playlistu. .bmq je zapis web pjesme, a ne preuzeti MP3; puštanje zavisi od interneta i izvora. EDIT mijenja podatke zapisa. CLEAR prazni QUEUE."
      ],
      [
        "XL · FULL / BACK · + / −",
        "XL otvara veliki vertikalni izbor playlista; NORMAL vraća mali prikaz. FULL proširuje listu ili browser, a BACK vraća prethodni raspored. + / − mijenjaju veličinu prikaza. Za pomjeranje XL playliste drži dugme, izaberi MOVE pa prevuci i pusti ili dodirni odredište. Držanje uz ivicu pomjera listu. Zaštićene playliste i nepomična navigacija nijesu odredišta."
      ],
      [
        "MIX I ROLLMONSTER FX",
        "MIX otvara dvije palube i crossfader. AUTO MIX radi prelaze; sačekaj da se sljedeća pjesma učita. WAIT znači da zvuk još nije spreman. FX otvara RollMonster efekte i LOOP. Isključi LOOP za normalno puštanje. Prije nastupa provjeri internet i Bluetooth; web izvori mogu zastajati zbog učitavanja."
      ],
      [
        "BACKUP I VRAĆANJE",
        "U HELP / ABOUT otvori BACKUP ALL i sačuvaj ZIP na sigurnom. Opcijom za uvoz backupa vrati kompatibilnu kopiju. WAIT i kružić znače da obrada traje; i učitavanje playliste prikazuje indikator. Backup playlista ne čuva vlasništvo PRO licence i ne mora sadržati originalne lokalne audio fajlove. Njih čuvaj posebno."
      ],
      [
        "ACTIVATE PRO · TRI UREĐAJA",
        "Prvu kupovinu pokreni iz BUY PRO u aplikaciji da se instalacija poveže. Poslije plaćanja vrati se i sačekaj provjeru servera. Na drugom ili trećem uređaju otvori HELP / ABOUT → ACTIVATE PRO, unesi isti BM1 kod i dodirni ACTIVATE. PRO se prikazuje tek kada server potvrdi aktivnu plaćenu licencu. Jedna kupljena licenca podržava najviše tri aktivne instalacije; četvrta se odbija dok ne oslobodiš mjesto. TEST kodovi i kupovine ne aktiviraju produkciju."
      ],
      [
        "MY DEVICES I ZAMJENA",
        "Uz aktivnu plaćenu licencu otvori HELP / ABOUT → MY DEVICES. SHOW ACTIVATION CODE prikazuje kod, a COPY ACTIVATION CODE ga kopira za tvoje druge uređaje. Pregledaj zauzeta mjesta; THIS DEVICE označava ovu instalaciju. Za zamjenu izaberi RELEASE odgovarajućeg uređaja i potvrdi, pa aktiviraj novi. Oslobađanje mjesta ne briše kupljenu licencu. Kod čuvaj privatno. Reinstalacija može stvoriti novi identitet instalacije: za update ne deinstaliraj aplikaciju."
      ],
      [
        "PLANOVI I OBNOVA",
        "Novi uređaj koji ispunjava uslove dobija sedam dana PRO triala od prvog početka koji zabilježi server. Ponovna provjera, update ili reinstalacija ne pokreću zabilježeni rok ispočetka. Poslije isteka zaključavaju se PRO online funkcije; osnovno lokalno puštanje ostaje dostupno. Trial radi nezavisno od naplate. Mjesečno: €2.99, pretplata. Godišnje: €19.90, pretplata. Lifetime: €39, jednokratno. Kupovina je dostupna kada servis za naplatu potvrdi da je prodavnica otvorena. Pročitaj konačne Creem uslove prije plaćanja. MANAGE SUBSCRIPTION upravlja pretplatom. Za aktivaciju i provjeru potreban je internet; server određuje dodatni rok za obnovu."
      ],
      [
        "PROBLEMI I PODRŠKA",
        "Poslije plaćanja i dalje vidiš TRIAL? Provjeri internet, vrati se u aplikaciju i ponovo otvori HELP / ABOUT da server osvježi licencu. Provjeri da je kupovina pokrenuta preko BUY PRO na ovom uređaju. Ne kupuj ponovo radi provjere aktivacije. Za drugi uređaj koristi ACTIVATE PRO i svoj aktivacioni kod. Ako problem ostane, pošalji podršci verziju aplikacije, model uređaja i tačnu poruku greške. Aktivacione kodove i podatke o plaćanju čuvaj privatno."
      ],
      [
        "RADIO · ZEMLJE I STANICE",
        "Otvori RADIO → COUNTRY, izaberi zemlju i dodirni stanicu da je pustiš kroz QUEUE. Dodirni ☆ pored zemlje da je postaviš na vrh: prva izabrana ostaje prva, sljedeća ide ispod nje. Ponovo dodirni ★ za uklanjanje sa vrha. Zvjezdica zemlje ne otvara niti pušta stanicu. Dostupnost i učitavanje stanica zavise od emitera i interneta."
      ],
      [
        "OMILJENE RADIO STANICE · REDOSLJED",
        "Dok je radio stanica prikazana u QUEUE, dodirni njenu ★ da je sačuvaš. Otvori RADIO → ★ FAVORITES za sačuvane stanice. Dugo pritisni omiljenu stanicu, prevuci gore ili dolje i pusti da sačuvaš novi redosljed. Držanje uz gornju ili donju ivicu pomjera listu tokom prevlačenja. Dodir pušta stanicu; dugme za uklanjanje briše samo taj sačuvani favorit. Označene zemlje i sačuvane stanice ulaze u kompatibilan BACKUP ALL."
      ],
      [
        "AKTIVNA PLAYLISTA I ŽIVI QUEUE",
        "Playlista koja zaista svira dobija veliki transparentni play trougao na kamenom dugmetu. Živa kamena DJ konzola je QUEUE dugme, bez dodatnog trougla. Red dugmadi možeš slobodno pregledati: poslije 10 sekundi bez dodira, skrolovanja ili klizanja, dugme koje svira vraća se u vidljivi red. Staje po sredini gdje prostor dozvoljava; početna dugmad, uključujući QUEUE, ostaju lijevo kada ne mogu do sredine. Povratak čeka dok prevlačiš, pomjeraš dugmad ili držiš meni playliste otvoren."
      ]
    ]
  },
  "de": {
    "ui": [
      "DIE BRAKEMONSTER ANLEITUNG",
      "BEREIT. PLAY.",
      "Dein Leitfaden für Android-Smartphones und Tablets.",
      "WAS BRAUCHST DU?",
      "ZUR ANLEITUNG ↑",
      "STARTE DEINE MUSIK.",
      "Nenne App-Version und Gerätemodell.",
      "SUPPORT KONTAKTIEREN",
      "STARTSEITE",
      "NACH OBEN ↑",
      "Aktualisiert am 7. November 2026 · v276 / 1.0.188-pro.136"
    ],
    "topics": [
      [
        "INSTALLATION & UPDATE",
        "Lade die signierte APK über diese Website herunter. Erlaube die Installation aus deinem Browser, wenn Android danach fragt. Installiere Updates über die bestehende App. Nicht deinstallieren: Dabei können Playlists, Einstellungen und die Installationskennung verloren gehen. Erstelle zuerst BACKUP ALL. Der Download wird erst nach Veröffentlichung und Prüfung der öffentlichen APK freigeschaltet. In der App sucht CHECK FOR UPDATES nach einer neuen Version. UPDATE lädt zuerst die APK herunter und prüft sie; danach musst du die Installation in Android bestätigen. Erlaube bei Bedarf die Installation aus dieser Quelle und kehre zur App zurück. Die App kann einen stockenden Installationsdialog erneut öffnen und meldet Erfolg erst nach Bestätigung der installierten Version. Startet die Installation weiterhin nicht, öffne die heruntergeladene APK erneut. Behalte die App und deine Playlists installiert."
      ],
      [
        "ERSTE SCHRITTE",
        "Öffne LOCAL FILES und wähle einen Musikordner oder nutze WEB SEARCH. QUEUE ist deine Wiedergabewarteschlange. Tippe zum Abspielen auf einen Titel. PLAY / PAUSE, BACK, NEXT und STOP befinden sich unten. Über das Fortschrittsseil springst du im Titel. Halte für Auftritte eine getestete lokale Playlist bereit."
      ],
      [
        "LOCAL FILES",
        "Wähle einen Ordner und erteile Android Zugriff. MP3-, FLAC- und WAV-Dateien müssen lesbar sein. Wähle den Ordner erneut, wenn er verschoben oder der Zugriff entzogen wurde. LOCAL SEARCH filtert lokale Titel. Verknüpfe fehlende Dateien erneut oder entferne den Eintrag: Eine Playlist stellt keine Audiodatei wieder her."
      ],
      [
        "QUEUE & WEB SEARCH",
        "Bei eingeschaltetem ADD TO QUEUE landen Web-Titel ohne Unterbrechung in QUEUE. Ist es ausgeschaltet, wird die Auswahl hinter dem aktuellen Titel der laufenden Playlist gespeichert. Ohne Wiedergabe landet sie in QUEUE. In der Playlist gespeicherte Titel bleiben nach einem Neustart erhalten; entsprechende Queue-Kopien werden entfernt. Prüfe vor größeren Ergänzungen das Ziel."
      ],
      [
        "PLAYLISTS & BMQ",
        "Tippe auf einen Playlist-Stein. Langes Drücken öffnet MOVE, Umbenennen und Löschen, soweit erlaubt. WELCOME und QUEUE sind geschützt. SAVE AS PL speichert die Queue als Playlist. .bmq ist ein Web-Titelverweis, kein MP3-Download; die Wiedergabe benötigt Internet und eine verfügbare Quelle. EDIT ändert Eintragsdetails. CLEAR leert QUEUE."
      ],
      [
        "XL · FULL / BACK · + / −",
        "XL öffnet die große vertikale Playlist-Auswahl; NORMAL kehrt zur kompakten Ansicht zurück. FULL vergrößert Liste oder Browser, BACK stellt die vorherige Ansicht her. + / − ändern die Darstellungsgröße. Halte einen XL-Stein gedrückt, wähle MOVE, ziehe ihn zum Ziel und lasse los oder tippe auf einen Zielstein. Halten am Rand scrollt. Geschützte Playlists und feste Navigation sind keine Ziele."
      ],
      [
        "MIX & ROLLMONSTER FX",
        "MIX öffnet zwei Decks und den Crossfader. AUTO MIX steuert Übergänge; lass den nächsten Titel puffern. WAIT bedeutet, dass das Audio noch nicht bereit ist. FX öffnet RollMonster-Effekte und LOOP. Schalte LOOP für normale Wiedergabe aus. Prüfe Internet und Bluetooth vor dem Auftritt; Onlinequellen können nachladen."
      ],
      [
        "BACKUP & WIEDERHERSTELLUNG",
        "Öffne HELP / ABOUT → BACKUP ALL und bewahre die ZIP sicher auf. Über den Backup-Import stellst du kompatible Sicherungen wieder her. WAIT und ein drehender Kreis zeigen laufende Vorgänge; auch das Laden einer Playlist hat eine Anzeige. Playlist-Backups sichern weder das PRO-Lizenzrecht noch unbedingt die lokalen Original-Audiodateien. Sichere diese separat."
      ],
      [
        "ACTIVATE PRO · DREI GERÄTE",
        "Starte den ersten Kauf über BUY PRO in der App, damit die Installation verknüpft wird. Kehre nach der Zahlung zurück und warte auf die Serverprüfung. Öffne auf dem zweiten oder dritten Gerät HELP / ABOUT → ACTIVATE PRO, gib denselben BM1-Code ein und tippe auf ACTIVATE. PRO wird erst nach Bestätigung einer aktiven bezahlten Lizenz durch den Server angezeigt. Eine gekaufte Lizenz erlaubt höchstens drei aktive Installationen. Die vierte wird abgewiesen, bis ein Platz freigegeben wird. TEST-Käufe und -Codes aktivieren keine Produktion."
      ],
      [
        "MY DEVICES & GERÄTEWECHSEL",
        "Öffne mit einer aktiven bezahlten Lizenz HELP / ABOUT → MY DEVICES. SHOW ACTIVATION CODE zeigt den Code; COPY ACTIVATION CODE kopiert ihn für deine anderen Geräte. Prüfe die belegten Plätze; THIS DEVICE kennzeichnet die aktuelle Installation. Wähle zum Gerätewechsel RELEASE beim betreffenden Gerät und bestätige. Aktiviere danach das Ersatzgerät. Die gekaufte Lizenz wird dadurch nicht gelöscht. Halte den Code geheim. Eine Neuinstallation kann eine neue Installationskennung erzeugen: Deinstalliere nicht für Updates."
      ],
      [
        "TARIFE & VERLÄNGERUNG",
        "Ein neues berechtigtes Gerät erhält sieben Tage PRO-Testzeit ab dem ersten vom Server erfassten Testbeginn. Erneute Prüfung, Update oder Neuinstallation starten diese Frist nicht neu. Danach werden reine PRO-Onlinefunktionen gesperrt; einfache lokale Wiedergabe bleibt verfügbar. Die Testzeit ist unabhängig vom Kaufzugang. Monatlich: €2.99 im Abo. Jährlich: €19.90 im Abo. Lifetime: €39 einmalig. Der Checkout ist verfügbar, wenn der Zahlungsdienst den geöffneten Shop bestätigt. Prüfe die endgültigen Creem-Bedingungen vor dem Kauf. MANAGE SUBSCRIPTION verwaltet Abos. Aktivierung und Prüfung benötigen Internet; eine Verlängerungsfrist bestimmt der Server."
      ],
      [
        "PROBLEME & SUPPORT",
        "Nach dem Bezahlen weiterhin TRIAL? Verbinde dich mit dem Internet, kehre zur App zurück und öffne HELP / ABOUT erneut, damit der Server die Lizenz aktualisiert. Prüfe, ob du den Kauf über BUY PRO auf diesem Gerät gestartet hast. Kaufe zur Fehlersuche nicht mehrfach. Nutze auf einem weiteren Gerät ACTIVATE PRO mit deinem Aktivierungscode. Bleibt das Problem bestehen, sende dem Support App-Version, Gerätemodell und die genaue Fehlermeldung. Halte Aktivierungscodes und Zahlungsdaten privat."
      ],
      [
        "RADIO · LÄNDER & SENDER",
        "Öffne RADIO → COUNTRY, wähle ein Land und tippe auf einen Sender, um ihn über QUEUE abzuspielen. Tippe auf ☆ neben einem Land, um es oben anzuheften: Das zuerst gewählte Land bleibt zuerst, das nächste folgt darunter. Tippe erneut auf ★, um es zu lösen. Der Länderstern öffnet oder startet keinen Sender. Verfügbarkeit und Laden hängen vom Sender und deiner Internetverbindung ab."
      ],
      [
        "RADIOFAVORITEN · REIHENFOLGE",
        "Wenn ein Radiosender in QUEUE angezeigt wird, speichere ihn mit seinem ★. Unter RADIO → ★ FAVORITES findest du gespeicherte Sender. Halte einen Favoriten gedrückt, ziehe ihn nach oben oder unten und lasse los, um die Reihenfolge zu speichern. Am oberen oder unteren Rand scrollt die Liste während des Ziehens. Antippen startet den Sender; die Entfernen-Schaltfläche löscht nur diesen gespeicherten Favoriten. Angeheftete Länder und gespeicherte Sender sind in kompatiblen BACKUP-ALL-Sicherungen enthalten."
      ],
      [
        "AKTIVE PLAYLIST & ANIMIERTE QUEUE",
        "Die tatsächlich spielende Playlist zeigt ein großes transparentes Wiedergabedreieck auf ihrer Steinschaltfläche. Das animierte DJ-Pult aus Stein ist die QUEUE-Schaltfläche und hat kein zusätzliches Dreieck. Du kannst die Schaltflächenreihe frei durchsuchen: Nach 10 Sekunden ohne Berührung, Scrollen oder Nachlauf kehrt die spielende Schaltfläche ins Sichtfeld zurück. Sie wird mittig ausgerichtet, soweit Platz vorhanden ist; erste Schaltflächen wie QUEUE bleiben links, wenn sie die Mitte nicht erreichen können. Während Ziehen, Verschieben oder eines geöffneten Playlistmenüs wartet die Rückkehr."
      ]
    ]
  },
  "it": {
    "ui": [
      "LA GUIDA BRAKEMONSTER",
      "PRONTI. PLAY.",
      "La guida per telefoni e tablet Android.",
      "DI COSA HAI BISOGNO?",
      "ALLA GUIDA ↑",
      "VIA ALLA MUSICA.",
      "Indica versione dell’app e modello del dispositivo.",
      "CONTATTA L’ASSISTENZA",
      "HOME",
      "TORNA SU ↑",
      "Aggiornato il 7 novembre 2026 · v276 / 1.0.188-pro.136"
    ],
    "topics": [
      [
        "INSTALLAZIONE E UPDATE",
        "Scarica l’APK firmato da questo sito. Consenti l’installazione dal browser quando Android lo richiede. Installa l’update sopra l’app esistente, senza disinstallarla: potresti perdere playlist, impostazioni e identità dell’installazione. Prima esegui BACKUP ALL. Il download si attiva solo dopo la pubblicazione e la verifica dell’APK pubblico. Nell’app, CHECK FOR UPDATES cerca una nuova versione. UPDATE scarica e verifica prima l’APK; poi devi confermare l’installazione in Android. Se viene richiesta l’autorizzazione a installare da questa fonte, concedila e torna nell’app. L’app può riaprire un avviso di installazione bloccato e segnala il successo solo dopo aver confermato la versione installata. Se l’installazione non parte, riapri l’APK scaricato. Mantieni installate l’app e le playlist."
      ],
      [
        "PRIMI PASSI",
        "Apri LOCAL FILES e scegli una cartella musicale oppure usa WEB SEARCH. QUEUE è la coda di riproduzione. Tocca un brano per avviarlo. PLAY / PAUSE, BACK, NEXT e STOP sono in basso. Usa la corda di avanzamento per spostarti nel brano. Per il palco prepara anche una playlist locale già provata."
      ],
      [
        "LOCAL FILES",
        "Scegli una cartella e autorizza l’accesso Android. I file MP3, FLAC e WAV devono essere leggibili. Se la cartella è stata spostata o il permesso revocato, selezionala di nuovo. LOCAL SEARCH filtra i brani locali. Ricollega o rimuovi i file mancanti: una voce nella playlist non ripristina l’audio."
      ],
      [
        "QUEUE E WEB SEARCH",
        "Con ADD TO QUEUE attivo, i brani web vanno in QUEUE senza interrompere la musica. Se è disattivo, la scelta viene salvata dopo il brano corrente nella playlist in riproduzione; se non suona nulla, va in QUEUE. I brani salvati nella playlist restano dopo il riavvio e le copie corrispondenti in coda vengono rimosse. Controlla la destinazione prima di aggiungere molti brani."
      ],
      [
        "PLAYLIST E BMQ",
        "Tocca il pulsante di pietra della playlist. La pressione prolungata apre MOVE, rinomina ed elimina dove consentito. WELCOME e QUEUE sono protette. SAVE AS PL salva la coda come playlist. .bmq è un riferimento a un brano web, non un MP3 scaricato: servono internet e una fonte disponibile. EDIT modifica i dettagli. CLEAR svuota QUEUE."
      ],
      [
        "XL · FULL / BACK · + / −",
        "XL apre la selezione verticale grande delle playlist; NORMAL torna alla vista compatta. FULL espande elenco o browser, BACK ripristina la vista precedente. + / − regolano le dimensioni. Tieni premuta una playlist XL, scegli MOVE, trascina e rilascia oppure tocca la destinazione. Tenere vicino al bordo fa scorrere l’elenco. Playlist protette e navigazione fissa non sono destinazioni."
      ],
      [
        "MIX E ROLLMONSTER FX",
        "MIX apre i due deck e il crossfader. AUTO MIX gestisce le transizioni: attendi il caricamento del brano successivo. WAIT indica che l’audio non è ancora pronto. FX apre gli effetti RollMonster e LOOP. Disattiva LOOP per tornare alla riproduzione normale. Prova internet e Bluetooth prima dello spettacolo: le fonti online possono richiedere buffering."
      ],
      [
        "BACKUP E RIPRISTINO",
        "Apri HELP / ABOUT → BACKUP ALL e conserva lo ZIP al sicuro. Usa l’importazione backup per ripristinare una copia compatibile. WAIT e il cerchio rotante indicano un’operazione in corso; anche le playlist mostrano il caricamento. Il backup delle playlist non conserva la proprietà della licenza PRO e non include necessariamente i file audio locali originali. Conservali separatamente."
      ],
      [
        "ACTIVATE PRO · TRE DISPOSITIVI",
        "Avvia il primo acquisto da BUY PRO nell’app per collegare l’installazione. Dopo il pagamento torna nell’app e attendi la verifica del server. Sul secondo o terzo dispositivo apri HELP / ABOUT → ACTIVATE PRO, inserisci lo stesso codice BM1 e tocca ACTIVATE. PRO appare solo dopo la conferma del server di una licenza pagata attiva. Una licenza acquistata consente al massimo tre installazioni attive. La quarta viene rifiutata finché non liberi un posto. Acquisti e codici TEST non attivano la produzione."
      ],
      [
        "MY DEVICES E SOSTITUZIONE",
        "Con una licenza pagata attiva, apri HELP / ABOUT → MY DEVICES. SHOW ACTIVATION CODE mostra il codice; COPY ACTIVATION CODE lo copia per gli altri tuoi dispositivi. Controlla i posti occupati; THIS DEVICE indica l’installazione corrente. Per sostituire un dispositivo scegli il suo RELEASE e conferma, poi attiva il nuovo dispositivo. Liberare un posto non elimina la licenza acquistata. Mantieni privato il codice. La reinstallazione può creare una nuova identità: non disinstallare per aggiornare."
      ],
      [
        "PIANI E RINNOVO",
        "Un nuovo dispositivo idoneo riceve sette giorni di prova PRO dal primo avvio della prova registrato dal server. Nuove verifiche, update o reinstallazioni non riavviano il periodo registrato. Alla scadenza si bloccano le funzioni online riservate a PRO; la riproduzione locale di base resta disponibile. La prova è indipendente dalla disponibilità degli acquisti. Mensile: €2.99, abbonamento. Annuale: €19.90, abbonamento. Lifetime: €39, una tantum. Il pagamento è disponibile quando il servizio conferma che il negozio è aperto. Leggi le condizioni finali Creem. MANAGE SUBSCRIPTION gestisce gli abbonamenti. Attivazione e verifica richiedono internet; il server determina l’eventuale tolleranza per il rinnovo."
      ],
      [
        "PROBLEMI E ASSISTENZA",
        "Vedi ancora TRIAL dopo il pagamento? Ricollegati a Internet, torna nell’app e riapri HELP / ABOUT per aggiornare la licenza dal server. Verifica di aver avviato l’acquisto da BUY PRO su questo dispositivo. Non ripetere l’acquisto per verificare l’attivazione. Su un altro dispositivo usa ACTIVATE PRO con il tuo codice. Se il problema continua, invia all’assistenza versione dell’app, modello e messaggio di errore esatto. Mantieni privati i codici di attivazione e i dati di pagamento."
      ],
      [
        "RADIO · PAESI E STAZIONI",
        "Apri RADIO → COUNTRY, scegli un paese e tocca una stazione per riprodurla tramite QUEUE. Tocca ☆ accanto a un paese per fissarlo in cima: il primo scelto resta per primo, il successivo va sotto. Tocca di nuovo ★ per rimuoverlo dalla cima. La stella del paese non apre né riproduce una stazione. Disponibilità e caricamento dipendono dall’emittente e dalla connessione Internet."
      ],
      [
        "RADIO PREFERITE · RIORDINO",
        "Quando una stazione radio appare in QUEUE, tocca la sua ★ per salvarla. Apri RADIO → ★ FAVORITES per le stazioni salvate. Tieni premuto un preferito, trascinalo in alto o in basso e rilascialo per salvare il nuovo ordine. Vicino al bordo superiore o inferiore, l’elenco scorre durante il trascinamento. Tocca un preferito per ascoltarlo; il comando di rimozione elimina solo quel preferito salvato. Paesi fissati e stazioni salvate sono inclusi nei backup BACKUP ALL compatibili."
      ],
      [
        "PLAYLIST ATTIVA E QUEUE ANIMATA",
        "La playlist effettivamente in riproduzione mostra un grande triangolo Play trasparente sul pulsante di pietra. La console DJ animata di pietra è il pulsante QUEUE, senza triangolo aggiuntivo. Puoi esplorare liberamente la fila di pulsanti: dopo 10 secondi senza tocchi, scorrimenti o inerzia, il pulsante in riproduzione torna visibile. Si centra dove lo spazio lo consente; i primi pulsanti, incluso QUEUE, restano a sinistra se non possono raggiungere il centro. Il ritorno attende durante trascinamenti, spostamenti o con il menu della playlist aperto."
      ]
    ]
  },
  "es": {
    "ui": [
      "LA GUÍA BRAKEMONSTER",
      "LISTOS. PLAY.",
      "Tu guía para teléfonos y tablets Android.",
      "¿QUÉ NECESITAS?",
      "VOLVER A LA GUÍA ↑",
      "QUE SUENE LA MÚSICA.",
      "Indica la versión de la app y el modelo del dispositivo.",
      "CONTACTAR CON SOPORTE",
      "INICIO",
      "VOLVER ARRIBA ↑",
      "Actualizado el 7 de noviembre de 2026 · v276 / 1.0.188-pro.136"
    ],
    "topics": [
      [
        "INSTALACIÓN Y UPDATE",
        "Descarga el APK firmado desde este sitio. Permite la instalación desde el navegador cuando Android lo solicite. Instala las actualizaciones sobre la app existente, sin desinstalarla: podrías perder playlists, ajustes y la identidad de instalación. Haz primero BACKUP ALL. La descarga se activa tras publicar y verificar el APK público. En la app, CHECK FOR UPDATES busca una nueva versión. UPDATE descarga y verifica primero el APK; después debes confirmar la instalación en Android. Si se solicita permiso para instalar desde esta fuente, concédelo y vuelve a la app. La app puede reabrir un aviso de instalación atascado y solo indica éxito tras confirmar la versión instalada. Si la instalación sigue sin comenzar, vuelve a abrir el APK descargado. Conserva instaladas la app y tus listas."
      ],
      [
        "PRIMEROS PASOS",
        "Abre LOCAL FILES y elige una carpeta musical o usa WEB SEARCH. QUEUE es tu cola de reproducción. Toca una canción para reproducirla. PLAY / PAUSE, BACK, NEXT y STOP están abajo. Usa la cuerda de progreso para desplazarte por la canción. Prepara una playlist local probada para tus actuaciones."
      ],
      [
        "LOCAL FILES",
        "Elige una carpeta y concede acceso en Android. Los archivos MP3, FLAC y WAV deben ser legibles. Si se movió la carpeta o se revocó el permiso, selecciónala otra vez. LOCAL SEARCH filtra canciones locales. Vuelve a vincular o elimina los archivos ausentes: la entrada de una playlist no restaura el audio."
      ],
      [
        "QUEUE Y WEB SEARCH",
        "Con ADD TO QUEUE activado, las canciones web van a QUEUE sin interrumpir la música. Desactivado, la selección se guarda detrás de la canción actual de la playlist en reproducción; si no suena nada, va a QUEUE. Las canciones guardadas en la playlist permanecen tras reiniciar y se eliminan sus copias correspondientes de la cola. Comprueba el destino antes de añadir muchos temas."
      ],
      [
        "PLAYLISTS Y BMQ",
        "Toca el botón de piedra de una playlist. Mantén pulsado para MOVE, cambiar nombre o eliminar cuando se permita. WELCOME y QUEUE están protegidas. SAVE AS PL guarda la cola como playlist. .bmq es una referencia web, no un MP3 descargado: requiere internet y una fuente disponible. EDIT cambia los detalles. CLEAR vacía QUEUE."
      ],
      [
        "XL · FULL / BACK · + / −",
        "XL abre el selector vertical grande de playlists; NORMAL vuelve a la vista compacta. FULL amplía la lista o el navegador, BACK recupera la vista anterior. + / − ajustan el tamaño. Mantén pulsada una playlist XL, elige MOVE, arrastra y suelta o toca un destino. Mantener cerca del borde desplaza la lista. Las playlists protegidas y la navegación fija no son destinos."
      ],
      [
        "MIX Y ROLLMONSTER FX",
        "MIX abre dos decks y el crossfader. AUTO MIX gestiona las transiciones: deja cargar la siguiente canción. WAIT significa que el audio aún no está listo. FX abre los efectos RollMonster y LOOP. Desactiva LOOP para volver a la reproducción normal. Prueba internet y Bluetooth antes de actuar; las fuentes online pueden necesitar buffering."
      ],
      [
        "BACKUP Y RESTAURACIÓN",
        "Abre HELP / ABOUT → BACKUP ALL y guarda el ZIP en un lugar seguro. Usa la importación de backup para restaurar una copia compatible. WAIT y el círculo giratorio indican una operación en curso; también aparece un indicador al cargar playlists. El backup no guarda la propiedad de la licencia PRO ni incluye necesariamente los audios locales originales. Guárdalos por separado."
      ],
      [
        "ACTIVATE PRO · TRES DISPOSITIVOS",
        "Inicia la primera compra desde BUY PRO en la app para vincular la instalación. Tras pagar, vuelve y espera la comprobación del servidor. En el segundo o tercer dispositivo abre HELP / ABOUT → ACTIVATE PRO, introduce el mismo código BM1 y toca ACTIVATE. PRO aparece solo cuando el servidor confirma una licencia pagada activa. Una licencia comprada permite como máximo tres instalaciones activas. La cuarta se rechaza hasta liberar un espacio. Las compras y códigos TEST no activan producción."
      ],
      [
        "MY DEVICES Y SUSTITUCIÓN",
        "Con una licencia pagada activa, abre HELP / ABOUT → MY DEVICES. SHOW ACTIVATION CODE muestra el código; COPY ACTIVATION CODE lo copia para tus otros dispositivos. Revisa los espacios ocupados; THIS DEVICE identifica la instalación actual. Para sustituir un dispositivo elige su RELEASE y confirma; después activa el sustituto. Liberar un espacio no elimina la licencia comprada. Mantén privado el código. Reinstalar puede crear una identidad nueva: no desinstales para actualizar."
      ],
      [
        "PLANES Y RENOVACIÓN",
        "Un dispositivo nuevo que cumpla los requisitos recibe siete días de prueba PRO desde el primer inicio registrado por el servidor. Volver a comprobar, actualizar o reinstalar no reinicia el periodo registrado. Tras caducar se bloquean las funciones online exclusivas de PRO; la reproducción local básica sigue disponible. La prueba es independiente de las compras. Mensual: €2.99, suscripción. Anual: €19.90, suscripción. Lifetime: €39, pago único. El pago está disponible cuando el servicio confirma que la tienda está abierta. Revisa las condiciones finales de Creem. MANAGE SUBSCRIPTION gestiona las suscripciones. La activación y comprobación requieren internet; el servidor determina el posible plazo de gracia."
      ],
      [
        "PROBLEMAS Y SOPORTE",
        "¿Sigues viendo TRIAL tras pagar? Reconecta internet, vuelve a la app y abre de nuevo HELP / ABOUT para actualizar la licencia desde el servidor. Comprueba que iniciaste la compra desde BUY PRO en este dispositivo. No repitas la compra para comprobar la activación. En otro dispositivo, usa ACTIVATE PRO con tu código. Si el problema persiste, envía a soporte la versión de la app, el modelo y el error exacto. Mantén privados los códigos de activación y los datos de pago."
      ],
      [
        "RADIO · PAÍSES Y EMISORAS",
        "Abre RADIO → COUNTRY, elige un país y toca una emisora para reproducirla a través de QUEUE. Toca ☆ junto a un país para fijarlo arriba: el primero elegido permanece primero y el siguiente queda debajo. Vuelve a tocar ★ para desfijarlo. La estrella del país no abre ni reproduce una emisora. La disponibilidad y la carga dependen de la emisora y de tu conexión a internet."
      ],
      [
        "RADIOS FAVORITAS · REORDENAR",
        "Cuando una emisora aparezca en QUEUE, toca su ★ para guardarla. Abre RADIO → ★ FAVORITES para ver las emisoras guardadas. Mantén pulsada una favorita, arrástrala arriba o abajo y suelta para guardar el nuevo orden. Cerca del borde superior o inferior, la lista se desplaza mientras arrastras. Toca una favorita para escucharla; el control de eliminación borra solo esa favorita guardada. Los países fijados y las emisoras guardadas se incluyen en copias BACKUP ALL compatibles."
      ],
      [
        "LISTA ACTIVA Y QUEUE ANIMADA",
        "La lista que está sonando muestra un gran triángulo Play transparente en su botón de piedra. La consola DJ animada de piedra es el botón QUEUE y no lleva otro triángulo. Puedes explorar libremente la fila de botones: tras 10 segundos sin tocar, desplazar ni deslizar por inercia, el botón que está sonando vuelve a la vista. Se centra donde hay espacio; los primeros botones, incluido QUEUE, permanecen a la izquierda si no pueden alcanzar el centro. El retorno espera durante arrastres, movimientos o mientras esté abierto el menú de la lista."
      ]
    ]
  }
};

'use strict';
(() => {
  const button=document.getElementById('download');
  const label=document.getElementById('release-status');
  const details=document.getElementById('release-details');
  if(!button||!label||!details)return;
  const words={
    en:['APK NOT AVAILABLE','The official download could not be verified. Please try again later.','DOWNLOAD APK','Official BrakeMonster PRO','SHA-256 · file verification'],
    cnr:['APK NIJE DOSTUPAN','Zvanično preuzimanje trenutno nije moguće provjeriti. Pokušajte kasnije.','PREUZMI APK','Zvanični BrakeMonster PRO','SHA-256 · provjera fajla'],
    de:['APK NICHT VERFÜGBAR','Der offizielle Download konnte nicht bestätigt werden.','APK HERUNTERLADEN','Offizieller BrakeMonster PRO','SHA-256 · Dateiprüfung'],
    it:['APK NON DISPONIBILE','Impossibile verificare il download ufficiale.','SCARICA APK','BrakeMonster PRO ufficiale','SHA-256 · verifica file'],
    es:['APK NO DISPONIBLE','No se pudo verificar la descarga oficial.','DESCARGAR APK','BrakeMonster PRO oficial','SHA-256 · verificar archivo']
  };
  let release=null,verified=false,finished=false;
  const hash=document.getElementById('release-hash');
  function render(){
    const t=words[window.BM_LANGUAGE]||words.en;
    if(!finished){
      const text=window.BM_I18N?.text||((s)=>s);
      button.textContent=text('VERIFYING APK…');label.textContent=text('Checking the official release…');details.textContent=text('Release details will appear after verification.');return;
    }
    if(!verified){button.removeAttribute('href');button.setAttribute('aria-disabled','true');button.setAttribute('tabindex','-1');button.textContent=t[0];label.textContent=t[1];details.textContent=window.BM_I18N?.text('Visit Help for assistance.')||'Visit Help for assistance.';if(hash)hash.hidden=true;return;}
    button.href=release.apkUrl;button.removeAttribute('aria-disabled');button.removeAttribute('tabindex');button.textContent=t[2];label.textContent=t[3]+' · v'+release.versionCode;
    details.textContent=release.versionName+' · '+(release.sizeBytes/1e6).toFixed(2)+' MB · Android 8.0+';
    if(hash){hash.hidden=false;hash.querySelector('summary').textContent=t[4];hash.querySelector('code').textContent=release.sha256;}
  }
  window.addEventListener('bm-language-change',render);
  (async()=>{
    try{
      const response=await fetch('../releases/latest.json',{cache:'no-store'});if(!response.ok)throw new Error('release manifest');
      release=await response.json();
      if(release.available!==true||release.buildVerified!==true||release.applicationId!=='com.teraphonia.breakmonster.pro'||!Number.isSafeInteger(release.versionCode)||release.versionCode<1||!/^[a-z0-9][a-z0-9.\-]+$/i.test(release.versionName||'')||!/^[a-f0-9]{64}$/.test(release.sha256||'')||!Number.isSafeInteger(release.sizeBytes)||release.sizeBytes<1e6)throw new Error('invalid release');
      const u=new URL(release.apkUrl);
      if(u.origin!=='https://github.com'||u.username||u.password||u.search||u.hash||!/^\/micovujovicde-netizen\/teraphonia-site\/releases\/download\/[^/]+\/[^/]+\.apk$/.test(u.pathname))throw new Error('untrusted url');
      const parts=u.pathname.split('/');const tag=parts[5];const filename=parts[6];
      const res=await fetch('https://api.github.com/repos/micovujovicde-netizen/teraphonia-site/releases/tags/'+encodeURIComponent(tag),{cache:'no-store',headers:{Accept:'application/vnd.github+json'}});
      if(!res.ok)throw new Error('unverified release');
      const published=await res.json();if(published.draft||published.prerelease)throw new Error('not public');
      const asset=published.assets?.find(a=>a.name===filename&&a.browser_download_url===release.apkUrl);
      if(!asset||asset.size!==release.sizeBytes||asset.digest!=='sha256:'+release.sha256)throw new Error('digest mismatch');
      verified=true;
    }catch(_){verified=false;}
    finished=true;render();
  })();
})();

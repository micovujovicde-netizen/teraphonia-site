# TERAPHONIA web package — responsive + release-ready

This ZIP is an exact replacement of `TERAPHONIA_Website.zip` (root `index.html`).

## Mobile fixes
- Large high-contrast touch targets for phone and tablet
- 2-column mobile navigation; one-column cards and prices on phones
- No horizontal scrolling at 320px; viewport and responsive CSS
- Purchase portal JS and the LIVE safety flag are **unchanged**

## APK publishing (not done yet)
The official Android v221 app has only source code in this session, not a verified signed public APK.
The Android update checker accepts **only** GitHub Release URLs under
`https://github.com/micovujovicde-netizen/teraphonia-site/releases/download/.../*.apk`.

1. Build & test v221 **production** APK and verify the original signing certificate. Never publish a TEST build.
2. Create a GitHub Release in this same `teraphonia-site` repository and attach `BrakeMonster-PRO.apk`.
3. Confirm the asset is publicly downloadable. Compute SHA-256 + exact byte size of the APK.
4. Edit `releases/latest.json` inside this website ZIP to fields:

```json
{
  "schemaVersion": 1,
  "available": true,
  "applicationId": "com.teraphonia.breakmonster.pro",
  "versionCode": 221,
  "versionName": "1.0.184-pro.105",
  "apkUrl": "https://github.com/micovujovicde-netizen/teraphonia-site/releases/download/<ACTUAL_TAG>/BrakeMonster-PRO.apk",
  "sha256": "<SHA256_OF_SIGNED_APK>",
  "sizeBytes": 12345678,
  "notes": "Your release notes"
}
```

Do not use placeholder values or set `available` to true before the file exists.

5. Upload the updated ZIP as `TERAPHONIA_Website.zip` to `teraphonia-site` → `main`.
6. GitHub Actions `Deploy TERAPHONIA website` publishes it; visit site on phone, verify actual APK download.

**SAFETY**: The purchase portal remains disabled in `commercial-config.json` until LIVE billing is verified separately.

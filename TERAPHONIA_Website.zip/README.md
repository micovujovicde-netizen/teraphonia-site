TERAPHONIA WEBSITE — v264 DOWNLOAD + HELP

Replace the root TERAPHONIA_Website.zip in micovujovicde-netizen/teraphonia-site. Existing workflow extracts and deploys it. No deployment performed by this package.

Production APK v264 / 1.0.187-pro.124 is already published as bm-pro-v264. Asset name, size and SHA-256 were checked against the successful production build. The download gate verifies public release metadata before enabling the button.
APK SHA-256: ecc40879807ab32f040069b11fc4d64f8f45c7603a096551e84c5e8f0a98bd7c
APK bytes: 33803302

HELP updated in English, Crnogorski, Deutsch, Italiano, Español: production activation, three device slots, release/replacement and independent seven-day trial. Production Worker r4 trial was confirmed live and the user confirmed trial appeared in the app. No paid production activation end-to-end test was performed.

MALL OPEN CANDIDATE: the website billing switch is now enabled; all live purchases remain gated by the production Worker /v1/health billingEnabled:true and an Android-app device token. No Worker, D1, Creem product or Android changes. Direct browser checkout without the app is not supported. Main marketing and checkout prose remain English.

# Publish v263

Do these steps in order; nothing has been published by this package.

1. Open https://github.com/micovujovicde-netizen/teraphonia-site/releases/new
2. Create tag `bm-pro-v263`, title `BrakeMonster PRO v263`. Upload the supplied signed `BrakeMonster-PRO-UPDATE.apk` unchanged. Publish a normal public release, not a draft or pre-release.
3. Upload `TERAPHONIA_Website.zip` to the root of `teraphonia-site`, replacing the old website ZIP. The existing GitHub Pages workflow extracts it.
4. Check https://teraphonia.com/help.html and https://teraphonia.com/#download-panel . Download enables only when the public Release asset name, URL, size and digest match the manifest. If GitHub API access is blocked or rate-limited, it stays disabled; retry later.

APK: 263 / 1.0.187-pro.123, Android 8.0+, 33,803,302 bytes.
SHA-256: 6027b3836ecea83b5e8fa445d2592b05f4362cd307dcc67f25f4707f01730d6e
Signing certificate SHA-256: 93236b7d82cec6990e0f9b47e29ec1dd31b4a6e2b7884e73813165c3fb75ca4a
Source workflow: https://github.com/micovujovicde-netizen/GigLyrics/actions/runs/42036018176
Source commit: d9908a53d728f73ec9728ac04d8c5a5ed2245568

APK is distributed separately, not inside the website ZIP.
Billing remains disabled. This website does not alter Workers, D1 or secrets.
Production v263 does not yet expose ACTIVATE PRO / MY DEVICES. These are TEST-only in that APK, documented in all five HELP languages. Do not promise working production code-entry controls before a separate app update enables them.

HELP: English, Crnogorski, Deutsch, Italiano, Español; automatic browser language and persistent manual selection. Download controls and navigation use the same language. Main marketing and checkout prose remain English.
Verification: successful production CI build and APK signature verification; downloaded APK hash/size/integrity; JS syntax; download gate branches tested with local mocked responses; all local HTML links/anchors/assets checked. No Android runtime test or visual browser test performed in this task.

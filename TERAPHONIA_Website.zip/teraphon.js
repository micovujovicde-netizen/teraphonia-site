'use strict';
(async () => {
  const supported = ['en', 'cnr', 'de', 'it', 'es'];
  const picker = document.getElementById('language');
  let dictionaries = {};
  let release = null;
  let releaseState = 'checking';
  let product = null;
  function initialLanguage() {
    try {
      const saved = localStorage.getItem('bm-site-language');
      if (supported.includes(saved)) return saved;
    } catch (_) {}
    for (const locale of navigator.languages || [navigator.language || 'en']) {
      const code = locale.toLowerCase().split('-')[0];
      if (['cnr','sr','hr','bs','sh','me'].includes(code)) return 'cnr';
      if (supported.includes(code)) return code;
    }
    return 'en';
  }
  picker.value = initialLanguage();
  function text(key) { return dictionaries[picker.value]?.[key] || dictionaries.en?.[key] || key; }
  function render() {
    document.documentElement.lang = picker.value === 'cnr' ? 'cnr-ME' : picker.value;
    document.querySelectorAll('[data-i18n]').forEach(node => {
      const value = text(node.dataset.i18n);
      if (value !== node.dataset.i18n) node.textContent = value;
    });
    picker.setAttribute('aria-label', text('language'));
    document.querySelector('.demo-play')?.setAttribute('aria-label', text('play_pause'));
    for (const plan of product?.plans || []) {
      const target = document.querySelector(`[data-price="${plan.id}"]`);
      if (target && Number.isFinite(plan.price) && plan.price > 0) {
        target.textContent = new Intl.NumberFormat(picker.value === 'cnr' ? 'sr-Latn-ME' : picker.value,
          {style:'currency',currency:plan.currency}).format(plan.price);
      }
    }
    const button = document.getElementById('teraphon-download');
    if (!button) return;
    button.disabled = releaseState !== 'verified';
    button.textContent = text(releaseState === 'verified' ? 'verified_download' :
      releaseState === 'checking' ? 'checking' : releaseState === 'failed' ? 'download_failed' : 'unavailable');
    document.getElementById('teraphon-release-status').textContent =
      releaseState === 'verified' ? `TERAPHON · ${release.versionName}` : text('release_preparing');
    if (releaseState === 'verified') {
      document.getElementById('teraphon-release-details').textContent =
        `${(release.sizeBytes / 1e6).toFixed(2)} MB · Android 8.0+`;
      const hash = document.getElementById('teraphon-release-hash');
      hash.hidden = false;
      hash.querySelector('code').textContent = release.sha256;
    }
  }
  picker.addEventListener('change', () => {
    try { localStorage.setItem('bm-site-language', picker.value); } catch (_) {}
    render();
  });
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.getElementById('site-navigation');
  function closeMenu() { nav.classList.remove('open'); toggle.setAttribute('aria-expanded', 'false'); }
  toggle.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(open));
  });
  nav.addEventListener('click', event => { if (event.target.closest('a')) closeMenu(); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape') closeMenu(); });
  const tabs = [...document.querySelectorAll('[role=tab]')];
  function selectTab(tab) {
    tabs.forEach(item => {
      const selected = item === tab;
      item.setAttribute('aria-selected', String(selected));
      item.tabIndex = selected ? 0 : -1;
      document.getElementById(item.dataset.panel).hidden = !selected;
    });
  }
  tabs.forEach((tab, index) => {
    tab.addEventListener('click', () => selectTab(tab));
    tab.addEventListener('keydown', event => {
      if (!['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) return;
      event.preventDefault();
      const target = event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1 :
        (index + (event.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length;
      selectTab(tabs[target]); tabs[target].focus();
    });
  });
  document.querySelector('.demo-play')?.addEventListener('click', event => {
    const button = event.currentTarget;
    const active = button.getAttribute('aria-pressed') !== 'true';
    button.setAttribute('aria-pressed', String(active));
    button.querySelector('span').textContent = active ? 'Ⅱ' : '▶︎';
  });
  async function json(path) {
    const response = await fetch(path, {cache:'no-store', signal:AbortSignal.timeout(12000)});
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return response.json();
  }
  try { dictionaries = await json('/teraphon-i18n.json'); } catch (_) {}
  try { product = await json('/teraphon-product.json'); } catch (_) {}
  render();
  const download = document.getElementById('teraphon-download');
  if (!download) return;
  download.addEventListener('click', () => {
    if (releaseState === 'verified' && release) location.assign(release.apkUrl);
  });
  try {
    const [candidate, policy] = await Promise.all([
      json('/releases/teraphon/latest.json'), json('/teraphon-release-policy.json')
    ]);
    if (candidate.available !== true) {
      releaseState = 'pending'; render(); return;
    }
    if (candidate.productId !== 'teraphon' || candidate.applicationId !== 'com.teraphonia.music' ||
        candidate.buildVerified !== true || policy.commercialReady !== true ||
        policy.applicationId !== candidate.applicationId ||
        !/^[a-f0-9]{64}$/.test(policy.signingCertificateSha256 || '') ||
        candidate.signingCertificateSha256 !== policy.signingCertificateSha256 ||
        !Number.isSafeInteger(candidate.versionCode) || candidate.versionCode < 1 ||
        !/^\d+\.\d+\.\d+$/.test(candidate.versionName || '') ||
        !/^[a-f0-9]{64}$/.test(candidate.sha256 || '') ||
        !Number.isSafeInteger(candidate.sizeBytes) || candidate.sizeBytes < 1000000) throw new Error('release');
    const url = new URL(candidate.apkUrl);
    const expected = `/${policy.releaseRepository}/releases/download/teraphon-v${candidate.versionCode}/${policy.assetName}`;
    if (url.origin !== 'https://github.com' || url.pathname !== expected ||
        url.username || url.password || url.search || url.hash) throw new Error('url');
    const published = await json(`https://api.github.com/repos/${policy.releaseRepository}/releases/tags/teraphon-v${candidate.versionCode}`);
    const asset = published.assets?.find(item => item.name === policy.assetName && item.browser_download_url === candidate.apkUrl);
    if (published.draft || published.prerelease || !asset || asset.size !== candidate.sizeBytes ||
        asset.digest !== `sha256:${candidate.sha256}`) throw new Error('asset');
    release = candidate; releaseState = 'verified';
  } catch (_) { releaseState = 'failed'; }
  render();
})();

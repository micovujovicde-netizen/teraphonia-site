'use strict';
(() => {
  const button=document.getElementById('download'),label=document.getElementById('release-status'),details=document.getElementById('release-details');
  if(!button||!label||!details)return;
  const words={
    en:['APK NOT YET RELEASED','The public APK is not available yet.','The download opens after the verified signed APK is published.','DOWNLOAD APK','Official BrakeMonster PRO','HOW TO INSTALL','SHA-256 · file verification'],
    cnr:['APK JOŠ NIJE OBJAVLJEN','Javni APK još nije dostupan.','Download se otvara kada provjereni potpisani APK bude objavljen.','PREUZMI APK','Zvanični BrakeMonster PRO','KAKO INSTALIRATI','SHA-256 · provjera fajla'],
    de:['APK NOCH NICHT VERÖFFENTLICHT','Die öffentliche APK ist noch nicht verfügbar.','Der Download wird nach Veröffentlichung der geprüften signierten APK freigeschaltet.','APK HERUNTERLADEN','Offizieller BrakeMonster PRO','INSTALLATIONSANLEITUNG','SHA-256 · Dateiprüfung'],
    it:['APK NON ANCORA PUBBLICATO','L’APK pubblico non è ancora disponibile.','Il download si apre dopo la pubblicazione dell’APK firmato e verificato.','SCARICA APK','BrakeMonster PRO ufficiale','COME INSTALLARE','SHA-256 · verifica file'],
    es:['APK AÚN NO PUBLICADO','El APK público aún no está disponible.','La descarga se activa tras publicar el APK firmado y verificado.','DESCARGAR APK','BrakeMonster PRO oficial','CÓMO INSTALAR','SHA-256 · verificar archivo']
  };
  let release=null,verified=false;
  function render(){
    const t=words[window.BM_LANGUAGE]||words.en;
    document.querySelector('a[href="help.html#install"]')?.replaceChildren(document.createTextNode(t[5]));
    if(!verified){button.removeAttribute('href');button.setAttribute('aria-disabled','true');button.setAttribute('tabindex','-1');button.textContent=t[0];label.textContent=t[1];details.textContent=t[2];return;}
    button.href=release.apkUrl;button.removeAttribute('aria-disabled');button.removeAttribute('tabindex');button.textContent=t[3];label.textContent=t[4]+' · v'+release.versionCode;
    details.textContent=release.versionName+' · '+(release.sizeBytes/1e6).toFixed(2)+' MB · Android 8.0+';
    const hash=document.getElementById('release-hash');if(hash){hash.hidden=false;hash.querySelector('summary').textContent=t[6];hash.querySelector('code').textContent=release.sha256;}
  }
  window.addEventListener('bm-language-change',render);render();
  (async()=>{try{
    const response=await fetch('releases/latest.json',{cache:'no-store'});if(!response.ok)return;
    release=await response.json();
    if(release.available!==true||release.buildVerified!==true||release.applicationId!=='com.teraphonia.breakmonster.pro'||!Number.isSafeInteger(release.versionCode)||release.versionCode<1||!/^\d+\.\d+\.\d+-pro\.\d+$/.test(release.versionName||'')||!/^[a-f0-9]{64}$/.test(release.sha256||'')||!Number.isSafeInteger(release.sizeBytes)||release.sizeBytes<1e6)return;
    const url=new URL(release.apkUrl);
    if(url.origin!=='https://github.com'||url.username||url.password||url.search||url.hash||!/^\/micovujovicde-netizen\/teraphonia-site\/releases\/download\/[^/]+\/[^/]+\.apk$/.test(url.pathname))return;
    const tag=url.pathname.split('/')[5];const filename=url.pathname.split('/')[6];
    const publicRelease=await fetch('https://api.github.com/repos/micovujovicde-netizen/teraphonia-site/releases/tags/'+encodeURIComponent(tag),{cache:'no-store',headers:{Accept:'application/vnd.github+json'}});
    if(!publicRelease.ok)return;
    const data=await publicRelease.json();if(data.draft||data.prerelease)return;
    const asset=data.assets?.find(a=>a.name===filename&&a.browser_download_url===release.apkUrl);
    if(!asset||asset.size!==release.sizeBytes||asset.digest!=='sha256:'+release.sha256)return;
    verified=true;render();
  }catch(_){render();}})();
})();

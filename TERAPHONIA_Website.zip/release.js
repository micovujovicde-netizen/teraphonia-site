"use strict";
(async () => {
  const label = document.getElementById("release-status");
  const details = document.getElementById("release-details");
  const button = document.getElementById("download");
  if (!label || !details || !button) return;
  const unavailable = () => {
    button.removeAttribute("href");
    button.setAttribute("aria-disabled", "true");
    button.setAttribute("tabindex", "-1");
    button.textContent = "APK NOT YET RELEASED";
    label.textContent = "The signed public APK has not been published yet.";
    details.textContent = "No download is offered until the official Android release is verified.";
  };
  unavailable();
  try {
    const response = await fetch("releases/latest.json", { cache: "no-store" });
    if (!response.ok) return;
    const release = await response.json();
    if (release.available !== true || release.applicationId !== "com.teraphonia.breakmonster.pro" ||
        !Number.isSafeInteger(release.versionCode) || release.versionCode < 1 ||
        !/^\d+\.\d+\.\d+-pro\.\d+$/.test(release.versionName || "") ||
        !/^[a-f0-9]{64}$/.test(release.sha256 || "") ||
        !Number.isSafeInteger(release.sizeBytes) || release.sizeBytes < 1000000) return;
    const url = new URL(release.apkUrl);
    if (url.protocol !== "https:" || url.hostname !== "github.com" || url.username || url.password || url.port ||
        !/^\/micovujovicde-netizen\/teraphonia-site\/releases\/download\/[^/]+\/[^/]+\.apk$/.test(url.pathname)) return;
    button.href = url.href;
    button.removeAttribute("aria-disabled");
    button.removeAttribute("tabindex");
    button.textContent = "DOWNLOAD APK";
    label.textContent = "Official BrakeMonster PRO · v" + release.versionCode + " available for Android.";
    details.textContent = "Version " + release.versionName + " · " + (release.sizeBytes / 1048576).toFixed(1) + " MB · Android 8.0+";
  } catch (_) { unavailable(); }
})();

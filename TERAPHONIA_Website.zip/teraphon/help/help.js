"use strict";
(async () => {
  const choose = document.getElementById('language');
  const supported = ['en','cnr','de','it','es','fr'];
  let guide = {};
  try {
    const response = await fetch('/teraphon/help/guide.json', {cache:'no-store'});
    if (!response.ok) throw new Error('Guide HTTP ' + response.status);
    guide = await response.json();
  } catch (error) { console.warn('TERAPHON help: using English fallback', error); }
  function render() {
    const lang = supported.includes(choose?.value) ? choose.value : 'en';
    const data = guide[lang] || guide.en;
    if (!data) return; // Keep the complete accessible English HTML fallback.
    document.querySelectorAll('[data-guide-label]').forEach(node => {
      const value = data[node.dataset.guideLabel];
      if (typeof value === 'string') node.textContent = value;
    });
    document.querySelectorAll('[data-guide-title]').forEach(node => {
      const value = data.topics?.[node.dataset.guideTitle]?.title;
      if (typeof value === 'string') node.textContent = value;
    });
    document.querySelectorAll('[data-guide-body]').forEach(node => {
      const value = data.topics?.[node.dataset.guideBody]?.body;
      if (typeof value === 'string') node.textContent = value;
    });
  }
  choose?.addEventListener('change',render);
  render();
})();

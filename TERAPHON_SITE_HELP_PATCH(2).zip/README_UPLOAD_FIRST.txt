TERAPHON WEBSITE — WINDOWS & ANDROID RECEIVERS

Upload the entire file TERAPHON_SITE_HELP_PATCH.zip to the root of:
https://github.com/micovujovicde-netizen/teraphonia-site

The EXISTING workflow .github/workflows/TERAPHONIA_SITE_PATCH_APPLY.yml will:
* extract only this receiver add-on
* verify the EXE/APK SHA256 and sizes
* merge it into the live TERAPHONIA_Website.zip without changing billing,
  the main APK release manifest, pricing, CSS/JS of the rest of the site
* commit the modified website ZIP, which triggers the existing deploy.yml.

After the website deploy is green, the new page will be:
https://teraphonia.com/teraphon/receivers/

Includes English, Montenegrin, German, Italian, Spanish and French.
Images are compact 9:16 thumbnails with a full-size overlay on click.
Receiver downloads are binary EXE and APK supplied by the user.
Windows Receiver is unsigned; show verified-source and SmartScreen guidance
without suggesting disabling antivirus.

Note: The Wi-Fi audio leg is described as CD-quality; Bluetooth output quality
may be codec dependent. Avoid claiming Bluetooth is necessarily lossless.

IMPORTANT: This package intentionally reuses the existing HELPPATCH workflow; no new workflow file is needed.

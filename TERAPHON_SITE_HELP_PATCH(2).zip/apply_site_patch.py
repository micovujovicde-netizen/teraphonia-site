#!/usr/bin/env python3
"""Apply user-provided TERAPHON receiver assets into the canonical website ZIP.
Preserves existing site content, billing, current APK downloads and all release metadata.
"""
import sys,zipfile,tempfile,hashlib,json,os
from pathlib import Path
SITE=Path(sys.argv[1]) if len(sys.argv)>1 else Path('TERAPHONIA_Website.zip')
PATCH=Path(sys.argv[2]) if len(sys.argv)>2 else Path('TERAPHON_RECEIVERS_SITE_PATCH.zip')
PREFIX='payload/'
SECTION='<!-- TERAPHON-RECEIVERS-START -->'
END='<!-- TERAPHON-RECEIVERS-END -->'
TARGETS=('index.html','teraphon/help/index.html','teraphon/download/index.html')
with zipfile.ZipFile(SITE,'r') as s,zipfile.ZipFile(PATCH,'r') as p:
    if s.testzip() or p.testzip():raise SystemExit('Corrupt ZIP')
    oldnames=s.namelist()
    if len(set(oldnames))!=len(oldnames):raise SystemExit('Duplicate site ZIP paths')
    old={n:s.read(n) for n in oldnames if not n.endswith('/')}
    if not {'index.html','teraphon/help/index.html'}.issubset(old):
        raise SystemExit('Not the canonical TERAPHON website ZIP — refusing overwrite')
    new=dict(old)
    names=[n for n in p.namelist() if n.startswith(PREFIX) and not n.endswith('/')]
    if not names:raise SystemExit('Missing patch payload')
    for n in names:
        dst=n[len(PREFIX):]
        if dst.startswith('/') or '..' in Path(dst).parts:raise SystemExit('Invalid payload path')
        if not dst.startswith('teraphon/receivers/'):
            raise SystemExit('Patch tries to edit outside TERAPHON receivers: '+dst)
        new[dst]=p.read(n)
    manifest=json.loads(new['teraphon/receivers/manifest.json'])
    for a in manifest['assets']:
        key='teraphon/receivers/downloads/'+a['file']
        data=new.get(key)
        if not data or len(data)!=a['bytes'] or hashlib.sha256(data).hexdigest()!=a['sha256']:
            raise SystemExit('Binary verification failed: '+key)
    snippet=p.read('site-snippet.html').decode('utf8')
    for target in TARGETS:
        if target not in old:
            if target=='teraphon/download/index.html':continue
            raise SystemExit('Missing expected website page: '+target)
        html=new[target].decode('utf8')
        # Append after existing main (before footer), keeping all other sections, code and paywall logic unchanged.
        if SECTION in html:
            if END not in html:raise SystemExit('Corrupt receiver markers in '+target)
            a=html.index(SECTION);b=html.index(END,a)+len(END)
            html=html[:a]+snippet+html[b:]
        else:
            pos=html.lower().find('</main>')
            if pos<0:raise SystemExit('No </main> in '+target)
            html=html[:pos]+'\n'+snippet+'\n'+html[pos:]
        css='<link rel="stylesheet" href="/teraphon/receivers/cta.css" data-receiver-cta>'
        js='<script defer src="/teraphon/receivers/site-link.js" data-receiver-i18n></script>'
        if 'data-receiver-cta' not in html:
            pos=html.lower().find('</head>')
            if pos<0:raise SystemExit('No </head> in '+target)
            html=html[:pos]+css+'\n'+html[pos:]
        if 'data-receiver-i18n' not in html:
            pos=html.lower().find('</body>')
            if pos<0:raise SystemExit('No </body> in '+target)
            html=html[:pos]+js+'\n'+html[pos:]
        new[target]=html.encode('utf8')
    # Reject any edits outside exactly the HTML targets and the isolated receiver directory.
    changes={n for n in old if old[n]!=new[n]}
    if changes-set(TARGETS):raise SystemExit('Unexpected change to '+repr(changes-set(TARGETS)))
    newfiles=set(new)-set(old)
    if any(not n.startswith('teraphon/receivers/') for n in newfiles):raise SystemExit('Unexpected new paths')
    for guarded in ('commercial-config.json','teraphon-product.json','releases/latest.json','teraphon-i18n.json','purchase.js','purchase-complete.html'):
        if guarded in old and new[guarded]!=old[guarded]:raise SystemExit('Guarded file changed')
    with tempfile.NamedTemporaryFile(dir=SITE.parent,suffix='.zip',delete=False) as f:
        temp=Path(f.name)
    try:
        with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            for name,data in new.items():z.writestr(name,data)
            z.comment=s.comment
        with zipfile.ZipFile(temp) as check:
            if check.testzip():raise SystemExit('Patched ZIP integrity test failed')
            if len(check.namelist())!=len(set(check.namelist())):raise SystemExit('Duplicate paths')
        temp.replace(SITE)
    finally:
        temp.unlink(missing_ok=True)
    print(f'Receivers patch applied safely: {len(newfiles)} added, {len(changes)} HTML pages updated; release metadata preserved')

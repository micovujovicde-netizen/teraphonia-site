import sys, pathlib, zipfile, json, re, hashlib, html, os, io
site,patch=map(pathlib.Path,sys.argv[1:3]); filename='TERAPHON RECEIEVER.APK'; base='teraphon/receivers/'; apkpath=base+'downloads/'+filename
with zipfile.ZipFile(patch) as z:
    texts=json.loads(z.read('texts.json')); apk=z.read(filename)
assert hashlib.sha256(apk).hexdigest()=='888a4b415843953360071ceeb3f84288c817c3ca527a21863997908af5af74f7'
with zipfile.ZipFile(io.BytesIO(apk)) as z: assert z.testzip() is None
with zipfile.ZipFile(site) as z:
    assert z.testzip() is None
    infos=z.infolist(); data={i.filename:z.read(i) for i in infos}
# Work on the current site's files, not a snapshot. Windows, pricing, release and all other assets remain intact.
def get(p): return data[p].decode('utf-8')
def put(p,s): data[p]=s.encode('utf-8')
def load(p): return json.loads(data[p])
def save(p,d): put(p,json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def sub1(pattern,repl,s):
    s,n=re.subn(pattern,lambda m:repl,s,count=1,flags=re.S); assert n==1,pattern; return s
def esc(s): return html.escape(s,quote=False)
rx=load(base+'i18n.json'); guide=load('teraphon/help/guide.json'); faq=load('assets/tera-i18n.json')
for lang,t in texts.items():
    d=rx[lang]; old_status=d.get('androidStatus',''); warning=d.get('androidChanges','')
    d.update(androidStatus=t['status'],andSteps=t['steps'],androidChanges=t['update']+' '+warning if warning and t['update'] not in warning else warning,androidControls=t['controls'],downloadAndroid=filename)
    if not d['androidChanges'].startswith(t['update']): d['androidChanges']=t['update']+' '+d['androidChanges']
    for obj,key in [(guide[lang]['topics']['cast'],'body'),(faq[lang],'faq5b')]:
        old=obj[key]
        if old_status and old_status in old: old=old.replace(old_status,t['available'])
        elif t['available'] not in old: old+=' '+t['available']
        if t['update'] not in old: old+=' '+t['update']
        if t['controls'] not in old: old+=' '+t['controls']
        obj[key]=old
save(base+'i18n.json',rx); save('teraphon/help/guide.json',guide); save('assets/tera-i18n.json',faq)
p=base+'index.html'; s=get(p); start=s.index('<section class="rx-card" id="android">'); end=s.index('</section>',start)+len('</section>'); a=s[start:end]; en=rx['en']
a=sub1(r'<div class="rx-buttons">.*?</div>','<div class="rx-buttons"><a class="rx-button" data-rx="downloadAndroid" href="downloads/TERAPHON%20RECEIEVER.APK" download="TERAPHON RECEIEVER.APK">TERAPHON RECEIEVER.APK</a><p data-rx="androidStatus">'+esc(en['androidStatus'])+'</p></div>',a)
a=sub1(r'<ol data-rx-list="andSteps"[^>]*>.*?</ol>','<ol data-rx-list="andSteps">'+''.join('<li>'+esc(x)+'</li>' for x in en['andSteps'])+'</ol>',a)
a=sub1(r'<p data-rx="androidChanges"[^>]*>.*?</p>(?:<p data-rx="androidControls"[^>]*>.*?</p>)?','<p data-rx="androidChanges">'+esc(en['androidChanges'])+'</p><p data-rx="androidControls">'+esc(en['androidControls'])+'</p>',a)
put(p,(s[:start]+a+s[end:]).replace('receivers.js?v=rxrelease1','receivers.js?v=rx19'))
p=base+'receivers.js'; s=get(p); s=re.sub(r'i18n\.json\?v=[\w-]+','i18n.json?v=rx19',s); put(p,s)
p='teraphon/help/index.html'; s=get(p); s=sub1(r'<p data-tera="faq5b"[^>]*>.*?</p>','<p data-tera="faq5b">'+esc(faq['en']['faq5b'])+'</p>',s); put(p,s.replace('tera-site.js?v=rxrelease1','tera-site.js?v=rx19'))
p='assets/tera-site.js'; s=get(p); s=re.sub(r'tera-i18n\.json\?v=[\w-]+','tera-i18n.json?v=rx19',s); put(p,s)
# Stable download URL and manifest; remove obsolete Receiver APKs from this folder only.
for p in list(data):
    if p.startswith(base+'downloads/') and p.lower().endswith('.apk'): del data[p]
data[apkpath]=apk
p=base+'manifest.json'; m=load(p); m['assets']=[x for x in m.get('assets',[]) if not x.get('file','').lower().endswith('.apk')];m['assets'].append({'file':filename,'bytes':len(apk),'sha256':hashlib.sha256(apk).hexdigest(),'versionName':'1.9','versionCode':10,'applicationId':'com.teraphon.receiver','minSdk':26});save(p,m)
# Atomic rewrite; preserve original ZIP metadata for existing members.
tmp=site.with_suffix('.tmp.zip'); old={i.filename:i for i in infos}
with zipfile.ZipFile(tmp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p,b in data.items():
        if p in old: z.writestr(old[p],b)
        else: z.writestr(p,b)
with zipfile.ZipFile(tmp) as z:
    assert z.testzip() is None and z.read(apkpath)==apk
    assert len([n for n in z.namelist() if n.startswith(base+'downloads/') and n.lower().endswith('.apk')])==1
os.replace(tmp,site)
print('Android Receiver 1.9 APK and six-language setup/update/help merged:',site)
